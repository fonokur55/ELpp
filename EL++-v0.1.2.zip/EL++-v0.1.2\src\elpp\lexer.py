"""Lexer: forrás → token lista (HU/EN szinonimák)."""

from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass

from elpp.errors import LexerError
from elpp.synonyms import (
    COMMENT_STARTERS,
    FILLER_WORDS,
    PHRASE_TO_KIND,
    SYMBOLS,
)


@dataclass
class Token:
    kind: str
    value: str | float | None = None
    line: int = 1
    column: int = 1

    def __repr__(self) -> str:
        if self.value is not None:
            return f"Token({self.kind}, {self.value!r}, L{self.line})"
        return f"Token({self.kind}, L{self.line})"


_IDENT_RE = re.compile(r"[\w\u00C0-\u024F]+", re.UNICODE)


def _strip_accents(s: str) -> str:
    nfkd = unicodedata.normalize("NFKD", s)
    return "".join(c for c in nfkd if not unicodedata.combining(c))


def _word_eq(a: str, b: str) -> bool:
    return _strip_accents(a.casefold()) == _strip_accents(b.casefold())


def _is_filler(word: str) -> bool:
    w = _strip_accents(word.casefold())
    return word.casefold() in FILLER_WORDS or w in FILLER_WORDS


def _match_phrase_at(text: str, pos: int, phrase: str) -> int | None:
    """Ha phrase illeszkedik text[pos:]-ra, visszaadja a végpozíciót."""
    i = pos
    for word in phrase.split():
        while i < len(text) and text[i].isspace():
            i += 1
        if i >= len(text):
            return None
        m = _IDENT_RE.match(text, i)
        if not m or not _word_eq(m.group(0), word):
            return None
        i = m.end()
    if i < len(text):
        nxt = text[i]
        if nxt.isalnum() or nxt == "_":
            return None
    return i


def _keyword_at(text: str, pos: int) -> tuple[str, str, int] | None:
    for phrase, kind in PHRASE_TO_KIND:
        end = _match_phrase_at(text, pos, phrase)
        if end is not None:
            return kind, phrase, end
    return None


def _strip_line_comment(line: str) -> str:
    lower = line.casefold()
    for starter in sorted(COMMENT_STARTERS, key=len, reverse=True):
        idx = lower.find(starter.casefold())
        if idx >= 0:
            return line[:idx].rstrip()
    return line


def tokenize(source: str) -> list[Token]:
    tokens: list[Token] = []
    lines = source.splitlines()
    if not lines and source:
        lines = [source]

    for line_no, raw_line in enumerate(lines, start=1):
        line = _strip_line_comment(raw_line)
        if not line.strip():
            tokens.append(Token("NEWLINE", line=line_no))
            continue

        col = 1
        pos = 0
        n = len(line)

        while pos < n:
            if line[pos].isspace():
                pos += 1
                col += 1
                continue

            # kétjegyű, majd egyjegyű szimbólum
            matched = False
            for sym in (">=", "<=", "==", "!=", "+", "-", "*", "/", "(", ")", "<", ">"):
                if line.startswith(sym, pos):
                    # minus vs negatív szám: ha - és utána szám, számként kezeljük lent
                    if sym == "-" and pos + 1 < n and (line[pos + 1].isdigit() or line[pos + 1] == "."):
                        break
                    tokens.append(Token(SYMBOLS[sym], sym, line_no, col))
                    pos += len(sym)
                    col += len(sym)
                    matched = True
                    break
            if matched:
                continue

            if line[pos] in ('"', "'"):
                quote = line[pos]
                start_col = col
                pos += 1
                col += 1
                chars: list[str] = []
                while pos < n:
                    ch = line[pos]
                    if ch == "\\" and pos + 1 < n:
                        nxt = line[pos + 1]
                        escapes = {"n": "\n", "t": "\t", "\\": "\\", quote: quote}
                        chars.append(escapes.get(nxt, nxt))
                        pos += 2
                        col += 2
                        continue
                    if ch == quote:
                        pos += 1
                        col += 1
                        tokens.append(Token("STRING", "".join(chars), line_no, start_col))
                        break
                    chars.append(ch)
                    pos += 1
                    col += 1
                else:
                    raise LexerError('Hiányzik a záró idézőjel.', line_no, start_col)
                continue

            if line[pos].isdigit() or (
                line[pos] == "-" and pos + 1 < n and (line[pos + 1].isdigit() or line[pos + 1] == ".")
            ):
                start_col = col
                start = pos
                if line[pos] == "-":
                    pos += 1
                while pos < n and (line[pos].isdigit() or line[pos] == "."):
                    pos += 1
                num_str = line[start:pos]
                val: float | int = int(num_str) if "." not in num_str else float(num_str)
                tokens.append(Token("NUMBER", val, line_no, start_col))
                col += pos - start
                continue

            kw = _keyword_at(line, pos)
            if kw:
                kind, phrase, end = kw
                tokens.append(Token(kind, phrase, line_no, col))
                col += end - pos
                pos = end
                continue

            m = _IDENT_RE.match(line, pos)
            if m:
                word = m.group(0)
                if _is_filler(word):
                    pos = m.end()
                    col += len(word)
                    continue
                tokens.append(Token("IDENT", word, line_no, col))
                pos = m.end()
                col += len(word)
                continue

            raise LexerError(f"Nem értem ezt a karaktert: „{line[pos]}”.", line_no, col)

        tokens.append(Token("NEWLINE", line=line_no))

    tokens.append(Token("EOF", line=len(lines) or 1))
    return tokens


def filter_newlines(tokens: list[Token]) -> list[Token]:
    return [t for t in tokens if t.kind != "NEWLINE"]

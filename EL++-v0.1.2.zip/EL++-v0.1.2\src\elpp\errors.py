"""Természetes hibák HU/EN stílusban."""

from __future__ import annotations


class ELPPError(Exception):
    """Alap EL++ hiba."""

    def __init__(self, message: str, line: int | None = None, column: int | None = None):
        self.line = line
        self.column = column
        parts: list[str] = []
        if line is not None:
            parts.append(f"Hiba a {line}. sorban:")
        parts.append(message)
        if column is not None and line is not None:
            parts.append(f"  (oszlop ~{column})")
        super().__init__("\n".join(parts))


class LexerError(ELPPError):
    """Tokenizálási hiba."""


class ParseError(ELPPError):
    """Szintaxis hiba."""


class RuntimeError(ELPPError):
    """Futtatási hiba."""


def unexpected_token(got: str, expected: str, line: int | None = None) -> ParseError:
    return ParseError(
        f"Nem várt elem: „{got}”. Talán „{expected}” kellene?",
        line=line,
    )


def undefined_variable(name: str, line: int | None = None) -> RuntimeError:
    return RuntimeError(
        f"Nincs ilyen változó: „{name}”. Előbb „legyen {name} …” vagy „set {name} to …”.",
        line=line,
    )


def type_error(msg: str, line: int | None = None) -> RuntimeError:
    return RuntimeError(msg, line=line)

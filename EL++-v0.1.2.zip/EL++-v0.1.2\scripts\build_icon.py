"""EL++.png -> Windows-kompatibilis .ico (16, 32, 48, 256 px)."""
from __future__ import annotations

import sys
from pathlib import Path

from PIL import Image


def build_ico(png_path: Path, ico_path: Path) -> None:
    img = Image.open(png_path).convert("RGBA")
    sizes = [(16, 16), (32, 32), (48, 48), (256, 256)]
    img.save(ico_path, format="ICO", sizes=sizes)


if __name__ == "__main__":
    src = Path(sys.argv[1])
    dst = Path(sys.argv[2])
    build_ico(src, dst)
    print("ico ok", dst)

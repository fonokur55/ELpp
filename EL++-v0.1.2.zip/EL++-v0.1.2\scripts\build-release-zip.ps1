# GitHub Release ZIP keszitese (install.bat, EL++.png, src, vscode-elpp, stb.)
# Hasznalat: .\scripts\build-release-zip.ps1

$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot

$version = (Select-String -Path (Join-Path $Root "pyproject.toml") -Pattern '^version = "(.+)"' |
    ForEach-Object { $_.Matches[0].Groups[1].Value })
if (-not $version) { throw "Verzio nem talalhato a pyproject.toml-ban." }

$zipName = "EL++-v$version.zip"
$stagingName = "EL++-v$version"
$distDir = Join-Path $Root "dist"
$staging = Join-Path $distDir $stagingName
$zipPath = Join-Path $distDir $zipName

if (Test-Path $staging) { Remove-Item $staging -Recurse -Force }
if (Test-Path $zipPath) { Remove-Item $zipPath -Force }
New-Item -ItemType Directory -Force -Path $staging | Out-Null

$rootFiles = @(
    "EL++.png",
    "install.bat",
    "install.ps1",
    "refresh-icons.ps1",
    "Register-ElppWindows.ps1",
    "release.json",
    "pyproject.toml",
    "README.md"
)
foreach ($f in $rootFiles) {
    $src = Join-Path $Root $f
    if (-not (Test-Path $src)) { throw "Hianyzik: $f" }
    Copy-Item $src (Join-Path $staging $f)
}

Copy-Item (Join-Path $Root "scripts") (Join-Path $staging "scripts") -Recurse
Copy-Item (Join-Path $Root "examples") (Join-Path $staging "examples") -Recurse
New-Item -ItemType Directory -Force -Path (Join-Path $staging "src\elpp") | Out-Null
Get-ChildItem (Join-Path $Root "src\elpp") -File | Copy-Item -Destination (Join-Path $staging "src\elpp")

$extSrc = Join-Path $Root "vscode-elpp"
$extDst = Join-Path $staging "vscode-elpp"
New-Item -ItemType Directory -Force -Path $extDst | Out-Null
$vsix = "elpp-language-$version.vsix"
Get-ChildItem $extSrc -File | Where-Object {
    $_.Extension -ne ".vsix" -or $_.Name -eq $vsix
} | Copy-Item -Destination $extDst
Get-ChildItem $extSrc -Directory | ForEach-Object {
    Copy-Item $_.FullName (Join-Path $extDst $_.Name) -Recurse
}
if (-not (Test-Path (Join-Path $extDst $vsix))) {
    Write-Host "  ! Figyelem: $vsix hianyzik - futtasd elobb: .\install.ps1" -ForegroundColor Yellow
}

Compress-Archive -Path $staging -DestinationPath $zipPath -Force
Remove-Item $staging -Recurse -Force

$sizeKb = [math]::Round((Get-Item $zipPath).Length / 1KB)
Write-Host ('Kesz: {0} ({1} KB)' -f $zipPath, $sizeKb) -ForegroundColor Green
Write-Host "GitHub Release: https://github.com/fonokur55/EL-/releases/new" -ForegroundColor Cyan
Write-Host "  Tag: v$version" -ForegroundColor Cyan
Write-Host "  Asset: $zipName" -ForegroundColor Cyan

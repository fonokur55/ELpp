"""Parser: token lista → AST."""

from __future__ import annotations

from elpp import ast
from elpp.errors import ParseError, unexpected_token
from elpp.lexer import Token, filter_newlines, tokenize

# Operátor precedencia (magasabb szám = szorosabb kötés)
_PRECEDENCE: dict[str, int] = {
    "OR": 1,
    "AND": 2,
    "EQ": 3, "NE": 3,
    "LT": 4, "GT": 4, "LE": 4, "GE": 4,
    "PLUS": 5, "MINUS": 5,
    "STAR": 6, "SLASH": 6,
}

_COMPARISON = {"EQ", "NE", "LT", "GT", "LE", "GE"}
_ARITHMETIC = {"PLUS", "MINUS", "STAR", "SLASH"}


class Parser:
    def __init__(self, tokens: list[Token]):
        self.tokens = filter_newlines(tokens)
        self.pos = 0

    def _cur(self) -> Token:
        return self.tokens[self.pos]

    def _peek(self, offset: int = 0) -> Token:
        i = self.pos + offset
        if i >= len(self.tokens):
            return self.tokens[-1]
        return self.tokens[i]

    def _at_end(self) -> bool:
        return self._cur().kind == "EOF"

    def _advance(self) -> Token:
        t = self._cur()
        if not self._at_end():
            self.pos += 1
        return t

    def _match(self, *kinds: str) -> Token | None:
        if self._cur().kind in kinds:
            return self._advance()
        return None

    def _expect(self, kind: str, hint: str = "") -> Token:
        if self._cur().kind != kind:
            got = self._cur().kind
            msg = unexpected_token(got, kind).args[0]
            if hint:
                msg += f" {hint}"
            raise ParseError(msg, line=self._cur().line)
        return self._advance()

    def parse(self) -> ast.Program:
        stmts: list[ast.Stmt] = []
        while not self._at_end():
            if self._cur().kind == "EOF":
                break
            stmts.append(self._statement())
        return ast.Program(stmts)

    def _statement(self) -> ast.Stmt:
        t = self._cur()
        line = t.line

        if t.kind == "LET":
            self._advance()
            name_t = self._expect("IDENT", "Változónév kell a „legyen” / „set” után.")
            name = str(name_t.value)
            if not self._match("EQ"):
                raise ParseError(
                    'Hiányzik az értékadás: „egyen”, „to”, „egyenlő” stb.',
                    line=self._cur().line,
                )
            value = self._expression()
            return ast.Let(name, value, line)

        if t.kind == "PRINT":
            self._advance()
            values: list[ast.Expr] = []
            while self._is_expr_start():
                values.append(self._expression())
            return ast.Print(values, line)

        if t.kind == "IF":
            self._advance()
            cond = self._expression()
            self._expect("THEN", 'Hiányzik az „akkor” / „then”.')
            then_body = self._block()
            else_body: list[ast.Stmt] | None = None
            if self._match("ELSE"):
                else_body = self._block()
            if self._cur().kind == "END":
                self._advance()
            return ast.If(cond, then_body, else_body, line)

        if t.kind == "WHILE":
            self._advance()
            cond = self._expression()
            body = self._block()
            if self._cur().kind == "END":
                self._advance()
            return ast.While(cond, body, line)

        if t.kind == "END":
            self._advance()
            raise ParseError("Felesleges „kész” / „end”.", line=line)

        raise ParseError(
            f"Nem értem ezt a sort. Talán „legyen”, „írd ki”, „ha” vagy „amíg” kellene?",
            line=line,
        )

    def _is_expr_start(self) -> bool:
        return self._cur().kind in (
            "IDENT", "NUMBER", "STRING", "TRUE", "FALSE", "LPAREN", "NOT", "MINUS",
        )

    def _block(self) -> list[ast.Stmt]:
        body: list[ast.Stmt] = []
        while not self._at_end():
            k = self._cur().kind
            if k in ("END", "ELSE", "EOF"):
                break
            if k == "EOF":
                break
            body.append(self._statement())
        return body

    def _expression(self) -> ast.Expr:
        return self._parse_or()

    def _parse_or(self) -> ast.Expr:
        left = self._parse_and()
        while self._match("OR"):
            op = "OR"
            right = self._parse_and()
            left = ast.Binary(op, left, right, line=left.line if hasattr(left, "line") else 0)
        return left

    def _parse_and(self) -> ast.Expr:
        left = self._parse_comparison()
        while self._match("AND"):
            right = self._parse_comparison()
            left = ast.Binary("AND", left, right, line=getattr(left, "line", 0))
        return left

    def _parse_comparison(self) -> ast.Expr:
        left = self._parse_additive()
        while self._cur().kind in _COMPARISON:
            op = self._advance().kind
            right = self._parse_additive()
            left = ast.Binary(op, left, right, line=getattr(left, "line", 0))
        return left

    def _parse_additive(self) -> ast.Expr:
        left = self._parse_multiplicative()
        while self._cur().kind in ("PLUS", "MINUS"):
            op = self._advance().kind
            right = self._parse_multiplicative()
            left = ast.Binary(op, left, right, line=getattr(left, "line", 0))
        return left

    def _parse_multiplicative(self) -> ast.Expr:
        left = self._parse_unary()
        while self._cur().kind in ("STAR", "SLASH"):
            op = self._advance().kind
            right = self._parse_unary()
            left = ast.Binary(op, left, right, line=getattr(left, "line", 0))
        return left

    def _parse_unary(self) -> ast.Expr:
        if self._match("NOT"):
            return ast.Unary("NOT", self._parse_unary(), line=self._peek(-1).line)
        if self._match("MINUS"):
            return ast.Unary("MINUS", self._parse_unary(), line=self._peek(-1).line)
        return self._parse_primary()

    def _parse_primary(self) -> ast.Expr:
        t = self._cur()
        line = t.line

        if self._cur().kind == "NUMBER":
            tok = self._advance()
            v = tok.value
            assert isinstance(v, (int, float))
            return ast.Number(float(v), line)

        if self._cur().kind == "STRING":
            tok = self._advance()
            return ast.String(str(tok.value), line)

        if self._match("TRUE"):
            return ast.Bool(True, line)

        if self._match("FALSE"):
            return ast.Bool(False, line)

        if self._cur().kind == "IDENT":
            tok = self._advance()
            return ast.Var(str(tok.value), line)

        if self._match("LPAREN"):
            expr = self._expression()
            self._expect("RPAREN", "Hiányzik a záró „)”.")
            return expr

        raise ParseError(
            f"Kifejezés helyett „{t.kind}” áll. Változó, szám vagy „\"szöveg\"”?",
            line=line,
        )


def parse(source: str) -> ast.Program:
    return Parser(tokenize(source)).parse()

"""GitHub Releases alapu frissites-ellenorzes es automatikus telepites."""

from __future__ import annotations

import json
import re
import shutil
import subprocess
import sys
import tempfile
import urllib.error
import urllib.request
import zipfile
from pathlib import Path
from typing import Any

from elpp import __version__


def _parse_version(text: str) -> tuple[int, ...]:
    nums = re.findall(r"\d+", text)
    return tuple(int(n) for n in nums[:3]) if nums else (0,)


def _is_newer(latest: str, current: str) -> bool:
    return _parse_version(latest) > _parse_version(current)


def _find_release_config() -> dict[str, Any]:
    here = Path(__file__).resolve()
    candidates = [
        Path.cwd() / "release.json",
        here.parents[2] / "release.json",
        here.parents[1] / "release.json",
    ]
    for path in candidates:
        if path.is_file():
            try:
                return json.loads(path.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, OSError):
                break
    return {}


def _fetch_latest_release(repo: str) -> dict[str, Any] | None:
    url = f"https://api.github.com/repos/{repo}/releases/latest"
    req = urllib.request.Request(
        url,
        headers={"Accept": "application/vnd.github+json", "User-Agent": "ELplusplus-updater"},
    )
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            if isinstance(data, dict):
                return data
    except (urllib.error.URLError, TimeoutError, json.JSONDecodeError, OSError):
        return None
    return None


def _release_tag(release: dict[str, Any]) -> str | None:
    tag = release.get("tag_name") or release.get("name")
    if isinstance(tag, str):
        return tag.lstrip("v")
    return None


def _find_zip_url(release: dict[str, Any]) -> str | None:
    for asset in release.get("assets") or []:
        if not isinstance(asset, dict):
            continue
        name = str(asset.get("name") or "")
        url = asset.get("browser_download_url")
        if name.lower().endswith(".zip") and isinstance(url, str):
            return url
    return None


def _find_project_root() -> Path | None:
    here = Path(__file__).resolve()
    candidates = [
        Path.cwd(),
        here.parents[2],
        here.parents[1],
    ]
    seen: set[Path] = set()
    for base in candidates:
        try:
            root = base.resolve()
        except OSError:
            continue
        if root in seen:
            continue
        seen.add(root)
        if (root / "install.ps1").is_file() and (root / "pyproject.toml").is_file():
            return root
    return None


def _find_install_root_in(folder: Path) -> Path | None:
    if (folder / "install.ps1").is_file():
        return folder
    for child in folder.iterdir():
        if child.is_dir() and (child / "install.ps1").is_file():
            return child
    return None


def _run_install_ps1(root: Path) -> int:
    ps1 = root / "install.ps1"
    print(f"Telepito futtatasa: {ps1}")
    try:
        proc = subprocess.run(
            [
                "powershell",
                "-NoProfile",
                "-ExecutionPolicy",
                "Bypass",
                "-File",
                str(ps1),
            ],
            cwd=str(root),
            check=False,
        )
        return proc.returncode
    except OSError as e:
        print(f"Hiba a telepito inditasakor: {e}", file=sys.stderr)
        return 1


def _copy_tree_into(src: Path, dest: Path) -> None:
    for item in src.iterdir():
        target = dest / item.name
        if item.is_dir():
            shutil.copytree(item, target, dirs_exist_ok=True)
        else:
            shutil.copy2(item, target)


def _update_via_git(root: Path) -> int:
    print("Git: legujabb valtozatok letoltese...")
    try:
        pull = subprocess.run(["git", "pull"], cwd=str(root), capture_output=True, text=True)
    except OSError:
        print("Git nem erheto el. Probald a ZIP frissitest.", file=sys.stderr)
        return 1
    if pull.returncode != 0:
        print(pull.stderr or pull.stdout or "git pull sikertelen.", file=sys.stderr)
        return 1
    if pull.stdout.strip():
        print(pull.stdout.strip())
    return _run_install_ps1(root)


def _update_via_zip(root: Path, zip_url: str) -> int:
    print("ZIP letoltese a GitHub Releases-rol...")
    try:
        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            zip_path = tmp_path / "elpp-update.zip"
            with urllib.request.urlopen(zip_url, timeout=120) as resp:
                zip_path.write_bytes(resp.read())
            extract = tmp_path / "extracted"
            extract.mkdir()
            with zipfile.ZipFile(zip_path) as zf:
                zf.extractall(extract)
            new_root = _find_install_root_in(extract)
            if not new_root:
                print("Hiba: a ZIP-ben nincs install.ps1.", file=sys.stderr)
                return 1
            print("Fajlok frissitese...")
            _copy_tree_into(new_root, root)
            return _run_install_ps1(root)
    except (urllib.error.URLError, OSError, zipfile.BadZipFile) as e:
        print(f"ZIP frissites sikertelen: {e}", file=sys.stderr)
        return 1


def check_update(*, quiet: bool = False) -> int:
    cfg = _find_release_config()
    repo = (cfg.get("github_repo") or "").strip()
    releases_page = cfg.get("releases_page") or ""

    if not repo:
        if not quiet:
            print("Frissites-figyelo: GitHub repo meg nincs beallitva.")
            if releases_page:
                print(f"  Releases oldal (kesobb): {releases_page}")
            print("  Szerkeszd a release.json fajlt (github_repo mezo).")
        return 0

    release = _fetch_latest_release(repo)
    if not release:
        if not quiet:
            print("Frissites-ellenorzes: nem sikerult lekerdezni a GitHubot.")
        return 1

    latest = _release_tag(release)
    if not latest:
        return 1

    if _is_newer(latest, __version__):
        print(f"Uj EL++ verzio erheto el: v{latest} (telepitett: v{__version__})")
        print("  Frissites: el++ update")
        return 2

    if not quiet:
        print(f"Naprakesz vagy: EL++ v{__version__} (legujabb: v{latest})")
    return 0


def run_update(*, auto: bool = False) -> int:
    cfg = _find_release_config()
    repo = (cfg.get("github_repo") or "").strip()
    releases_page = cfg.get("releases_page") or ""

    if not repo:
        print("Automatikus frissites: allitsd be a release.json github_repo mezot.")
        if releases_page:
            print(f"  {releases_page}")
        return 1

    release = _fetch_latest_release(repo)
    if not release:
        print("Nem sikerult lekerdezni a GitHub Releases-t.", file=sys.stderr)
        return 1

    latest = _release_tag(release)
    if not latest:
        print("A release nem tartalmaz verzioszamot.", file=sys.stderr)
        return 1

    if not _is_newer(latest, __version__):
        print(f"Mar a legujabb verzio fut: v{__version__}")
        return 0

    print(f"Uj verzio: v{latest}  (jelenlegi: v{__version__})")

    if not auto and sys.stdin.isatty():
        try:
            answer = input("Frissitsem most? (i/n): ").strip().casefold()
        except (EOFError, KeyboardInterrupt):
            print()
            return 0
        if answer not in ("i", "igen", "y", "yes"):
            print("Megszakitva. Kesobb: el++ update --yes")
            return 0

    root = _find_project_root()
    if root and (root / ".git").is_dir():
        return _update_via_git(root)

    zip_url = _find_zip_url(release)
    if root and zip_url:
        return _update_via_zip(root, zip_url)

    print("Automatikus frissites nem sikerult ebből a telepitesi modbol.", file=sys.stderr)
    print("  Git clone: git pull + .\\install.ps1", file=sys.stderr)
    if zip_url:
        print(f"  Vagy toltsd le: {zip_url}", file=sys.stderr)
    elif releases_page:
        print(f"  Releases: {releases_page}", file=sys.stderr)
    return 1


def print_update_help() -> int:
    print(f"EL++ frissites (jelenleg: v{__version__})")
    print()
    print("  el++ check-update       ellenorzes")
    print("  el++ update             frissites (kerdez)")
    print("  el++ update --yes       frissites (azonnal)")
    print()
    return 0

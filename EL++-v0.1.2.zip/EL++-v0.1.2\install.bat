@echo off
title EL++ telepites
echo.
echo  EL++ (Easy Language) - telepito
echo  Python, VS Code bovitmeny, ikonok - minden automatikusan.
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
echo.
pause

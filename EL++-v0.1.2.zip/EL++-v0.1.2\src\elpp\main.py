"""CLI és REPL belépési pont."""

from __future__ import annotations

import sys
from pathlib import Path

from elpp import __version__
from elpp.errors import ELPPError
from elpp.interpreter import Interpreter
from elpp.parser import parse
from elpp.updater import check_update, print_update_help, run_update

REPL_EXIT = frozenset({"kilép", "kilep", "exit", "quit", "vége", "vege"})
EL_EXTENSIONS = {".elpp", ".el"}


def _is_el_file(path: Path) -> bool:
    return path.suffix.lower() in EL_EXTENSIONS


def _run_file(path: Path) -> int:
    source = path.read_text(encoding="utf-8")
    try:
        program = parse(source)
        Interpreter().run(program)
    except ELPPError as e:
        print(str(e), file=sys.stderr)
        return 1
    return 0


def _repl() -> int:
    print(f"EL++ (Easy Language) v{__version__} – REPL")
    print('Írj programokat; kilépés: "kilép" vagy "exit".')
    interp = Interpreter()
    buffer: list[str] = []
    block_depth = 0

    while True:
        try:
            prompt = "EL++> " if block_depth == 0 else "  ...> "
            line = input(prompt)
        except (EOFError, KeyboardInterrupt):
            print()
            break

        stripped = line.strip()
        if not buffer and stripped.casefold() in {w.casefold() for w in REPL_EXIT}:
            break

        if not stripped and not buffer:
            continue

        buffer.append(line)

        lower = stripped.casefold()
        if any(
            lower.startswith(s)
            for s in ("ha ", "if ", "amíg", "amig", "while ", "ismételd", "ismeteld", "repeat ")
        ) or lower.endswith(" akkor") or lower.endswith(" then"):
            block_depth += 1
        if any(lower == s for s in ("kész", "kesz", "end", "vége", "vege", "done")):
            block_depth = max(0, block_depth - 1)

        if block_depth == 0 and buffer:
            source = "\n".join(buffer)
            buffer = []
            try:
                program = parse(source)
                interp.run(program)
            except ELPPError as e:
                print(str(e), file=sys.stderr)

    return 0


def _print_help() -> None:
    print(
        f"""EL++ (Easy Language) v{__version__}

Használat:
  el++                         REPL (interaktív) – csak írd be: el++
  el++ fájl.elpp               program futtatása
  el++ run fájl.elpp           program futtatása
  el++ --version               verzió
  el++ check-update            uj verzio kereses (GitHub)
  el++ update                  frissites a legujabb verziora (kerdez)
  el++ update --yes            frissites azonnal

(A régi `.el` kiterjesztés is futtatható. Az `elpp` parancs is.)
"""
    )


def main(argv: list[str] | None = None) -> int:
    args = list(argv if argv is not None else sys.argv[1:])

    if not args:
        return _repl()

    if args[0] in ("-h", "--help"):
        _print_help()
        return 0

    if args[0] in ("--version", "-V"):
        print(f"EL++ {__version__}")
        return 0

    if args[0] in ("check-update", "check-updates", "frissites-ellenorzes"):
        return check_update()

    if args[0] == "update":
        auto = "--yes" in args or "-y" in args
        if "--help" in args or "-h" in args:
            return print_update_help()
        return run_update(auto=auto)

    if args[0] == "run":
        if len(args) < 2:
            print("Hiányzik a fájl: el++ run példa.elpp", file=sys.stderr)
            return 1
        return _run_file(Path(args[1]))

    path = Path(args[0])
    if path.exists() or _is_el_file(path):
        return _run_file(path)

    print(f"Ismeretlen parancs vagy fájl: {args[0]}", file=sys.stderr)
    _print_help()
    return 1


if __name__ == "__main__":
    sys.exit(main())

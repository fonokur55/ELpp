"""Interpreter: AST végrehajtás."""

from __future__ import annotations

import sys
from typing import Any

from elpp import ast
from elpp.errors import RuntimeError, type_error, undefined_variable
from elpp.parser import parse


class Interpreter:
    def __init__(self, stdout: Any = None):
        self.env: dict[str, Any] = {}
        self.stdout = stdout if stdout is not None else sys.stdout

    def run(self, program: ast.Program) -> None:
        for stmt in program.statements:
            self._exec_stmt(stmt)

    def run_source(self, source: str) -> None:
        self.run(parse(source))

    def _exec_stmt(self, stmt: ast.Stmt) -> None:
        if isinstance(stmt, ast.Let):
            self.env[stmt.name] = self._eval(stmt.value)
            return

        if isinstance(stmt, ast.Print):
            parts = [self._format_value(self._eval(e)) for e in stmt.values]
            print(" ".join(parts), file=self.stdout)
            return

        if isinstance(stmt, ast.If):
            if self._truthy(self._eval(stmt.condition)):
                for s in stmt.then_body:
                    self._exec_stmt(s)
            elif stmt.else_body:
                for s in stmt.else_body:
                    self._exec_stmt(s)
            return

        if isinstance(stmt, ast.While):
            while self._truthy(self._eval(stmt.condition)):
                for s in stmt.body:
                    self._exec_stmt(s)
            return

    def _truthy(self, val: Any) -> bool:
        if isinstance(val, bool):
            return val
        if isinstance(val, (int, float)):
            return val != 0
        if isinstance(val, str):
            return len(val) > 0
        return bool(val)

    def _format_value(self, val: Any) -> str:
        if isinstance(val, float) and val == int(val):
            return str(int(val))
        return str(val)

    def _eval(self, expr: ast.Expr) -> Any:
        if isinstance(expr, ast.Number):
            return int(expr.value) if expr.value == int(expr.value) else expr.value

        if isinstance(expr, ast.String):
            return expr.value

        if isinstance(expr, ast.Bool):
            return expr.value

        if isinstance(expr, ast.Var):
            if expr.name not in self.env:
                raise undefined_variable(expr.name, expr.line)
            return self.env[expr.name]

        if isinstance(expr, ast.Unary):
            v = self._eval(expr.operand)
            if expr.op == "NOT":
                return not self._truthy(v)
            if expr.op == "MINUS":
                n = self._as_number(v, expr.line)
                return -n
            raise type_error(f"Ismeretlen egytagú operátor: {expr.op}", expr.line)

        if isinstance(expr, ast.Binary):
            if expr.op in ("AND", "OR"):
                left = self._truthy(self._eval(expr.left))
                if expr.op == "AND":
                    return left and self._truthy(self._eval(expr.right))
                return left or self._truthy(self._eval(expr.right))

            left = self._eval(expr.left)
            right = self._eval(expr.right)

            if expr.op in ("PLUS", "MINUS", "STAR", "SLASH"):
                if isinstance(left, str) or isinstance(right, str):
                    if expr.op == "PLUS":
                        return str(left) + str(right)
                    raise type_error(
                        "Szöveggel csak összefűzés (+) működik.",
                        expr.line,
                    )
                ln = self._as_number(left, expr.line)
                rn = self._as_number(right, expr.line)
                if expr.op == "PLUS":
                    return ln + rn
                if expr.op == "MINUS":
                    return ln - rn
                if expr.op == "STAR":
                    return ln * rn
                if expr.op == "SLASH":
                    if rn == 0:
                        raise type_error("Nullával nem lehet osztani.", expr.line)
                    return ln / rn

            if expr.op in ("EQ", "NE", "LT", "GT", "LE", "GE"):
                return self._compare(expr.op, left, right, expr.line)

        raise type_error("Ismeretlen kifejezés.", getattr(expr, "line", 0))

    def _as_number(self, val: Any, line: int) -> float:
        if isinstance(val, (int, float)):
            return float(val)
        if isinstance(val, bool):
            return 1.0 if val else 0.0
        raise type_error(f"Szám kell, nem: {type(val).__name__}", line)

    def _compare(self, op: str, left: Any, right: Any, line: int) -> bool:
        if isinstance(left, str) and isinstance(right, str):
            ops = {
                "EQ": left == right,
                "NE": left != right,
                "LT": left < right,
                "GT": left > right,
                "LE": left <= right,
                "GE": left >= right,
            }
            return ops[op]

        if isinstance(left, (int, float)) and isinstance(right, (int, float)):
            ops = {
                "EQ": left == right,
                "NE": left != right,
                "LT": left < right,
                "GT": left > right,
                "LE": left <= right,
                "GE": left >= right,
            }
            return ops[op]

        if isinstance(left, bool) and isinstance(right, bool):
            ops = {
                "EQ": left == right,
                "NE": left != right,
            }
            if op in ops:
                return ops[op]

        raise type_error(
            "Összehasonlításnál azonos típus kell (szám, szöveg vagy logikai).",
            line,
        )


def run_source(source: str, stdout: Any = None) -> Interpreter:
    interp = Interpreter(stdout=stdout)
    interp.run_source(source)
    return interp

const vscode = require("vscode");
const { spawn } = require("child_process");

const EL_EXTENSIONS = [".elpp", ".el"];

function isElFile(file) {
  const lower = file.toLowerCase();
  return EL_EXTENSIONS.some((ext) => lower.endsWith(ext));
}

function getExecutable() {
  const cfg = vscode.workspace.getConfiguration("elpp");
  return cfg.get("executable", "el++");
}

function runInTerminal(command, name) {
  const term =
    vscode.window.terminals.find((t) => t.name === name) ||
    vscode.window.createTerminal({ name, iconPath: new vscode.ThemeIcon("play") });
  term.show();
  term.sendText(command);
}

function runFile(uri) {
  const file = uri?.fsPath || vscode.window.activeTextEditor?.document.uri.fsPath;
  if (!file) {
    vscode.window.showWarningMessage("Nincs megnyitott .elpp fájl.");
    return;
  }
  if (!isElFile(file)) {
    vscode.window.showWarningMessage("Csak .elpp (vagy régi .el) fájl futtatható.");
    return;
  }
  const exe = getExecutable();
  runInTerminal(`${exe} "${file}"`, "EL++");
}

function startRepl() {
  runInTerminal(getExecutable(), "EL++ REPL");
}

/** Minimális debug adapter – F5 / Run and Debug panel, el++ futtatás. */
class ELppDebugAdapter {
  constructor() {
    this._onDidSendMessage = new vscode.EventEmitter();
    this.onDidSendMessage = this._onDidSendMessage.event;
    this._seq = 1;
  }

  _send(message) {
    this._onDidSendMessage.fire(message);
  }

  _response(request, body = {}) {
    this._send({
      type: "response",
      seq: this._seq++,
      request_seq: request.seq,
      success: true,
      command: request.command,
      body,
    });
  }

  _event(event, body = {}) {
    this._send({ type: "event", seq: this._seq++, event, body });
  }

  handleMessage(message) {
    switch (message.command) {
      case "initialize":
        this._response(message, {
          supportsConfigurationDoneRequest: true,
          supportsTerminateRequest: true,
        });
        break;

      case "launch": {
        const program = message.arguments.program;
        const exe = getExecutable();
        const child = spawn(exe, [program], {
          shell: true,
          cwd: vscode.workspace.workspaceFolders?.[0]?.uri.fsPath,
        });
        let output = "";
        child.stdout?.on("data", (d) => {
          output += d.toString();
        });
        child.stderr?.on("data", (d) => {
          output += d.toString();
        });
        child.on("close", (code) => {
          if (output.trim()) {
            const ch = vscode.window.createOutputChannel("EL++");
            ch.appendLine(output.trimEnd());
            ch.show(true);
          }
          if (code !== 0) {
            vscode.window.showErrorMessage(`EL++ hiba (kód ${code}). Nézd az Output panelt.`);
          }
          this._event("terminated");
        });
        this._response(message);
        break;
      }

      case "configurationDone":
        this._response(message);
        break;

      case "disconnect":
      case "terminate":
        this._response(message);
        this._event("terminated");
        break;

      default:
        this._response(message);
        break;
    }
  }
}

function activate(context) {
  context.subscriptions.push(
    vscode.commands.registerCommand("elpp.runFile", (uri) => runFile(uri)),
    vscode.commands.registerCommand("elpp.startRepl", () => startRepl()),
    vscode.debug.registerDebugConfigurationProvider("elpp", {
      resolveDebugConfiguration(_folder, config) {
        if (!config.program && vscode.window.activeTextEditor) {
          config.program = vscode.window.activeTextEditor.document.uri.fsPath;
        }
        return config;
      },
    }),
    vscode.debug.registerDebugAdapterDescriptorFactory("elpp", {
      createDebugAdapterDescriptor() {
        return new vscode.DebugAdapterInlineImplementation(new ELppDebugAdapter());
      },
    })
  );
}

function deactivate() {}

module.exports = { activate, deactivate };

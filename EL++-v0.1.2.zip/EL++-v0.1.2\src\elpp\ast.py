"""AST node-ok az EL++ nyelvhez."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Union

# --- Kifejezések ---


@dataclass
class Number:
    value: float
    line: int = 0


@dataclass
class String:
    value: str
    line: int = 0


@dataclass
class Bool:
    value: bool
    line: int = 0


@dataclass
class Var:
    name: str
    line: int = 0


@dataclass
class Unary:
    op: str  # NOT, MINUS
    operand: Expr
    line: int = 0


@dataclass
class Binary:
    op: str  # PLUS, MINUS, STAR, SLASH, EQ, NE, LT, GT, LE, GE, AND, OR
    left: Expr
    right: Expr
    line: int = 0


Expr = Union[Number, String, Bool, Var, Unary, Binary]

# --- Utasítások ---


@dataclass
class Let:
    name: str
    value: Expr
    line: int = 0


@dataclass
class Print:
    values: list[Expr]
    line: int = 0


@dataclass
class If:
    condition: Expr
    then_body: list[Stmt]
    else_body: list[Stmt] | None = None
    line: int = 0


@dataclass
class While:
    condition: Expr
    body: list[Stmt]
    line: int = 0


Stmt = Union[Let, Print, If, While]


@dataclass
class Program:
    statements: list[Stmt] = field(default_factory=list)

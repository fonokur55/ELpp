# EL++ – egy parancsos telepítés (Windows PowerShell)
# Használat:  .\install.ps1   vagy   install.bat
$ErrorActionPreference = "Stop"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$Root = $PSScriptRoot
Set-Location $Root

Write-Host ""
Write-Host "  EL++ (Easy Language) telepitese..." -ForegroundColor Cyan
Write-Host ""

function Refresh-SessionPath {
    $machine = [Environment]::GetEnvironmentVariable("Path", "Machine")
    $user = [Environment]::GetEnvironmentVariable("Path", "User")
    $env:Path = "$machine;$user"
}

function Test-PythonReady {
    foreach ($exe in @("python", "py")) {
        $cmd = Get-Command $exe -ErrorAction SilentlyContinue
        if (-not $cmd) { continue }
        if ($exe -eq "py") {
            $ok = & py -3 -c "import sys; raise SystemExit(0 if sys.version_info >= (3,11) else 1)" 2>$null
        } else {
            $ok = & python -c "import sys; raise SystemExit(0 if sys.version_info >= (3,11) else 1)" 2>$null
        }
        if ($LASTEXITCODE -eq 0) { return $true }
    }
    foreach ($p in @(
        "$env:LocalAppData\Programs\Python\Python313\python.exe",
        "$env:LocalAppData\Programs\Python\Python312\python.exe",
        "$env:LocalAppData\Programs\Python\Python311\python.exe"
    )) {
        if (Test-Path $p) {
            $env:Path = "$(Split-Path $p -Parent);$env:Path"
            return $true
        }
    }
    return $false
}

function Get-PythonCmd {
    if (Get-Command python -ErrorAction SilentlyContinue) {
        $ok = & python -c "import sys; raise SystemExit(0 if sys.version_info >= (3,11) else 1)" 2>$null
        if ($LASTEXITCODE -eq 0) { return "python" }
    }
    if (Get-Command py -ErrorAction SilentlyContinue) {
        $ok = & py -3 -c "import sys; raise SystemExit(0 if sys.version_info >= (3,11) else 1)" 2>$null
        if ($LASTEXITCODE -eq 0) { return "py -3" }
    }
    return $null
}

function Install-PythonAuto {
    Write-Host "  Python nincs telepitve (vagy regi). Automatikus telepites..." -ForegroundColor Yellow

    $winget = Get-Command winget -ErrorAction SilentlyContinue
    if ($winget) {
        Write-Host "  Probalom a winget-et (Python 3.13)..." -ForegroundColor Cyan
        $oldEap = $ErrorActionPreference
        $ErrorActionPreference = "Continue"
        & winget install -e --id Python.Python.3.13 `
            --accept-package-agreements --accept-source-agreements `
            --disable-interactivity 2>&1 | Out-Null
        $ErrorActionPreference = $oldEap
        Refresh-SessionPath
        if (Test-PythonReady) {
            Write-Host "  + Python telepitve (winget)." -ForegroundColor Green
            return
        }
    }

    Write-Host "  Letoltes a python.org-rol (1-2 perc)..." -ForegroundColor Cyan
    $installer = Join-Path $env:TEMP "elpp-python-installer.exe"
    $urls = @(
        "https://www.python.org/ftp/python/3.13.3/python-3.13.3-amd64.exe",
        "https://www.python.org/ftp/python/3.12.10/python-3.12.10-amd64.exe"
    )
    $downloaded = $false
    foreach ($url in $urls) {
        try {
            Invoke-WebRequest -Uri $url -OutFile $installer -UseBasicParsing -TimeoutSec 120
            $downloaded = $true
            break
        } catch {
            continue
        }
    }
    if (-not $downloaded) {
        Write-Host "  Hiba: Python letoltes sikertelen. Telepits kezzel: https://www.python.org/downloads/" -ForegroundColor Red
        Write-Host "  Pipald be: Add Python to PATH" -ForegroundColor Yellow
        exit 1
    }

    Write-Host "  Telepites (csendes mod, PATH hozzaadva)..." -ForegroundColor Cyan
    $args = @(
        "/quiet", "InstallAllUsers=0", "PrependPath=1",
        "Include_pip=1", "Include_launcher=1", "SimpleInstall=1"
    )
    $proc = Start-Process -FilePath $installer -ArgumentList $args -Wait -PassThru
    Remove-Item $installer -Force -ErrorAction SilentlyContinue
    Refresh-SessionPath
    Start-Sleep -Seconds 2

    if (-not (Test-PythonReady)) {
        Write-Host "  Python telepitve lehet, de uj terminál kell. Indits uj PowerShell ablakot, futtasd ujra az install.bat-ot." -ForegroundColor Yellow
        exit 1
    }
    Write-Host "  + Python telepitve." -ForegroundColor Green
}

if (-not (Test-PythonReady)) {
    Install-PythonAuto
}

$python = Get-PythonCmd
if (-not $python) {
    Write-Host "Hiba: Python 3.11+ nem talalhato telepites utan sem." -ForegroundColor Red
    exit 1
}

Write-Host "  Python: OK ($python)" -ForegroundColor Green

Invoke-Expression "$python -m pip install --upgrade pip -q" 2>$null
Invoke-Expression "$python -m pip install -e `"$Root`" -q --no-warn-script-location"
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

function Add-ToUserPath([string]$folder) {
    if (-not $folder -or -not (Test-Path $folder)) { return }
    $current = [Environment]::GetEnvironmentVariable("Path", "User")
    if (-not $current) { $current = "" }
    if ($current -notlike "*$folder*") {
        [Environment]::SetEnvironmentVariable("Path", "$current;$folder", "User")
        $env:Path = "$env:Path;$folder"
        Write-Host "  + PATH: $folder" -ForegroundColor Green
    }
}

$scripts = Invoke-Expression "$python -c `"import site, os; print(os.path.join(site.USER_BASE, 'Scripts'))`""
Add-ToUserPath $scripts

$cmdDir = Join-Path $env:LOCALAPPDATA "ELplusplus"
New-Item -ItemType Directory -Force -Path $cmdDir | Out-Null
$wrapper = Join-Path $cmdDir "el++.cmd"
$pyLauncher = if ($python -eq "py -3") { "py -3" } else { "python" }
@"
@echo off
$pyLauncher -m elpp %*
"@ | Set-Content -Path $wrapper -Encoding ASCII
Add-ToUserPath $cmdDir

$iconSrc = Join-Path $Root "EL++.png"
$icoPath = Join-Path $cmdDir "el.ico"
if (Test-Path $iconSrc) {
    Write-Host "  Windows .elpp fajl ikon beallitasa..." -ForegroundColor Cyan
    $buildIcon = Join-Path $Root "scripts\build_icon.py"
    if (Test-Path $buildIcon) {
        & $python $buildIcon $iconSrc $icoPath 2>$null
    } else {
        Invoke-Expression "$python -c `"from pathlib import Path; from PIL import Image; s=Path(r'$iconSrc'); d=Path(r'$icoPath'); im=Image.open(s).convert('RGBA'); im.save(d, format='ICO', sizes=[(16,16),(32,32),(48,48),(256,256)]); print('ico ok')`"" 2>$null
    }
    if (Test-Path $icoPath) {
        . (Join-Path $Root "Register-ElppWindows.ps1")
        $ok = Register-ElppWindowsAssociation -IcoPath $icoPath -WrapperPath $wrapper
        if ($ok) {
            Write-Host "  + Windows Intezo: .elpp fajlok -> tehen ikon (.ico)" -ForegroundColor Green
            Write-Host "    Ha meg feher: .\refresh-icons.ps1" -ForegroundColor DarkGray
        }
    }
}

Write-Host ""
Write-Host "  Terminal: uj ablak utan  el++  -> REPL" -ForegroundColor Green
Write-Host ""

$extDir = Join-Path $Root "vscode-elpp"
$vsix = Join-Path $extDir "elpp-language-0.1.2.vsix"
$iconDst = Join-Path $extDir "icon.png"

if (Test-Path $iconSrc) {
    Invoke-Expression "$python -c `"from pathlib import Path; from PIL import Image; src=Path(r'$iconSrc'); dst=Path(r'$iconDst'); im=Image.open(src).convert('RGBA'); im.resize((128,128), Image.Resampling.LANCZOS).save(dst, format='PNG')`"" 2>$null
    if (-not (Test-Path $iconDst)) { Copy-Item -Force $iconSrc $iconDst }
}

$npx = Get-Command npx -ErrorAction SilentlyContinue
if ($npx -and (Test-Path $extDir)) {
    Write-Host "  VS Code bovitmeny csomagolasa (.vsix)..." -ForegroundColor Cyan
    Push-Location $extDir
    $oldEap = $ErrorActionPreference
    $ErrorActionPreference = "Continue"
    try {
        & npx --yes @vscode/vsce package --allow-missing-repository --out $vsix 2>&1 | Out-Null
    } finally {
        $ErrorActionPreference = $oldEap
        Pop-Location
        Set-Location $Root
    }
}

if (Test-Path $vsix) {
    Write-Host "  VSIX kesz." -ForegroundColor Green
    $code = Get-Command code -ErrorAction SilentlyContinue
    if ($code) {
        Write-Host "  Telepites VS Code-ba..." -ForegroundColor Cyan
        & code --install-extension $vsix --force 2>&1 | Out-Null
        if ($LASTEXITCODE -eq 0) {
            Write-Host "  + EL++ bovitmeny telepitve a VS Code-ba!" -ForegroundColor Green
        }
    }
} else {
    Write-Host "  ! VSIX hianyzik (Node nelkul is mehet, ha mar a mappaban van)." -ForegroundColor Yellow
}

Write-Host ""
Write-Host "  Telepites keszen!" -ForegroundColor Green
Write-Host "  VS Code: Ctrl+Shift+P -> Developer: Reload Window" -ForegroundColor Cyan
Write-Host ""
Invoke-Expression "$python -m elpp --version"
Write-Host ""
Write-Host "  Frissites ellenorzes:" -ForegroundColor Cyan
Invoke-Expression "$python -m elpp check-update" 2>$null
Write-Host ""

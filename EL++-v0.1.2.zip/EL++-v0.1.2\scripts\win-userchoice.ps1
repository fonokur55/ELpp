# Windows 10/11 UserChoice hash – alapertelmezett fajltarsitas beallitasa.
# Hash algoritmus: PS-SFTA (MIT) – https://github.com/DanysysTeam/PS-SFTA

function Remove-ProtectedUserChoiceKey {
    param([Parameter(Mandatory = $true)][string]$Key)

    if (-not ("Registry.Utils" -as [type])) {
        Add-Type @"
using System;
using System.Runtime.InteropServices;
namespace Registry {
public class Utils {
    [DllImport("advapi32.dll", SetLastError = true)]
    private static extern int RegOpenKeyEx(UIntPtr hKey, string subKey, int ulOptions, int samDesired, out UIntPtr hkResult);
    [DllImport("advapi32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
    private static extern uint RegDeleteKey(UIntPtr hKey, string subKey);
    public static void DeleteKey(string key) {
        UIntPtr hKey = UIntPtr.Zero;
        RegOpenKeyEx((UIntPtr)0x80000001u, key, 0, 0x20019, out hKey);
        RegDeleteKey((UIntPtr)0x80000001u, key);
    }
}
}
"@
    }
    try { [Registry.Utils]::DeleteKey($Key) } catch {}
}

function Get-ElppUserExperienceString {
    $search = "User Choice set via Windows User Experience"
    $fallback = "User Choice set via Windows User Experience {D18B6DD5-6124-4341-9318-804003BAFA0B}"
    $shell32 = Join-Path ([Environment]::GetFolderPath([Environment+SpecialFolder]::SystemX86)) "Shell32.dll"
    try {
        $stream = [System.IO.File]::Open($shell32, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, [System.IO.FileShare]::ReadWrite)
        $reader = New-Object System.IO.BinaryReader($stream)
        $bytes = $reader.ReadBytes(5mb)
        $stream.Close()
        $text = [Text.Encoding]::Unicode.GetString($bytes)
        $start = $text.IndexOf($search)
        $end = $text.IndexOf("}", $start)
        return $text.Substring($start, $end - $start + 1)
    } catch {
        return $fallback
    }
}

function Get-ElppUserChoiceHash {
    param([Parameter(Mandatory = $true)][string]$BaseInfo)

    function Get-ShiftRight([long]$Value, [int]$Count) {
        if ($Value -band 0x80000000) { return (( $Value -shr $Count) -bxor 0xFFFF0000) }
        return ($Value -shr $Count)
    }
    function Get-LongFromBytes([byte[]]$Bytes, [int]$Index = 0) {
        return [BitConverter]::ToInt32($Bytes, $Index)
    }
    function Convert-Int32Long([long]$Value) {
        return [BitConverter]::ToInt32([BitConverter]::GetBytes($Value), 0)
    }

    [Byte[]]$bytesBaseInfo = [System.Text.Encoding]::Unicode.GetBytes($BaseInfo)
    $bytesBaseInfo += 0x00, 0x00
    $md5 = [System.Security.Cryptography.MD5]::Create()
    [Byte[]]$bytesMD5 = $md5.ComputeHash($bytesBaseInfo)

    $lengthBase = ($BaseInfo.Length * 2) + 2
    $length = (($lengthBase -band 4) -le 1) + (Get-ShiftRight $lengthBase 2) - 1
    $base64Hash = ""

    if ($length -gt 1) {
        $map = @{
            PDATA = 0; CACHE = 0; COUNTER = 0; INDEX = 0; MD51 = 0; MD52 = 0
            OUTHASH1 = 0; OUTHASH2 = 0; R0 = 0
            R1 = @(0, 0); R2 = @(0, 0); R3 = 0; R4 = @(0, 0); R5 = @(0, 0); R6 = @(0, 0)
        }
        $map.CACHE = 0; $map.OUTHASH1 = 0; $map.PDATA = 0
        $map.MD51 = (((Get-LongFromBytes $bytesMD5) -bor 1) + 0x69FB0000L)
        $map.MD52 = ((Get-LongFromBytes $bytesMD5 4) -bor 1) + 0x13DB0000L
        $map.INDEX = Get-ShiftRight ($length - 2) 1
        $map.COUNTER = $map.INDEX + 1
        while ($map.COUNTER) {
            $map.R0 = Convert-Int32Long ((Get-LongFromBytes $bytesBaseInfo $map.PDATA) + [long]$map.OUTHASH1)
            $map.R1[0] = Convert-Int32Long (Get-LongFromBytes $bytesBaseInfo ($map.PDATA + 4))
            $map.PDATA = $map.PDATA + 8
            $map.R2[0] = Convert-Int32Long (($map.R0 * ([long]$map.MD51)) - (0x10FA9605L * ((Get-ShiftRight $map.R0 16))))
            $map.R2[1] = Convert-Int32Long ((0x79F8A395L * ([long]$map.R2[0])) + (0x689B6B9FL * (Get-ShiftRight $map.R2[0] 16)))
            $map.R3 = Convert-Int32Long ((0xEA970001L * $map.R2[1]) - (0x3C101569L * (Get-ShiftRight $map.R2[1] 16)))
            $map.R4[0] = Convert-Int32Long ($map.R3 + $map.R1[0])
            $map.R5[0] = Convert-Int32Long ($map.CACHE + $map.R3)
            $map.R6[0] = Convert-Int32Long (($map.R4[0] * [long]$map.MD52) - (0x3CE8EC25L * (Get-ShiftRight $map.R4[0] 16)))
            $map.R6[1] = Convert-Int32Long ((0x59C3AF2DL * $map.R6[0]) - (0x2232E0F1L * (Get-ShiftRight $map.R6[0] 16)))
            $map.OUTHASH1 = Convert-Int32Long ((0x1EC90001L * $map.R6[1]) + (0x35BD1EC9L * (Get-ShiftRight $map.R6[1] 16)))
            $map.OUTHASH2 = Convert-Int32Long ([long]$map.R5[0] + [long]$map.OUTHASH1)
            $map.CACHE = [long]$map.OUTHASH2
            $map.COUNTER = $map.COUNTER - 1
        }
        [Byte[]]$outHash = @(0) * 16
        [BitConverter]::GetBytes($map.OUTHASH1).CopyTo($outHash, 0)
        [BitConverter]::GetBytes($map.OUTHASH2).CopyTo($outHash, 4)

        $map = @{
            PDATA = 0; CACHE = 0; COUNTER = 0; INDEX = 0; MD51 = 0; MD52 = 0
            OUTHASH1 = 0; OUTHASH2 = 0; R0 = 0
            R1 = @(0, 0); R2 = @(0, 0); R3 = 0; R4 = @(0, 0); R5 = @(0, 0)
        }
        $map.CACHE = 0; $map.OUTHASH1 = 0; $map.PDATA = 0
        $map.MD51 = ((Get-LongFromBytes $bytesMD5) -bor 1)
        $map.MD52 = ((Get-LongFromBytes $bytesMD5 4) -bor 1)
        $map.INDEX = Get-ShiftRight ($length - 2) 1
        $map.COUNTER = $map.INDEX + 1
        while ($map.COUNTER) {
            $map.R0 = Convert-Int32Long ((Get-LongFromBytes $bytesBaseInfo $map.PDATA) + ([long]$map.OUTHASH1))
            $map.PDATA = $map.PDATA + 8
            $map.R1[0] = Convert-Int32Long ($map.R0 * [long]$map.MD51)
            $map.R1[1] = Convert-Int32Long ((0xB1110000L * $map.R1[0]) - (0x30674EEFL * (Get-ShiftRight $map.R1[0] 16)))
            $map.R2[0] = Convert-Int32Long ((0x5B9F0000L * $map.R1[1]) - (0x78F7A461L * (Get-ShiftRight $map.R1[1] 16)))
            $map.R2[1] = Convert-Int32Long ((0x12CEB96DL * (Get-ShiftRight $map.R2[0] 16)) - (0x46930000L * $map.R2[0]))
            $map.R3 = Convert-Int32Long ((0x1D830000L * $map.R2[1]) + (0x257E1D83L * (Get-ShiftRight $map.R2[1] 16)))
            $map.R4[0] = Convert-Int32Long ([long]$map.MD52 * ([long]$map.R3 + (Get-LongFromBytes $bytesBaseInfo ($map.PDATA - 4))))
            $map.R4[1] = Convert-Int32Long ((0x16F50000L * $map.R4[0]) - (0x5D8BE90BL * (Get-ShiftRight $map.R4[0] 16)))
            $map.R5[0] = Convert-Int32Long ((0x96FF0000L * $map.R4[1]) - (0x2C7C6901L * (Get-ShiftRight $map.R4[1] 16)))
            $map.R5[1] = Convert-Int32Long ((0x2B890000L * $map.R5[0]) + (0x7C932B89L * (Get-ShiftRight $map.R5[0] 16)))
            $map.OUTHASH1 = Convert-Int32Long ((0x9F690000L * $map.R5[1]) - (0x405B6097L * (Get-ShiftRight $map.R5[1] 16)))
            $map.OUTHASH2 = Convert-Int32Long ([long]$map.OUTHASH1 + $map.CACHE + $map.R3)
            $map.CACHE = [long]$map.OUTHASH2
            $map.COUNTER = $map.COUNTER - 1
        }
        [BitConverter]::GetBytes($map.OUTHASH1).CopyTo($outHash, 8)
        [BitConverter]::GetBytes($map.OUTHASH2).CopyTo($outHash, 12)
        [Byte[]]$outHashBase = @(0) * 8
        $hashValue1 = ((Get-LongFromBytes $outHash 8) -bxor (Get-LongFromBytes $outHash))
        $hashValue2 = ((Get-LongFromBytes $outHash 12) -bxor (Get-LongFromBytes $outHash 4))
        [BitConverter]::GetBytes($hashValue1).CopyTo($outHashBase, 0)
        [BitConverter]::GetBytes($hashValue2).CopyTo($outHashBase, 4)
        $base64Hash = [Convert]::ToBase64String($outHashBase)
    }
    return $base64Hash
}

function Set-ElppDefaultFileAssociation {
    param(
        [Parameter(Mandatory = $true)][string]$Extension,
        [Parameter(Mandatory = $true)][string]$ProgId
    )

    if (-not $Extension.StartsWith(".")) { $Extension = ".$Extension" }

    $userSid = (
        (New-Object System.Security.Principal.NTAccount([Environment]::UserName)).Translate(
            [System.Security.Principal.SecurityIdentifier]
        ).Value
    ).ToLower()
    $userExperience = Get-ElppUserExperienceString
    $now = [DateTime]::Now
    $dateTime = [DateTime]::New($now.Year, $now.Month, $now.Day, $now.Hour, $now.Minute, 0)
    $fileTime = $dateTime.ToFileTime()
    $hi = ($fileTime -shr 32)
    $low = ($fileTime -band 0xFFFFFFFFL)
    $userDateTime = ($hi.ToString("X8") + $low.ToString("X8")).ToLower()

    $baseInfo = "$Extension$userSid$ProgId$userDateTime$userExperience".ToLower()
    $progHash = Get-ElppUserChoiceHash -BaseInfo $baseInfo

    $toastKey = "HKCU:\Software\Microsoft\Windows\CurrentVersion\ApplicationAssociationToasts"
    if (-not (Test-Path $toastKey)) { New-Item -Path $toastKey -Force | Out-Null }
    Set-ItemProperty -Path $toastKey -Name "${ProgId}_${Extension}" -Value 0 -Type DWord -Force

    $openWithKey = "HKCU:\Software\Classes\$Extension\OpenWithProgids"
    if (-not (Test-Path $openWithKey)) { New-Item -Path $openWithKey -Force | Out-Null }
    [Microsoft.Win32.Registry]::SetValue(
        "HKEY_CURRENT_USER\SOFTWARE\Classes\$Extension\OpenWithProgids",
        $ProgId,
        ([byte[]]@()),
        [Microsoft.Win32.RegistryValueKind]::None
    )

    $userChoiceKey = "Software\Microsoft\Windows\CurrentVersion\Explorer\FileExts\$Extension\UserChoice"
    Remove-ProtectedUserChoiceKey -Key $userChoiceKey
    [Microsoft.Win32.Registry]::SetValue("HKEY_CURRENT_USER\$userChoiceKey", "Hash", $progHash)
    [Microsoft.Win32.Registry]::SetValue("HKEY_CURRENT_USER\$userChoiceKey", "ProgId", $ProgId)

    return $true
}

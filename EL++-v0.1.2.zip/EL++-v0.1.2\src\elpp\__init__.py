"""EL++ (Easy Language) – természetes magyar/angol programozási nyelv."""

__version__ = "0.1.2"

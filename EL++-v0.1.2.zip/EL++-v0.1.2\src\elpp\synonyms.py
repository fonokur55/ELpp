"""HU/EN kulcsszavak és szinonimák → belső token nevek."""

from __future__ import annotations

# Belső token típusok (a lexer Token.kind mezőjében)
TOKEN_KINDS = (
    "LET", "IF", "THEN", "ELSE", "END", "WHILE", "PRINT",
    "EQ", "NE", "LT", "GT", "LE", "GE",
    "AND", "OR", "NOT",
    "PLUS", "MINUS", "STAR", "SLASH",
    "LPAREN", "RPAREN",
    "TRUE", "FALSE",
    "NUMBER", "STRING", "IDENT",
    "NEWLINE", "EOF",
)

# Töltőszavak – a lexer kihagyja őket
# Megjegyzés: „a” / „an” nincs itt – ütközhet változónévvel (pl. set a to 1).
FILLER_WORDS: frozenset[str] = frozenset({
    "az", "the", "hogy", "that",
    "valamint", "also", "pedig",
})

# Többszavas kulcsszók: leghosszabb illeszkedés előbb (rendezve hossz szerint csökkenő)
_PHRASES: list[tuple[str, str]] = [
    # WHILE
    ("ismételd amíg", "WHILE"),
    ("repeat while", "WHILE"),
    ("amíg", "WHILE"),
    ("while", "WHILE"),
    # PRINT
    ("írd ki", "PRINT"),
    ("ird ki", "PRINT"),
    ("mutasd", "PRINT"),
    ("print", "PRINT"),
    ("show", "PRINT"),
    ("say", "PRINT"),
    # Comparisons (hosszú előbb)
    ("nagyobb egyen", "GE"),
    ("greater than or equal", "GE"),
    ("greater than or equal to", "GE"),
    ("at least", "GE"),
    ("legalább", "GE"),
    ("kisebb egyen", "LE"),
    ("less than or equal", "LE"),
    ("less than or equal to", "LE"),
    ("at most", "LE"),
    ("legfeljebb", "LE"),
    ("nagyobb mint", "GT"),
    ("greater than", "GT"),
    ("is above", "GT"),
    ("kisebb mint", "LT"),
    ("less than", "LT"),
    ("is below", "LT"),
    ("nem egyen", "NE"),
    ("not equal to", "NE"),
    ("not equal", "NE"),
    ("does not equal", "NE"),
    # LET
    ("állítsd be", "LET"),
    ("allitsd be", "LET"),
    ("legyen", "LET"),
    ("állíts", "LET"),
    ("allits", "LET"),
    ("tegyük", "LET"),
    ("tegyuk", "LET"),
    ("make", "LET"),
    ("let", "LET"),
    ("set", "LET"),
    # IF / THEN / ELSE / END
    ("amennyiben", "IF"),
    ("ha", "IF"),
    ("when", "IF"),
    ("if", "IF"),
    ("akkor", "THEN"),
    ("then", "THEN"),
    ("egyébként", "ELSE"),
    ("egyebkent", "ELSE"),
    ("különben", "ELSE"),
    ("kulonben", "ELSE"),
    ("otherwise", "ELSE"),
    ("else", "ELSE"),
    ("vége", "END"),
    ("vege", "END"),
    ("kész", "END"),
    ("kesz", "END"),
    ("done", "END"),
    ("end", "END"),
    # EQ (kontextus: értékadás / összehasonlítás)
    ("egyenlő", "EQ"),
    ("egyenlo", "EQ"),
    ("egyen", "EQ"),
    ("equals", "EQ"),
    ("equal to", "EQ"),
    ("equal", "EQ"),
    # AND / OR / NOT
    ("valamint", "AND"),  # also filler – only keyword when between exprs; lexer treats as AND if not skipped... skip valamint as filler only
    ("és", "AND"),
    ("and", "AND"),
    ("vagy", "OR"),
    ("or", "OR"),
    ("nem", "NOT"),
    ("not", "NOT"),
    # Boolean literals
    ("hamis", "FALSE"),
    ("false", "FALSE"),
    ("igaz", "TRUE"),
    ("true", "TRUE"),
    # "to" / "is" – angol mintákban
    ("to", "EQ"),
    ("is", "EQ"),
]

# Rendezés: leghosszabb kifejezés először
PHRASE_TO_KIND: list[tuple[str, str]] = sorted(
    _PHRASES, key=lambda p: len(p[0]), reverse=True
)

# Egyszerű szimbólumok
SYMBOLS: dict[str, str] = {
    "+": "PLUS",
    "-": "MINUS",
    "*": "STAR",
    "/": "SLASH",
    "(": "LPAREN",
    ")": "RPAREN",
    "<=": "LE",
    ">=": "GE",
    "<": "LT",
    ">": "GT",
    "==": "EQ",
    "!=": "NE",
}

# Komment kezdők (soron belül a maradék komment)
COMMENT_STARTERS: tuple[str, ...] = ("#", "//", "megjegyzés:", "megjegyzes:", "note:")

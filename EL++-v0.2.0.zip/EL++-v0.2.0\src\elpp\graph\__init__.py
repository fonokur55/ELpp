"""Számítási gráf futtató."""

from elpp.graph.runtime import GraphExecutor

__all__ = ["GraphExecutor"]

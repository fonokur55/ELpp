"""TudatRuntime: egy `tudat` deklaráció instanciált, állapotos futtatása.

Phase 1 / M2: a hiedelmek tényezőit evaluálja és aggregálja, állapotot tart
súlyokról, célokról, kontextusról. Explicit `compute_belief(name)` hívás.

Phase 1 / M3: ÉLET — eseményvezérelt + reaktív + szelektíven aktiváló.
    - `észlel(**inputs)` → context update + reaktív újraszámolás
    - Statikus függőség-analízis: minden hiedelem ismeri, mire hivatkozik
    - Csak a változott bemenetektől (transitíve) függő hiedelmek frissülnek
    - `activate_area()` / `deactivate_area()` → szelektív aktiváció;
      inaktív területek hiedelmei átugorva (Phase 1 / 4. döntés)

Phase 1 / M4: ÖNREFLEXIÓ — a tudat magyarázza önmagát.
    - `magyarázd(belief_name)` → Explanation objektum (str-able, gazdag)
    - `reflektál(label)` → egy reflexió-blokk futtatása (Explanation lista)
    - `list_reflections()` → deklarált reflexió-címkék

Phase 1 / M5: TANULÁS — a tudat frissíti paramétereit hiba alapján.
    - `tanulj(belief_name=target, ..., tanulási_ráta=...)`
    - Algoritmus: hibafelelősség-eloszlás Bayes-aggregátum gradiense szerint
    - Frissít: súly-tenzorok (numerikus gradient), szabály-súlyok,
      cél-súlyok. Hiedelem-tényezők közvetlenül NEM (a forrás-hiedelem
      a saját jeléből tanul).

Phase 2 / M2.1: HIPOTETIKUS — a tudat alternatívákat képzel.
    - `mi_lenne_ha("címke")` → nevesített forgatókönyv futtatása
    - `mi_lenne_ha(**overrides)` → ad-hoc Python API
    - 4-féle felülírás: súly, context, cél, hiedelem (utóbbi BYPASS)
    - PURE: snapshot → apply → recompute → action → restore

Phase 2 / M2.2: META-BIZONYTALANSÁG — a tudat tudja, mit nem tud.
    - `BeliefState.meta_uncertainty` — epistemikus bizonytalanság [0, 1]
    - Számítás: α × 1/(1+n) + (1-α) × min(1, 2·std(factor_values))
    - α konfigurálható (alapérték 0.5)
    - Nincs tényező → 1.0, hiedelem-override → 0.0
    - Megjelenik az Explanation-ben + `rt.meta_bizonytalanság(name)` API

Phase 2 / M2.3: ELLENTMONDÁS — a tudat felismeri a belső konfliktust.
    - `feszültség(name)` = max(értékek) − min(értékek) [0, 1]
    - `ellentmondások(name, küszöb)` → list[Conflict] párokkal
    - Conflict = két FactorTrace + távolság
    - PASSZÍV: csak jelez, nem módosítja az aggregálást
    - Auto figyelmeztetés Explanation-ben ha feszültség > küszöb

Phase 3 / M3.1: MEGLEPETÉS-VEZÉRELT FELFEDEZÉS — a tudat magától struktúrálódik.
    - Opt-in: `rt.felfedezés_engedélyezve = True` (default False)
    - Ha `|error| > meglepetés_küszöb` (default 0.3), új neurális
      tényezőt javasol egy nem-használt context-változóra
    - Auto-súlyok: `auto_W_N` (egyedi nevek), kis kezdő-súllyal
    - Max 10 javaslat/hiedelem (configurable)
    - Magyarázható: minden auto-tényező metadatában lévő step + context_var

Phase 3 / M3.2: TANULT TERÜLETAKTIVÁCIÓ (ROUTING) — Mixture of Experts.
    - Opt-in: `rt.tanult_routing = True` (default False)
    - Routing-súlyok minden (cél, terület) párra (default 0.5)
    - Aktiváció: max(goal.aktiváció × routing_súly(goal, area)) > küszöb
    - Kézi `activate_area`/`deactivate_area` FELÜLÍRJA a routingot
    - Tanulás: `Δw = rate × hibajavulás × goal.aktiváció` aktív területekre

Phase 4 / M4.1: TENZOR-MŰVELETEK — valós ML kifejezhető.
    - ElTensor érték az evaluátorban (lista-literál, súly-annotáció)
    - Broadcasting (+, -, *, /), `pont`/`dot`/`matmul`
    - `súly W : tenzor[n, m]` → kis random init
    - Multi-element súly tanulás elemenkénti numerikus gradient-tel

Phase 4 / M4.2: EPIZODIKUS EMLÉKEZET — a tudat emlékszik.
    - DEFAULT ON (passzív megfigyelés)
    - 5 eseménytípus: meglepetés, felfedezés, tanulás, routing, észlelés
    - FIFO cap (default 1000)
    - `rt.emlékek(típus=, hiedelem=, n=)` lekérdezhető
    - Phase 4-ben nem hat a futtatásra — csak log

Phase 5 / M5.1: PERSISTENCE — a tudat mentődik és visszatölthető.
    - `rt.ments(útvonal)` — minden állapotot pickle-be ment
    - `TudatRuntime.betölt(útvonal)` — visszaállítás
    - id(factor)-kulcsú dictek (belief_name, factor_index)-kulcsra átalakítva
    - Verzió-string a kompatibilitásért

Phase 5 / M5.2: FIT + METRIKÁK — adat-alapú tanítás és értékelés.
    - `rt.fit(adatok, célok={belief: oszlop, ...}, epochok=N)`
      Iterálja az adatot, automatikus észlel+tanulj minden sornál.
      Pandas DataFrame opcionálisan támogatott.
    - `rt.értékelés(test_adatok, célok=...)` → {belief: {pontosság, MAE, MSE}}

Phase 5 / M5.3: TANULÁSI KÖVETÉS — vizuális visszajelzés.
    - `rt.tanulási_görbe(hiedelem=...)` → list[(step, |hiba|)]
    - `rt.tanulási_görbe_szöveg(hiedelem=...)` → ASCII sparkline
    - `splitt(adatok, arány=0.8)` modul-szintű train/test split segéd

Phase 5 / M5.4: MULTI-CLASS + AKTIVÁCIÓK — realisztikus klasszifikáció.
    - `rt.legjobb_osztály([nevek])` → (név, confidence)
    - `rt.osztály_valószínűségek([nevek], normalizálás="softmax")` → dict
    - sigmoid(x), tanh(x), relu(x) builtin a tényező-kifejezésekben
"""

from __future__ import annotations

import math
import pickle
import random
from collections import deque
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterator


# M5.1: persistence formátum verzió. Növelni kell, ha a save-formátum tör.
# M6.5: 2.0 — szöveg-tényezők (szótár + kódoló) is mentődnek.
# M7.5: 2.1 — a kifejezés-paletta (beszéd) is része az állapotnak.
# A betöltő visszafelé kompatibilis: a régebbi mentésekben hiányzó (újabb)
# mezőket a __setstate__ alapértelmezetten kezeli / újraépíti.
PERSISTENCE_VERSION = "2.1"
# D8 (backward-compat): ezeket a korábbi formátumokat is be tudjuk tölteni.
KOMPATIBILIS_VERZIÓK = frozenset({"1.0", "2.0", "2.1"})

from elpp import ast as base_ast
from elpp.runtime_values import ElTensor
from elpp.tudat import ast as tudat_ast
from elpp.tudat.factors import (
    GOAL_DEFAULT_WEIGHT,
    _eval_expr,  # M5: numerikus gradiens-számoláshoz kell
    aggregate,
    describe_factor,
    evaluate_factor,
)
from elpp.tudat.szoveg import DictForrás, FragmentForrás, SzövegKódoló, Szótár, Tokenizer


@dataclass
class FactorTrace:
    """Egy tényező értékének nyomvonala — bemutatáshoz / reflexióhoz."""

    type_name: str  # "neurális", "szabály", "hiedelem", "cél"
    value: float
    description: str  # ember-olvasható összefoglaló
    # M3.1: ha auto-felfedezett, melyik training-step-ben? Egyébként None.
    auto_proposed_step: int | None = None


@dataclass
class BeliefState:
    """Egy hiedelem aktuális futás-állapota."""

    name: str
    confidence: float = 0.5  # default: semmi tudás
    last_trace: list[FactorTrace] = field(default_factory=list)
    # M2.2: epistemikus meta-bizonytalanság [0, 1]. Default 1.0 = még nem
    # számoltuk, ezért maximum bizonytalanság.
    meta_uncertainty: float = 1.0


def _meta_uncertainty_label(unc: float) -> str:
    """Olvasható kategória egy meta-bizonytalanság értékhez."""
    if unc < 0.2:
        return "alacsony"
    if unc < 0.4:
        return "közepes"
    if unc < 0.7:
        return "magas"
    return "nagyon magas"


@dataclass
class Esemény:
    """Egy jelentős esemény a tudat futása során (Phase 4 / M4.2).

    Az eseménytípusok és a részletek típus-specifikusak:
      - "meglepetés": nagy hiba a tanulj() közben (|error| > meglepetés_küszöb)
        részletek: {error, before, target}
      - "felfedezés": új tényező javaslat sikerült (M3.1)
        részletek: {context_var, weight_name, triggered_by_error}
      - "tanulás": jelentős hibajavulás történt
        részletek: {hibajavulás, before, after}
      - "routing": jelentős routing-súly változás (M3.2)
        részletek: {goal, area, before, after}
      - "észlelés": sok hiedelem változott egy észleléskor
        részletek: {inputs, changed_count}
    """

    step: int
    típus: str
    belief_name: str | None
    context_snapshot: dict[str, float]
    részletek: dict[str, object] = field(default_factory=dict)


@dataclass
class Conflict:
    """Két ellentmondó tényező egy hiedelem belsejében (Phase 2 / M2.3).

    A két FactorTrace ellenkező oldalon áll (egyik magas, másik alacsony),
    és a `távolság` ≥ a tudat konfigurált küszöbe.
    """

    a: FactorTrace
    b: FactorTrace
    távolság: float

    def __str__(self) -> str:
        return (
            f"{self.a.type_name} ({self.a.value:.3f}) "
            f"vs {self.b.type_name} ({self.b.value:.3f})"
        )


@dataclass
class Explanation:
    """Ember-olvasható magyarázat egy hiedelemről (Phase 1 / M4, M2.2 bővítés).

    Strukturált formában tartalmazza:
      - a hiedelem nevét, aktuális confidence-ét,
      - a meta-bizonytalanságát (M2.2),
      - a területét (vagy None ha top-level), aktív-e a terület,
      - a tényező-trace-eket (a last_trace mező a BeliefState-ből).

    Az `__str__` magyar nyelvű, többsoros bemutatást ad.
    """

    belief_name: str
    confidence: float
    area: str | None
    is_area_active: bool
    factor_traces: list[FactorTrace] = field(default_factory=list)
    # M2.2: epistemikus meta-bizonytalanság
    meta_uncertainty: float = 1.0
    # M2.3: feszültség (max-min) + ellentmondó tényező-párok
    tension: float = 0.0
    contradictions: list[Conflict] = field(default_factory=list)

    def __str__(self) -> str:
        lines = []
        lines.append(
            f"A `{self.belief_name}` hiedelem confidence-e: "
            f"{self.confidence:.3f}"
        )
        if self.area is None:
            lines.append("Terület: top-level (a tudat közvetlen szintje)")
        else:
            állapot = "aktív" if self.is_area_active else "alvó"
            lines.append(f"Terület: {self.area} ({állapot})")
        # M2.2: meta-bizonytalanság sora
        unc_label = _meta_uncertainty_label(self.meta_uncertainty)
        lines.append(
            f"Meta-bizonytalanság: {self.meta_uncertainty:.3f} ({unc_label})"
        )
        # M2.3: ellentmondás-figyelmeztetés — csak ha vannak küszöb fölötti párok
        if self.contradictions:
            lines.append(
                f"⚠ Ellentmondás észlelve! Feszültség: {self.tension:.2f}"
            )
            # Max 3 pár a kimenetben, távolság szerint csökkenő.
            for c in self.contradictions[:3]:
                lines.append(f"   Ellentétes: {c}")
            if len(self.contradictions) > 3:
                lines.append(
                    f"   ... és további {len(self.contradictions) - 3} pár."
                )
        if not self.factor_traces:
            lines.append("Nincs tényező (csak deklaráció).")
        else:
            lines.append(f"Tényezők ({len(self.factor_traces)}):")
            for tr in self.factor_traces:
                line = f"  • {tr.description}"
                # M3.1: auto-felfedezett tényező jelzése
                if tr.auto_proposed_step is not None:
                    line += f"  [✨ auto-felfedezett @ step {tr.auto_proposed_step}]"
                lines.append(line)
        return "\n".join(lines)


class TudatRuntime:
    """Egy `tudat` állapotos instanciája — reaktív, eseményvezérelt, tanulható."""

    # M5: alapértelmezett tanulási ráta. A `tanulj(..., tanulási_ráta=)`
    # paraméter felülírja egy adott hívásra.
    DEFAULT_LEARNING_RATE: float = 0.1

    # M2.2: alapértelmezett meta-bizonytalanság α (minta-méret súly).
    # α = 0.5: fele-fele a kettő komponens súlya.
    DEFAULT_META_UNCERTAINTY_ALPHA: float = 0.5

    # M2.3: alapértelmezett ellentmondás-küszöb. Pár (a, b) ellentmondó,
    # ha |a.value - b.value| ≥ ez. 0.4 = 0.3 vs 0.7 már ellentmondás.
    DEFAULT_CONTRADICTION_THRESHOLD: float = 0.4

    # M3.1: alapértelmezett meglepetés-küszöb. Ha |error| ≥ ez, és a felfedezés
    # engedélyezve van, új tényezőt javasol a tudat.
    DEFAULT_SURPRISE_THRESHOLD: float = 0.3

    # M3.1: max auto-javaslat hiedelmenként — anti-spam védelem.
    DEFAULT_MAX_PROPOSALS_PER_BELIEF: int = 10

    # M3.2: alapértelmezett routing-aktivációs küszöb. Terület aktív, ha
    # max(goal.akt × routing(goal, area)) > ez.
    DEFAULT_ROUTING_ACTIVATION_THRESHOLD: float = 0.5

    # M3.2: alapértelmezett routing-súly minden (cél, terület) párra.
    DEFAULT_ROUTING_WEIGHT: float = 0.5

    # M4.2: alapértelmezett emlékezet-konfig.
    DEFAULT_MAX_MEMORIES: int = 1000
    DEFAULT_SIGNIFICANT_THRESHOLD: float = 0.2
    DEFAULT_PERCEPTION_SIGNIFICANT_COUNT: int = 2

    def __init__(
        self,
        decl: tudat_ast.TudatDecl,
        *,
        seed: int = 0,
        tanulási_ráta: float = DEFAULT_LEARNING_RATE,
        meta_uncertainty_alpha: float = DEFAULT_META_UNCERTAINTY_ALPHA,
        ellentmondás_küszöb: float = DEFAULT_CONTRADICTION_THRESHOLD,
        felfedezés_engedélyezve: bool = False,
        meglepetés_küszöb: float = DEFAULT_SURPRISE_THRESHOLD,
        max_javaslatok_hiedelmenként: int = DEFAULT_MAX_PROPOSALS_PER_BELIEF,
        tanult_routing: bool = False,
        routing_aktivációs_küszöb: float = DEFAULT_ROUTING_ACTIVATION_THRESHOLD,
        emlékezés_engedélyezve: bool = True,
        max_emlékek: int = DEFAULT_MAX_MEMORIES,
        jelentős_küszöb: float = DEFAULT_SIGNIFICANT_THRESHOLD,
        észlelés_jelentős_küszöb: int = DEFAULT_PERCEPTION_SIGNIFICANT_COUNT,
    ):
        self.decl = decl
        self._rng = random.Random(seed)
        self.tanulási_ráta = float(tanulási_ráta)
        # M2.2: α a meta-bizonytalanság képletében.
        self.meta_uncertainty_alpha = float(meta_uncertainty_alpha)
        # M2.3: ellentmondás-detektálás küszöbe.
        self.ellentmondás_küszöb = float(ellentmondás_küszöb)
        # M3.1: meglepetés-vezérelt felfedezés
        self.felfedezés_engedélyezve = bool(felfedezés_engedélyezve)
        self.meglepetés_küszöb = float(meglepetés_küszöb)
        self.max_javaslatok_hiedelmenként = int(max_javaslatok_hiedelmenként)
        # M3.1 belső állapotok:
        self._step_counter: int = 0
        self._auto_weight_counter: int = 0
        self._auto_proposed_count: dict[str, int] = {}
        # id(factor) → {"step": int, "context_var": str, "triggered_by_error": float}
        self._auto_factor_metadata: dict[int, dict[str, object]] = {}

        # M3.2: tanult routing
        self.tanult_routing = bool(tanult_routing)
        self.routing_aktivációs_küszöb = float(routing_aktivációs_küszöb)
        # (goal_name, area_name) → súly [0, 1]; default 0.5 lookup-kor
        self._routing_weights: dict[tuple[str, str], float] = {}
        # Kézi aktiváció / deaktiváció követése — felülbírálja a routingot
        self._manual_activated: set[str] = set()
        self._manual_deactivated: set[str] = set()

        # M4.2: epizodikus emlékezet
        self.emlékezés_engedélyezve = bool(emlékezés_engedélyezve)
        self.jelentős_küszöb = float(jelentős_küszöb)
        self.észlelés_jelentős_küszöb = int(észlelés_jelentős_küszöb)
        self._emlékek: deque = deque(maxlen=int(max_emlékek))

        # M5.3: tanulási görbe — minden tanulj() egy bejegyzést ad.
        # Független az emlékek küszöbeitől → tiszta görbét ad.
        self._training_history: deque = deque(maxlen=int(max_emlékek))

        # Belső állapotok
        self.beliefs: dict[str, BeliefState] = {}
        self.weights: dict[str, float] = {}
        self.goals: dict[str, float] = {}
        self.context: dict[str, float] = {}

        # Deklaráció-referenciák
        self._belief_decls: dict[str, tudat_ast.BeliefDecl] = {}
        self._area_of: dict[str, str | None] = {}

        # M3: terület-aktiváció + függőségi gráf + észlelés-paraméterek
        self._areas: dict[str, list[str]] = {}
        self._active_areas: set[str] = set()
        self._belief_deps: dict[str, set[str]] = {}
        self._dependents_of: dict[str, set[str]] = {}
        self._perception_params: list[str] = []

        # M5: per-tényező tanult paraméterek (rule_weight, goal_weight, ...).
        # Kulcs: id(factor); érték: dict[param_name → float].
        self._factor_params: dict[int, dict[str, float]] = {}

        # M6.3: szöveg-tényezők tanult állapota. Mind id(factor)-kulcsú,
        # pickle-kor (belief_name, factor_idx)-re reindexelve (mint _factor_params).
        #   _text_tokenizers: id(factor) → Tokenizer
        #   _text_vocabs:     id(factor) → Szótár
        #   _text_encoders:   id(factor) → SzövegKódoló
        self._text_tokenizers: dict[int, Tokenizer] = {}
        self._text_vocabs: dict[int, Szótár] = {}
        self._text_encoders: dict[int, SzövegKódoló] = {}
        # A szótár az első fit()-kor épül föl és fagy be (D6 + Phase 6 döntés).
        self._text_vocab_built: bool = False
        # Reprodukálható embedding-init seedje (a runtime seedjéből származtatva).
        self._text_seed: int = int(seed) + 100003

        # M2.1: hipotetikus hiedelem-override-ok. Amíg egy név itt van,
        # a compute_belief() ezt az értéket adja vissza, nem újraszámolja
        # a tényezőkből. Csak `mi_lenne_ha` kontextusban kerül beleelemre.
        self._belief_overrides: dict[str, float] = {}

        # M7.2: a kifejezés-blokkok beszéd-palettája (belief, szerep, sáv) → darabok.
        self._kifejezés_tábla: dict[tuple[str, str, str], list[str]] = {}

        self._initialize()
        self._build_dependency_graph()
        self._collect_perception_params()
        self._collect_kifejezések()

    # ─── Inicializálás ─────────────────────────────────────────────────

    def _initialize(self) -> None:
        for area_name, item in self._iter_items_with_area():
            if isinstance(item, tudat_ast.BeliefDecl):
                self.beliefs[item.name] = BeliefState(name=item.name)
                self._belief_decls[item.name] = item
                self._area_of[item.name] = area_name
            elif isinstance(item, tudat_ast.WeightDecl):
                # M4.1: tensor_shape annotáció → ElTensor, különben skalár
                if item.tensor_shape:
                    size = 1
                    for d in item.tensor_shape:
                        size *= d
                    data = [self._rng.gauss(0.0, 0.01) for _ in range(size)]
                    self.weights[item.name] = ElTensor(
                        data, list(item.tensor_shape)
                    )
                else:
                    self.weights[item.name] = self._rng.gauss(0.0, 0.1)
                self._area_of[item.name] = area_name
            elif isinstance(item, tudat_ast.GoalDecl):
                self.goals[item.name] = 1.0
                self._area_of[item.name] = area_name

        # Területek regisztrációja — default mind aktív
        for item in self.decl.body:
            if isinstance(item, tudat_ast.AreaDecl):
                names = [
                    sub.name
                    for sub in item.body
                    if isinstance(
                        sub,
                        (tudat_ast.BeliefDecl, tudat_ast.WeightDecl, tudat_ast.GoalDecl),
                    )
                ]
                self._areas[item.name] = names
                self._active_areas.add(item.name)

    def _iter_items_with_area(
        self,
    ) -> Iterator[tuple[str | None, tudat_ast.TudatItem]]:
        """Iterál a tudat összes deklaráción, megjelölve a területet."""
        for item in self.decl.body:
            if isinstance(item, tudat_ast.AreaDecl):
                for sub in item.body:
                    yield item.name, sub
            else:
                yield None, item

    def _build_dependency_graph(self) -> None:
        """Statikus analízis: mely hiedelem mely névre hivatkozik.

        Eredmény: két dict.
        - `_belief_deps`: belief → set(names it reads)
        - `_dependents_of`: name → set(beliefs that read this name)
        """
        for name, decl in self._belief_decls.items():
            deps = _collect_belief_deps(decl)
            self._belief_deps[name] = deps
            for dep_name in deps:
                self._dependents_of.setdefault(dep_name, set()).add(name)

    def _collect_perception_params(self) -> None:
        """Összegyűjti a tudat észlelés-blokkjaiban felsorolt paramétereket."""
        for item in self.decl.body:
            if isinstance(item, tudat_ast.PerceptionBlock):
                for p in item.params:
                    if p not in self._perception_params:
                        self._perception_params.append(p)

    def _collect_kifejezések(self) -> None:
        """A `kifejezés` blokkok darabjait (belief, szerep, sáv) kulcsra gyűjti.

        Több blokk / ismétlődő kulcs esetén a darabok összeadódnak (extend).
        """
        self._kifejezés_tábla = {}
        for item in self.decl.body:
            if not isinstance(item, tudat_ast.KifejezésBlokk):
                continue
            for b in item.bejegyzések:
                kulcs = (item.belief_name, b.szerep, b.sáv)
                self._kifejezés_tábla.setdefault(kulcs, []).extend(b.darabok)

    def kifejezés_forrás(self) -> FragmentForrás:
        """A tudat beszéd-palettája `FragmentForrás`-ként (a generálóhoz, M7.3).

        A `kifejezés` blokkokból épül; ha nincs ilyen blokk, üres forrás
        (a generáló ekkor semmit nem mond — grounded)."""
        return DictForrás(self._kifejezés_tábla)

    # ─── Számítás (M2-ből) ──────────────────────────────────────────────

    def compute_belief(self, name: str) -> float:
        """A `name` hiedelem confidence-ének újraszámolása.

        M2.1: ha a hiedelem `_belief_overrides`-ban van, a felülírt
        értéket adja vissza és NEM számolja újra a tényezőkből
        (a `mi_lenne_ha` "supposition" szemantikája).
        """
        if name not in self.beliefs:
            raise KeyError(
                f"Nincs `{name}` nevű hiedelem ebben a tudatban "
                f"(`{self.decl.name}`)."
            )

        # M2.1: hipotetikus override — bypass a tényezőkön.
        if name in self._belief_overrides:
            override = self._belief_overrides[name]
            state = self.beliefs[name]
            state.confidence = override
            state.last_trace = []
            # M2.2: hiedelem-override = "biztos tudás" — meta_unc = 0.0
            state.meta_uncertainty = 0.0
            return override

        decl = self._belief_decls[name]
        state = self.beliefs[name]

        if not decl.factors:
            state.confidence = 0.5
            state.last_trace = []
            # M2.2: nincs evidence → max bizonytalanság
            state.meta_uncertainty = 1.0
            return state.confidence

        traces: list[FactorTrace] = []
        támogató: list[float] = []   # "mellette" evidencia (emel)
        ellenző: list[float] = []    # M8.2: "ellen" evidencia (csökkent)
        for factor in decl.factors:
            value = evaluate_factor(factor, self)
            ellen = getattr(factor, "ellen", False)
            # M3.1: ha auto-felfedezett, mentjük a step-et a trace-be
            meta = self._auto_factor_metadata.get(id(factor))
            auto_step = meta["step"] if meta else None  # type: ignore[index]
            leírás = describe_factor(factor, value)
            if ellen:
                leírás = "ellene — " + leírás
            traces.append(
                FactorTrace(
                    type_name=_factor_type_name(factor),
                    value=value,
                    description=leírás,
                    auto_proposed_step=auto_step,  # type: ignore[arg-type]
                )
            )
            (ellenző if ellen else támogató).append(value)

        # M8.2: bizonyosság = támogatás × (1 − ellenzés).
        # Üres ellen-pool → ellenzés 0 (a régi noisy-OR-ral azonos).
        # Üres for-pool → 0.5 neutrális prior (hogy az ellen lehúzhassa).
        támogatás = aggregate(támogató) if támogató else 0.5
        ellenzés = aggregate(ellenző) if ellenző else 0.0
        state.confidence = támogatás * (1.0 - ellenzés)
        state.last_trace = traces
        # M2.2 / D4: meta-bizonytalanság a "mellette" tényezőkből (Phase 7 megőrzés).
        state.meta_uncertainty = _compute_meta_uncertainty(
            támogató, self.meta_uncertainty_alpha
        )
        return state.confidence

    def list_factors(self, name: str) -> list[FactorTrace]:
        """A hiedelem utolsó számolásának nyomvonala."""
        if name not in self.beliefs:
            raise KeyError(
                f"Nincs `{name}` nevű hiedelem ebben a tudatban "
                f"(`{self.decl.name}`)."
            )
        return list(self.beliefs[name].last_trace)

    # ─── Önreflexió (M4) ────────────────────────────────────────────────

    def magyarázd(self, belief_name: str) -> Explanation:
        """Strukturált magyarázat egy hiedelem aktuális állapotáról.

        Ha a hiedelmet még nem számoltuk (és van értelmezhető tényezője),
        most kiszámolja, hogy ne legyen üres a trace. Ha csak deklaráció
        (tényező nélkül), az `Explanation.factor_traces` üres.

        M2.2: az Explanation tartalmazza a meta_uncertainty-t is.
        M2.3: tartalmazza a tension-t és az ellentmondó párok listáját.
        """
        if belief_name not in self.beliefs:
            raise KeyError(
                f"Nincs `{belief_name}` nevű hiedelem ebben a tudatban "
                f"(`{self.decl.name}`)."
            )
        state = self.beliefs[belief_name]
        decl = self._belief_decls[belief_name]
        # Ha még nem számoltunk és van mire — most.
        if not state.last_trace and decl.factors:
            self.compute_belief(belief_name)
            state = self.beliefs[belief_name]
        area = self._area_of.get(belief_name)
        tension = self.feszültség(belief_name)
        contradictions = self.ellentmondások(belief_name)
        return Explanation(
            belief_name=belief_name,
            confidence=state.confidence,
            area=area,
            is_area_active=self._is_belief_active(belief_name),
            factor_traces=list(state.last_trace),
            meta_uncertainty=state.meta_uncertainty,
            tension=tension,
            contradictions=contradictions,
        )

    def meta_bizonytalanság(self, name: str) -> float:
        """A `name` hiedelem epistemikus meta-bizonytalansága (M2.2).

        Ha még nem futott compute_belief és van értelmezhető tényezője,
        most kiszámolja. Tényező nélküli hiedelem → 1.0.
        """
        if name not in self.beliefs:
            raise KeyError(
                f"Nincs `{name}` nevű hiedelem ebben a tudatban "
                f"(`{self.decl.name}`)."
            )
        state = self.beliefs[name]
        decl = self._belief_decls[name]
        if not state.last_trace and decl.factors:
            self.compute_belief(name)
            state = self.beliefs[name]
        return state.meta_uncertainty

    # ─── Ellentmondás-felismerés (M2.3) ─────────────────────────────────

    def feszültség(self, name: str) -> float:
        """A `name` hiedelem feszültsége: max(tényező_értékek) − min(...).

        0 = teljes egyetértés, 1 = teljes polarizáció.
        Üres trace → 0.0. Lazy compute, mint a többi API-nál.
        """
        if name not in self.beliefs:
            raise KeyError(
                f"Nincs `{name}` nevű hiedelem ebben a tudatban "
                f"(`{self.decl.name}`)."
            )
        state = self.beliefs[name]
        decl = self._belief_decls[name]
        if not state.last_trace and decl.factors:
            self.compute_belief(name)
            state = self.beliefs[name]
        if not state.last_trace:
            return 0.0
        values = [tr.value for tr in state.last_trace]
        return max(values) - min(values)

    def ellentmondások(
        self, name: str, *, küszöb: float | None = None
    ) -> list[Conflict]:
        """Az ellentmondó tényező-párok listája (M2.3).

        Pár (a, b) jegyzett, ha `|a.value − b.value| ≥ küszöb`.
        Visszatérés távolság szerint csökkenően. Üres lista, ha
        nincs küszöb fölötti pár.

        Ha `küszöb` None, a `self.ellentmondás_küszöb` használja.
        """
        if name not in self.beliefs:
            raise KeyError(
                f"Nincs `{name}` nevű hiedelem ebben a tudatban "
                f"(`{self.decl.name}`)."
            )
        th = (
            self.ellentmondás_küszöb
            if küszöb is None
            else float(küszöb)
        )
        state = self.beliefs[name]
        decl = self._belief_decls[name]
        if not state.last_trace and decl.factors:
            self.compute_belief(name)
            state = self.beliefs[name]

        traces = state.last_trace
        if len(traces) < 2:
            return []

        conflicts: list[Conflict] = []
        for i in range(len(traces)):
            for j in range(i + 1, len(traces)):
                distance = abs(traces[i].value - traces[j].value)
                if distance >= th:
                    conflicts.append(
                        Conflict(
                            a=traces[i],
                            b=traces[j],
                            távolság=distance,
                        )
                    )
        # Távolság szerint csökkenően
        conflicts.sort(key=lambda c: c.távolság, reverse=True)
        return conflicts

    def reflektál(self, label: str) -> list[Explanation]:
        """Egy nevesített reflexió-blokk futtatása.

        Visszatérés: a `magyarázd` statementek által generált
        Explanation-ok listája, blokk-sorrendben.
        """
        for item in self.decl.body:
            if isinstance(item, tudat_ast.ReflectionBlock) and item.label == label:
                return [self.magyarázd(stmt.belief_name) for stmt in item.body]
        labels = self.list_reflections()
        raise KeyError(
            f"Nincs `{label}` címkéjű reflexió a tudatban "
            f"(`{self.decl.name}`). Elérhető címkék: {labels}."
        )

    def list_reflections(self) -> list[str]:
        """A deklarált reflexió-blokkok címkéi (deklaráció-sorrendben)."""
        return [
            item.label
            for item in self.decl.body
            if isinstance(item, tudat_ast.ReflectionBlock)
        ]

    # ─── Tanult per-tényező paraméterek (M5) ────────────────────────────

    def get_factor_param(
        self, factor: object, name: str, *, default: float
    ) -> float:
        """Egy tényező tanult paraméterének aktuális értéke (vagy default)."""
        return self._factor_params.get(id(factor), {}).get(name, default)

    def set_factor_param(self, factor: object, name: str, value: float) -> None:
        """Egy tényező tanult paraméterének beállítása."""
        self._factor_params.setdefault(id(factor), {})[name] = float(value)

    # ─── Szöveg-tényezők (M6.3) ─────────────────────────────────────────

    def _all_text_factors(self) -> "list[tudat_ast.SzövegFactor]":
        """A tudat összes szöveg-tényezője (deklaráció-sorrendben)."""
        out: list[tudat_ast.SzövegFactor] = []
        for decl in self._belief_decls.values():
            for f in decl.factors:
                if isinstance(f, tudat_ast.SzövegFactor):
                    out.append(f)
        return out

    def _factor_seed_offset(self, factor: object) -> int:
        """Stabil, pozíció-alapú seed-eltolás egy tényezőhöz (reprodukálható)."""
        for bi, (_, decl) in enumerate(self._belief_decls.items()):
            for idx, f in enumerate(decl.factors):
                if f is factor:
                    return bi * 131 + idx * 17
        return 0

    def _text_state(
        self, factor: "tudat_ast.SzövegFactor"
    ) -> "tuple[Tokenizer, Szótár, SzövegKódoló]":
        """(tokenizer, szótár, kódoló) egy szöveg-tényezőhöz — lazy létrehozás.

        Ha még nincs (pl. compute_belief fit ELŐTT), üres szótárral és kis
        kódolóval hoz létre — neutrális prior, amit a fit() később felépít.
        """
        fid = id(factor)
        if fid not in self._text_encoders:
            voc = Szótár()
            # A szöveg-tényező tetszőleges hosszú kódot/üzenetet kaphat —
            # a >500 token figyelmeztetés itt nem releváns (elnémítva).
            self._text_tokenizers[fid] = Tokenizer(
                case_sensitive=factor.case_sensitive,
                figyelmeztetési_küszöb=10**9,
            )
            self._text_vocabs[fid] = voc
            self._text_encoders[fid] = SzövegKódoló(
                vocab_méret=voc.méret,
                dim=factor.dim,
                aktiváció="sigmoid",
                seed=self._text_seed + self._factor_seed_offset(factor),
            )
        return (
            self._text_tokenizers[fid],
            self._text_vocabs[fid],
            self._text_encoders[fid],
        )

    def _text_indices(self, factor: "tudat_ast.SzövegFactor") -> list[int]:
        """A context-beli szöveg-bemenet token-indexei a tényező szótárában."""
        tok, voc, _ = self._text_state(factor)
        raw = self.context.get(factor.input_name, "")
        if not isinstance(raw, str):
            raw = "" if raw is None else str(raw)
        return voc.kódol(tok.tokenizál(raw))

    def _text_factor_value(self, factor: "tudat_ast.SzövegFactor") -> float:
        """A szöveg-tényező [0,1] kimenete az aktuális context-re (sigmoid)."""
        _, _, enc = self._text_state(factor)
        return enc.forward(self._text_indices(factor))

    def _update_text_factor(
        self,
        factor: "tudat_ast.SzövegFactor",
        desired_delta_f: float,
        rate: float,
    ) -> None:
        """A szöveg-kódoló analitikus SGD-lépése.

        Konvenció (mint a neurális tényezőnél): a paramétert
        `+= rate · desired_delta_f · df/dp` irányba mozdítjuk, ami a kódoló
        `tanulj_lépés`-énél `hiba = −desired_delta_f`-nek felel meg.
        """
        _, _, enc = self._text_state(factor)
        indexek = self._text_indices(factor)
        enc.tanulj_lépés(indexek, hiba=-desired_delta_f, tanulási_ráta=rate)

    def _build_text_vocab(self, sorok: "list[dict]") -> None:
        """Első fit()-kor: szótár-építés a korpuszból + kódoló-méretezés.

        Idempotens: ha már felépült, nem ír felül (online tovább-tanulás védve).
        """
        if self._text_vocab_built:
            return
        for factor in self._all_text_factors():
            fid = id(factor)
            tok = Tokenizer(
                case_sensitive=factor.case_sensitive, figyelmeztetési_küszöb=10**9
            )
            voc = Szótár()
            dokumentumok = [
                tok.tokenizál(sor[factor.input_name])
                for sor in sorok
                if isinstance(sor.get(factor.input_name), str)
            ]
            voc.illeszt(dokumentumok)
            self._text_tokenizers[fid] = tok
            self._text_vocabs[fid] = voc
            self._text_encoders[fid] = SzövegKódoló(
                vocab_méret=voc.méret,
                dim=factor.dim,
                aktiváció="sigmoid",
                seed=self._text_seed + self._factor_seed_offset(factor),
            )
        self._text_vocab_built = True

    # ─── Tanulás (M5) ───────────────────────────────────────────────────

    def tanulj(
        self,
        *,
        tanulási_ráta: float | None = None,
        felfedezz: bool | None = None,
        **targets: float,
    ) -> dict[str, dict[str, float]]:
        """Tanítási lépés egy vagy több hiedelemre.

        Paraméterek:
          - `tanulási_ráta`: opcionális felülírás; ha None, a runtime alapérték.
          - `felfedezz`: M3.1 — opcionális felülírás a runtime-szintű
            `felfedezés_engedélyezve` flag-re. Ha igaz és |error| > meglepetés_küszöb,
            új neurális tényezőt javasol a hiedelemhez.
          - `**targets`: belief_név → kívánt confidence (float, [0, 1]).

        Algoritmus minden (belief, target) párra:
          1. Számolja a jelenlegi confidence-et (`compute_belief`).
          2. err = target − jelenlegi.
          3. Mindegyik tényező *aggregátum-gradiens-hozzájárulása*:
             g_j = ∏ᵢ≠ⱼ(1 − pᵢ).
          4. Mindegyik tényezőre kívánt változás: Δf_j = err × g_j.
          5. A tényező-típusra jellemző paraméter-frissítés.
          6. M3.1: ha felfedezz és |error| > küszöb, új tényező-javaslat.

        Visszatérés: dict[belief_név → {"before": float, "after": float,
        "error": float}].
        """
        rate = (
            float(tanulási_ráta)
            if tanulási_ráta is not None
            else self.tanulási_ráta
        )
        # M3.1: per-hívás override vagy runtime default
        discover = (
            bool(felfedezz)
            if felfedezz is not None
            else self.felfedezés_engedélyezve
        )

        results: dict[str, dict[str, float]] = {}
        for belief_name, target in targets.items():
            results[belief_name] = self._train_one_belief(
                belief_name, float(target), rate, discover
            )
        # M5.3: tanulási görbe — minden tanulj() egy bejegyzés
        if results:
            errors = {b: r["error"] for b, r in results.items()}
            self._training_history.append((self._step_counter, errors))
        # M3.1: lépésszámláló minden tanulj() hívás után
        self._step_counter += 1
        return results

    def _train_one_belief(
        self, name: str, target: float, rate: float, discover: bool = False
    ) -> dict[str, float]:
        if name not in self.beliefs:
            raise KeyError(
                f"Nincs `{name}` nevű hiedelem ebben a tudatban "
                f"(`{self.decl.name}`)."
            )
        decl = self._belief_decls[name]

        # Ha nincs faktor, csak deklaráció — nincs mit tanulni.
        if not decl.factors:
            return {"before": 0.5, "after": 0.5, "error": float(target) - 0.5}

        # 1. Jelenlegi confidence (kiszámolva tényezőkből).
        before = self.compute_belief(name)
        error = target - before

        # M4.2: meglepetés-esemény, ha a hiba túl nagy
        if abs(error) > self.meglepetés_küszöb:
            self._record_event(
                "meglepetés",
                belief_name=name,
                részletek={"error": error, "before": before, "target": target},
            )

        # 2. Tényezők aktuális értékei + előjel-szerinti szétválasztás (M8.2).
        factor_values = [tr.value for tr in self.beliefs[name].last_trace]
        ellen_flags = [getattr(f, "ellen", False) for f in decl.factors]
        for_vals = [v for v, e in zip(factor_values, ellen_flags) if not e]
        ellen_vals = [v for v, e in zip(factor_values, ellen_flags) if e]

        # 3. Gradiens a `bizonyosság = S·(1−O)` képletre:
        #    for-tényező:  g = (1−O) · ∂S/∂p
        #    ellen-tényező: g = −S · ∂O/∂q   (negatív irány → kivonó tanulás)
        támogatás = aggregate(for_vals) if for_vals else 0.5
        ellenzés = aggregate(ellen_vals) if ellen_vals else 0.0
        for_grads = _noisy_or_gradients(for_vals)
        ellen_grads = _noisy_or_gradients(ellen_vals)

        # 4. Mindegyik tényezőre paraméter-frissítés a megfelelő (előjeles) jellel.
        fi = ei = 0
        for factor, ellen in zip(decl.factors, ellen_flags):
            if ellen:
                g = -támogatás * ellen_grads[ei]
                ei += 1
            else:
                g = (1.0 - ellenzés) * for_grads[fi]
                fi += 1
            self._update_factor_params(factor, error * g, rate)

        # 5. Újraszámolás a frissített paraméterekkel.
        after = self.compute_belief(name)

        # 6. M3.1: meglepetés-vezérelt felfedezés
        if discover and abs(error) > self.meglepetés_küszöb:
            new_factor = self._propose_neural_factor(name, error)
            if new_factor is not None:
                # A propose belsőleg újraszámolt — frissítjük az after-t.
                after = self.beliefs[name].confidence

        # 7. M3.2: tanult routing-súlyok frissítése a hibajavulás alapján
        err_after = target - after
        hibajavulás = abs(error) - abs(err_after)
        if self.tanult_routing:
            self._update_routing_weights(name, hibajavulás, rate)

        # M4.2: tanulás-esemény, ha a hibajavulás jelentős
        if hibajavulás > self.jelentős_küszöb:
            self._record_event(
                "tanulás",
                belief_name=name,
                részletek={
                    "hibajavulás": hibajavulás,
                    "before": before,
                    "after": after,
                },
            )

        return {"before": before, "after": after, "error": error}

    # ─── Tanult routing (M3.2) ──────────────────────────────────────────

    def _update_routing_weights(
        self, belief_name: str, hibajavulás: float, rate: float
    ) -> None:
        """Routing-súly frissítés egy belief-edzés után.

        A hiedelem területének routing-súlyait frissítjük minden aktív
        célhoz: Δw = rate × hibajavulás × goal.aktiváció.

        Top-level hiedelmek (terület nélkül) nincsenek befolyásolva —
        nincs routing-súly hozzájuk.
        """
        area = self._area_of.get(belief_name)
        if area is None:
            return  # top-level belief, nincs routing
        for goal_name, activation in self.goals.items():
            if activation <= 0:
                continue
            key = (goal_name, area)
            current = self._routing_weights.get(
                key, self.DEFAULT_ROUTING_WEIGHT
            )
            delta = rate * hibajavulás * activation
            new = max(0.0, min(1.0, current + delta))
            self._routing_weights[key] = new
            # M4.2: routing-esemény, ha jelentős változás
            if abs(new - current) > self.jelentős_küszöb:
                self._record_event(
                    "routing",
                    belief_name=belief_name,
                    részletek={
                        "goal": goal_name,
                        "area": area,
                        "before": current,
                        "after": new,
                    },
                )

    # ─── Meglepetés-vezérelt felfedezés (M3.1) ──────────────────────────

    def _propose_neural_factor(
        self, belief_name: str, error: float
    ) -> "tudat_ast.NeuralFactor | None":
        """Egy új neurális tényező javaslata egy meglepő hiedelemhez.

        A javaslat: `auto_W_N * context_var` ahol `context_var` egy nem-használt
        context-változó. Ha minden context-változó már használatban van, vagy
        elértük a limitet hiedelmenként, nem javaslunk.

        Visszatérés: a hozzáadott NeuralFactor vagy None.
        """
        # Limit-ellenőrzés
        count = self._auto_proposed_count.get(belief_name, 0)
        if count >= self.max_javaslatok_hiedelmenként:
            return None

        decl = self._belief_decls[belief_name]

        # Mely context-változókat használja már a hiedelem?
        used_names: set[str] = set()
        for f in decl.factors:
            used_names |= _collect_factor_deps(f)

        # Találjunk egy NEM-használt context-változót
        candidate_context = [
            name for name in self.context if name not in used_names
        ]
        if not candidate_context:
            return None  # nincs új jel, amire építhetünk

        # Determinisztikus választás: insertion-order első nem-használt
        context_var = candidate_context[0]

        # Egyedi auto-súly név generálása (ütközés-elkerülés)
        self._auto_weight_counter += 1
        weight_name = f"auto_W_{self._auto_weight_counter}"
        while weight_name in self.weights:
            self._auto_weight_counter += 1
            weight_name = f"auto_W_{self._auto_weight_counter}"

        # Kis kezdő-súly — gauss kis szórással. Az SGD majd alakítja.
        self.weights[weight_name] = self._rng.gauss(0.0, 0.01)

        # Új NeuralFactor: weight * context_var
        new_expr = base_ast.Binary(
            op="STAR",
            left=base_ast.Var(name=weight_name),
            right=base_ast.Var(name=context_var),
        )
        new_factor = tudat_ast.NeuralFactor(expr=new_expr, line=0)

        # Metadata
        self._auto_factor_metadata[id(new_factor)] = {
            "step": self._step_counter,
            "context_var": context_var,
            "triggered_by_error": error,
            "belief_name": belief_name,
            "weight_name": weight_name,
        }

        # Beillesztés a hiedelem tényezőlistájába
        decl.factors.append(new_factor)
        self._auto_proposed_count[belief_name] = count + 1

        # Függőségi gráf újraépítése — az új súly és context_var
        # függésekkel bekerül a reaktív/futtatási mechanizmusba.
        self._build_dependency_graph()

        # State újraszámolás — a trace tükrözze az új tényezőt
        # (különben a `magyarázd` még a régi tényezőlistát mutatná).
        self.compute_belief(belief_name)

        # M4.2: felfedezés-esemény
        self._record_event(
            "felfedezés",
            belief_name=belief_name,
            részletek={
                "context_var": context_var,
                "weight_name": weight_name,
                "triggered_by_error": error,
            },
        )

        return new_factor

    # ─── Epizodikus emlékezet (M4.2) ────────────────────────────────────

    def _record_event(
        self,
        típus: str,
        *,
        belief_name: str | None = None,
        részletek: dict | None = None,
    ) -> None:
        """Egy esemény felvétele a tudat emlékezetébe.

        Ha az emlékezés ki van kapcsolva, nem csinál semmit (no-op).
        """
        if not self.emlékezés_engedélyezve:
            return
        evt = Esemény(
            step=self._step_counter,
            típus=típus,
            belief_name=belief_name,
            context_snapshot=dict(self.context),
            részletek=dict(részletek) if részletek else {},
        )
        self._emlékek.append(evt)

    def emlékek(
        self,
        *,
        típus: str | None = None,
        hiedelem: str | None = None,
        n: int | None = None,
    ) -> list[Esemény]:
        """Az emlékek lekérdezése. Legfrissebb először (időben fordított).

        Szűrők:
          - `típus`: csak az adott típusú események
          - `hiedelem`: csak adott hiedelemhez kapcsolódó események
          - `n`: csak az első N (legfrissebb) esemény
        """
        result = list(self._emlékek)
        result.reverse()  # legfrissebb először
        if típus is not None:
            result = [e for e in result if e.típus == típus]
        if hiedelem is not None:
            result = [e for e in result if e.belief_name == hiedelem]
        if n is not None:
            result = result[: int(n)]
        return result

    def utolsó_emlék(self) -> "Esemény | None":
        """A legutolsó esemény, vagy None ha üres az emlékezet."""
        if not self._emlékek:
            return None
        return self._emlékek[-1]

    def emlékek_száma(self) -> int:
        """A jelenleg tárolt emlékek száma."""
        return len(self._emlékek)

    # ─── Persistence (M5.1) ─────────────────────────────────────────────

    def ments(self, útvonal: "str | Path") -> None:
        """A tudat-runtime mentése pickle formátumban.

        Minden állapotot megőriz:
          - súlyok (skalár ÉS tenzor)
          - beliefs (confidence, meta_uncertainty, trace)
          - célok aktivációi
          - context (külső bemenetek)
          - routing-súlyok (M3.2)
          - factor-paraméterek (rule_weight, goal_weight — M5)
          - auto-felfedezett tényezők és metadatájuk (M3.1)
          - epizodikus emlékek (M4.2)
          - összes konfigurációs paraméter
          - step-szám, RNG állapot

        Verzió-string ágyazott a fájlba kompatibilitás-ellenőrzéshez.
        """
        útvonal = Path(útvonal)
        útvonal.parent.mkdir(parents=True, exist_ok=True)
        package = {
            "version": PERSISTENCE_VERSION,
            "runtime": self,
        }
        with open(útvonal, "wb") as f:
            pickle.dump(package, f)

    @classmethod
    def betölt(cls, útvonal: "str | Path") -> "TudatRuntime":
        """Mentett tudat-runtime visszaállítása."""
        útvonal = Path(útvonal)
        with open(útvonal, "rb") as f:
            package = pickle.load(f)
        if not isinstance(package, dict) or "version" not in package:
            raise ValueError(
                f"Érvénytelen tudat-mentés: `{útvonal}`. "
                f"Talán nem `rt.ments()` készítette?"
            )
        version = package["version"]
        if version not in KOMPATIBILIS_VERZIÓK:
            raise ValueError(
                f"Inkompatibilis mentési formátum: `{version}` (jelenlegi: "
                f"`{PERSISTENCE_VERSION}`, kompatibilis: "
                f"{sorted(KOMPATIBILIS_VERZIÓK)}). Régi mentés újra-tanítása kell."
            )
        rt = package["runtime"]
        if not isinstance(rt, cls):
            raise ValueError(
                f"A mentés nem TudatRuntime objektum, hanem "
                f"`{type(rt).__name__}`."
            )
        return rt

    def __getstate__(self) -> dict:
        """Pickle-helper: id-kulcsú dicteket átalakítja stabil pozíció-kulcsra.

        A `_factor_params` és `_auto_factor_metadata` Python `id(factor)`
        értékkel kulcsolt — pickle után az új objektumoknak új id-juk lesz,
        ezért átalakítás kell: (belief_name, factor_index) kulcsra.
        """
        state = self.__dict__.copy()
        state["_factor_params"] = self._reindex_id_dict(self._factor_params)
        state["_auto_factor_metadata"] = self._reindex_id_dict(
            self._auto_factor_metadata
        )
        # M6.3: szöveg-tényező állapot — szintén id(factor)-kulcsú.
        state["_text_tokenizers"] = self._reindex_id_dict(self._text_tokenizers)
        state["_text_vocabs"] = self._reindex_id_dict(self._text_vocabs)
        state["_text_encoders"] = self._reindex_id_dict(self._text_encoders)
        # Az _emlékek deque közvetlenül pickleable; maxlen megőrződik.
        return state

    def __setstate__(self, state: dict) -> None:
        """Pickle-helper: pozíció-kulcsú dicteket id-kulcsra rakja vissza."""
        self.__dict__.update(state)
        # Most már `self._belief_decls` elérhető — id-kulcsú visszaállítás
        # (a state-ben a position-keyed verziók vannak)
        self._factor_params = self._restore_id_dict(state["_factor_params"])
        self._auto_factor_metadata = self._restore_id_dict(
            state["_auto_factor_metadata"]
        )
        # M6.3: szöveg-tényező állapot visszaállítása. Régi (1.0) mentésekben
        # nincs — ilyenkor üres dict + nem-épült flag (backward-compat, D8).
        self._text_tokenizers = self._restore_id_dict(
            state.get("_text_tokenizers", {})
        )
        self._text_vocabs = self._restore_id_dict(state.get("_text_vocabs", {}))
        self._text_encoders = self._restore_id_dict(
            state.get("_text_encoders", {})
        )
        if "_text_vocab_built" not in state:
            self._text_vocab_built = False
        if "_text_seed" not in state:
            self._text_seed = 100003
        # M7.2: a beszéd-paletta a decl-ből újraépíthető — régi mentésben nincs.
        if "_kifejezés_tábla" not in state:
            self._collect_kifejezések()

    def _reindex_id_dict(self, id_dict: dict) -> dict:
        """id(factor) → érték dict-et átalakítja (belief_name, factor_idx) → érték."""
        result: dict = {}
        for belief_name, decl in self._belief_decls.items():
            for idx, factor in enumerate(decl.factors):
                if id(factor) in id_dict:
                    result[(belief_name, idx)] = id_dict[id(factor)]
        return result

    def _restore_id_dict(self, pos_dict: dict) -> dict:
        """(belief_name, factor_idx) → érték dict visszaállítása id(factor) kulcsra."""
        result: dict = {}
        for (belief_name, idx), value in pos_dict.items():
            if belief_name in self._belief_decls:
                decl = self._belief_decls[belief_name]
                if 0 <= idx < len(decl.factors):
                    result[id(decl.factors[idx])] = value
        return result

    # ─── Fit + Értékelés (M5.2) ────────────────────────────────────────

    def fit(
        self,
        adatok,
        *,
        célok: dict[str, str],
        epochok: int = 1,
        tanulási_ráta: float | None = None,
        felfedezz: bool | None = None,
        keverj: bool = True,
    ) -> dict:
        """Tanítási loop egy dataset felett.

        Paraméterek:
          - `adatok`: list[dict] VAGY pandas DataFrame (ha telepítve van)
          - `célok`: {belief_név: oszlop_név} mapping — minden sornál
            ezeket a hiedelmeket tanítjuk az adott oszlopok értékére
          - `epochok`: hányszor menjen végig az adatokon (default 1)
          - `tanulási_ráta`: opcionális override
          - `felfedezz`: opcionális override M3.1 felfedezésre
          - `keverj`: epochonkénti random shuffle (default True, reprodukálható
            mert a tudat saját RNG-jét használja)

        A nem-cél oszlopok automatikusan context-be kerülnek (`észlel(...)`).

        Visszatérés: {
          "iterációk": int,
          "végső_átlag_abs_hiba": float,
          "végső_hibák": {belief: hiba_érték},
        }
        """
        sorok = self._to_list_of_dicts(adatok)
        if not sorok:
            return {
                "iterációk": 0,
                "végső_átlag_abs_hiba": 0.0,
                "végső_hibák": {},
            }

        # M6.3: szöveg-tényezők szótárának felépítése a korpuszból (első fit).
        self._build_text_vocab(sorok)

        cél_oszlopok = set(célok.values())
        context_oszlopok = [
            k for k in sorok[0].keys() if k not in cél_oszlopok
        ]

        összes_iter = 0
        végső_hibák: dict[str, float] = {}

        for _ in range(epochok):
            ha_keverj = list(sorok)
            if keverj:
                self._rng.shuffle(ha_keverj)
            for sor in ha_keverj:
                context_kw = {
                    k: (sor[k] if isinstance(sor[k], str) else float(sor[k]))
                    for k in context_oszlopok
                    if k in sor
                }
                if context_kw:
                    self.észlel(**context_kw)
                target_kw = {
                    b: float(sor[c])
                    for b, c in célok.items()
                    if c in sor
                }
                eredmény = self.tanulj(
                    tanulási_ráta=tanulási_ráta,
                    felfedezz=felfedezz,
                    **target_kw,
                )
                végső_hibák = {
                    b: eredmény[b]["error"]
                    for b in target_kw
                    if b in eredmény
                }
                összes_iter += 1

        átlag_abs = (
            sum(abs(e) for e in végső_hibák.values()) / len(végső_hibák)
            if végső_hibák
            else 0.0
        )
        return {
            "iterációk": összes_iter,
            "végső_átlag_abs_hiba": átlag_abs,
            "végső_hibák": végső_hibák,
        }

    def értékelés(
        self,
        test_adatok,
        *,
        célok: dict[str, str],
    ) -> dict[str, dict[str, float]]:
        """Tudat-teljesítmény mérése egy teszt-adaton.

        NEM módosítja a modellt (csak észlel + compute_belief, nincs tanulj).

        Visszatérés: {belief: {"n": int, "pontosság": float, "átlagos_hiba": float, "MSE": float}}
          - pontosság: bináris klasszifikáció — (pred > 0.5) == (target > 0.5)
          - átlagos_hiba: MAE = mean(|pred - target|)
          - MSE: mean((pred - target)²)
        """
        sorok = self._to_list_of_dicts(test_adatok)
        if not sorok:
            return {b: {"n": 0, "pontosság": 0.0, "átlagos_hiba": 0.0, "MSE": 0.0} for b in célok}

        cél_oszlopok = set(célok.values())
        context_oszlopok = [
            k for k in sorok[0].keys() if k not in cél_oszlopok
        ]

        predikciók: dict[str, list[float]] = {b: [] for b in célok}
        célértékek: dict[str, list[float]] = {b: [] for b in célok}

        for sor in sorok:
            context_kw = {
                k: (sor[k] if isinstance(sor[k], str) else float(sor[k]))
                for k in context_oszlopok
                if k in sor
            }
            if context_kw:
                self.észlel(**context_kw)
            for belief_name, col in célok.items():
                if col in sor:
                    pred = self.compute_belief(belief_name)
                    predikciók[belief_name].append(pred)
                    célértékek[belief_name].append(float(sor[col]))

        metrikák: dict[str, dict[str, float]] = {}
        for b in célok:
            preds = predikciók[b]
            targs = célértékek[b]
            n = len(preds)
            if n == 0:
                metrikák[b] = {"n": 0, "pontosság": 0.0, "átlagos_hiba": 0.0, "MSE": 0.0}
                continue
            mae = sum(abs(p - t) for p, t in zip(preds, targs)) / n
            mse = sum((p - t) ** 2 for p, t in zip(preds, targs)) / n
            helyes = sum(
                1 for p, t in zip(preds, targs) if (p > 0.5) == (t > 0.5)
            )
            metrikák[b] = {
                "n": n,
                "pontosság": helyes / n,
                "átlagos_hiba": mae,
                "MSE": mse,
            }
        return metrikák

    @staticmethod
    def _to_list_of_dicts(adatok) -> list[dict]:
        """Pandas DataFrame → list[dict] konverzió, ha kell. Egyébként list()."""
        cls_name = type(adatok).__name__
        if cls_name == "DataFrame":
            return adatok.to_dict("records")
        return list(adatok)

    # ─── Tanulási görbe (M5.3) ──────────────────────────────────────────

    def tanulási_görbe(
        self, *, hiedelem: str | None = None
    ) -> list[tuple[int, float]]:
        """Tanulási görbe pontjai: (step, |hiba|) tuple-ök.

        Ha `hiedelem=None`: minden hiedelem |hibájának| átlaga lépésenként.
        Ha `hiedelem=X`: csak az X hiedelem hibái.
        """
        points: list[tuple[int, float]] = []
        for step, errors in self._training_history:
            if hiedelem is not None:
                if hiedelem in errors:
                    points.append((step, abs(errors[hiedelem])))
            else:
                if not errors:
                    continue
                avg = sum(abs(e) for e in errors.values()) / len(errors)
                points.append((step, avg))
        return points

    # ─── Multi-class API (M5.4) ────────────────────────────────────────

    def legjobb_osztály(self, nevek: list[str]) -> tuple[str, float]:
        """A megadott hiedelmek közül a LEGMAGASABB confidence-űt választja.

        Visszatérés: `(belief_név, confidence)` tuple.
        Hiba ha üres a lista, vagy egy név nem létezik.
        """
        if not nevek:
            raise ValueError(
                "Üres listából nem lehet legjobb osztályt választani."
            )
        legjobb_név: str | None = None
        legjobb_conf: float = float("-inf")
        for név in nevek:
            if név not in self.beliefs:
                raise KeyError(
                    f"Nincs `{név}` nevű hiedelem ebben a tudatban "
                    f"(`{self.decl.name}`)."
                )
            conf = self.compute_belief(név)
            if conf > legjobb_conf:
                legjobb_conf = conf
                legjobb_név = név
        # name biztos nem None, mert volt legalább egy név
        assert legjobb_név is not None
        return (legjobb_név, legjobb_conf)

    def osztály_valószínűségek(
        self,
        nevek: list[str],
        *,
        normalizálás: str = "softmax",
    ) -> dict[str, float]:
        """A hiedelmek confidence-értékei, opcionálisan normalizálva.

        `normalizálás`:
          - "softmax": exp(c) / sum(exp(c)) — exponenciálisan súlyozott (default)
          - "arány":   c / sum(c) — közvetlen arány (csak nem-negatívakon értelmes)
          - "nincs":   nyers confidence-értékek
        """
        if not nevek:
            return {}
        confidences = {n: self.compute_belief(n) for n in nevek}

        if normalizálás == "nincs":
            return confidences

        if normalizálás == "softmax":
            # Numerikus stabilitás: max kivonása
            max_c = max(confidences.values())
            exps = {
                n: math.exp(c - max_c) for n, c in confidences.items()
            }
            s = sum(exps.values())
            return {n: e / s for n, e in exps.items()}

        if normalizálás == "arány":
            s = sum(confidences.values())
            if s == 0.0:
                # Ha mind 0, egyenletes eloszlás
                egyenlő = 1.0 / len(nevek)
                return {n: egyenlő for n in nevek}
            return {n: c / s for n, c in confidences.items()}

        raise ValueError(
            f"Ismeretlen normalizálás: `{normalizálás}`. "
            f"Választható: 'softmax', 'arány', 'nincs'."
        )

    def tanulási_görbe_szöveg(
        self, *, hiedelem: str | None = None, max_szélesség: int = 60
    ) -> str:
        """Tanulási görbe ASCII sparkline-ként.

        Példa kimenet:
          'min=0.020 ▇▆▅▅▄▃▃▂▂▁▁  max=0.850'
        """
        points = self.tanulási_görbe(hiedelem=hiedelem)
        if not points:
            return "(Nincs tanulási adat.)"

        # Down-sample, ha túl sok pont van
        if len(points) > max_szélesség:
            arány = len(points) / max_szélesség
            sampled = [points[int(i * arány)] for i in range(max_szélesség)]
        else:
            sampled = points

        values = [v for _, v in sampled]
        min_v, max_v = min(values), max(values)
        span = max_v - min_v if max_v > min_v else 1.0

        chars = " ▁▂▃▄▅▆▇█"
        sparkline = "".join(
            chars[int(round((v - min_v) / span * (len(chars) - 1)))]
            for v in values
        )
        címke = (
            f"`{hiedelem}` hiba"
            if hiedelem
            else "Átlagos hiba"
        )
        return f"{címke}: min={min_v:.3f} {sparkline} max={max_v:.3f}"

    def auto_proposed_factors(
        self, belief_name: str
    ) -> "list[tuple[tudat_ast.NeuralFactor, dict]]":
        """A `belief_name` hiedelemhez auto-javasolt tényezők és metadatájuk.

        Visszatérés: list[(factor, {step, context_var, triggered_by_error, ...})]
        beillesztési sorrendben.
        """
        if belief_name not in self.beliefs:
            raise KeyError(
                f"Nincs `{belief_name}` nevű hiedelem ebben a tudatban."
            )
        result: list[tuple[tudat_ast.NeuralFactor, dict]] = []
        for f in self._belief_decls[belief_name].factors:
            meta = self._auto_factor_metadata.get(id(f))
            if meta is not None and isinstance(f, tudat_ast.NeuralFactor):
                result.append((f, dict(meta)))
        return result

    def _update_factor_params(
        self, factor: object, desired_delta_f: float, rate: float
    ) -> None:
        if isinstance(factor, tudat_ast.NeuralFactor):
            self._update_neural_weights(factor, desired_delta_f, rate)
        elif isinstance(factor, tudat_ast.RuleFactor):
            self._update_rule_weight(factor, desired_delta_f, rate)
        elif isinstance(factor, tudat_ast.GoalFactor):
            self._update_goal_weight(factor, desired_delta_f, rate)
        elif isinstance(factor, tudat_ast.SzövegFactor):
            self._update_text_factor(factor, desired_delta_f, rate)
        # BeliefFactor: tudatosan nincs frissítés — a forrás-hiedelem
        # a saját jeléből tanul, nem a derivált-jelből.

    def _update_neural_weights(
        self,
        factor: tudat_ast.NeuralFactor,
        desired_delta_f: float,
        rate: float,
    ) -> None:
        """SGD-lépés a NeuralFactor kifejezésében szereplő súlyokon.

        A gradiens-t numerikusan számoljuk (epsilon-perturbációval), így
        nincs autograd-függőség.
        - Skalár súlyon: egyetlen perturbáció (M5).
        - Tenzor súlyon: elemenkénti perturbáció (M4.1).
        """
        # Mely súlyok szerepelnek a kifejezésben?
        refs = _names_in_expr(factor.expr)
        weight_names = [n for n in refs if n in self.weights]
        if not weight_names:
            return

        baseline = _eval_scalar(factor.expr, self)
        eps = 1e-5
        for w_name in weight_names:
            old = self.weights[w_name]
            if isinstance(old, ElTensor):
                # M4.1: elemenkénti gradient
                for i in range(len(old.data)):
                    saved = old.data[i]
                    old.data[i] = saved + eps
                    new_val = _eval_scalar(factor.expr, self)
                    old.data[i] = saved  # restore
                    grad = (new_val - baseline) / eps
                    old.data[i] = saved + rate * desired_delta_f * grad
            else:
                # M5: skalár súly
                self.weights[w_name] = old + eps
                new_val = _eval_scalar(factor.expr, self)
                self.weights[w_name] = old
                grad_f_w = (new_val - baseline) / eps
                self.weights[w_name] = old + rate * desired_delta_f * grad_f_w

    def _update_rule_weight(
        self,
        factor: tudat_ast.RuleFactor,
        desired_delta_f: float,
        rate: float,
    ) -> None:
        """Tanult `rule_weight` frissítése — csak ha a szabály tüzelt.

        Modell: f_value = base_conf × rule_weight (ha cond>0.5), else 0.
        df/d(rule_weight) = base_conf.
        Δrw = rate × Δf × base_conf.
        """
        cond_value = _eval_expr(factor.condition, self)
        if cond_value <= 0.5:
            return  # nem tüzelt — nincs gradient
        base_conf = _eval_expr(factor.confidence, self)
        current = self.get_factor_param(factor, "rule_weight", default=1.0)
        new = current + rate * desired_delta_f * base_conf
        # M5: klippelés [0, 5] közé a numerikus stabilitásért.
        new = max(0.0, min(5.0, new))
        self.set_factor_param(factor, "rule_weight", new)

    def _update_goal_weight(
        self,
        factor: tudat_ast.GoalFactor,
        desired_delta_f: float,
        rate: float,
    ) -> None:
        """Tanult `goal_weight` frissítése.

        Modell: f_value = goal_activation × goal_weight.
        df/d(goal_weight) = goal_activation.
        Δgw = rate × Δf × goal_activation.
        """
        if factor.goal_name not in self.goals:
            return
        activation = self.goals[factor.goal_name]
        current = self.get_factor_param(
            factor, "goal_weight", default=GOAL_DEFAULT_WEIGHT
        )
        new = current + rate * desired_delta_f * activation
        # M5: klippelés [0, 1] közé (a cél nem dominálhat egyetlen forrásként).
        new = max(0.0, min(1.0, new))
        self.set_factor_param(factor, "goal_weight", new)

    # ─── Hipotetikus kérdezés (M2.1) ────────────────────────────────────

    def mi_lenne_ha(
        self, *args: str, **overrides: float
    ) -> "dict[str, float] | list[Explanation]":
        """Kontrafaktuális kérdezés — két módban használható.

        **Ad-hoc:**  `rt.mi_lenne_ha(W=0.8, páratartalom=0.9)` →
          dict[belief_név → új_confidence], CSAK a megváltozott hiedelmek.
          A valós állapot érintetlen marad (PURE).

        **Nevesített:**  `rt.mi_lenne_ha("esős nap")` → list[Explanation],
          a deklarált forgatókönyv body-jának eredménye.

        A felülírások 4 fajtája (a `name` keresési sorrendje):
          súly → context → cél → hiedelem. A hiedelem-override BYPASS
          a tényezőkön.
        """
        if args:
            if len(args) > 1 or overrides:
                raise TypeError(
                    "Vagy egy nevet adj meg (`mi_lenne_ha('név')`), vagy "
                    "kwargs overrides-eket (`mi_lenne_ha(W=0.8, ...)`), "
                    "de nem mindkettőt."
                )
            if not isinstance(args[0], str):
                raise TypeError(
                    "A pozicionális argumentum a forgatókönyv neve "
                    "kell legyen (str)."
                )
            return self._run_named_what_if(args[0])
        return self._run_adhoc_what_if(overrides)

    def list_what_ifs(self) -> list[str]:
        """A deklarált `mi_lenne_ha` forgatókönyvek címkéi."""
        return [
            item.label
            for item in self.decl.body
            if isinstance(item, tudat_ast.WhatIfBlock)
        ]

    def _find_what_if_block(self, label: str) -> "tudat_ast.WhatIfBlock | None":
        for item in self.decl.body:
            if isinstance(item, tudat_ast.WhatIfBlock) and item.label == label:
                return item
        return None

    def _run_named_what_if(self, label: str) -> "list[Explanation]":
        block = self._find_what_if_block(label)
        if block is None:
            labels = self.list_what_ifs()
            raise KeyError(
                f"Nincs `{label}` címkéjű mi_lenne_ha a tudatban "
                f"(`{self.decl.name}`). Elérhető címkék: {labels}."
            )
        # Override-kifejezések kiértékelése a JELENLEGI (még valós) állapotban.
        evaluated: dict[str, float] = {}
        for ov in block.overrides:
            evaluated[ov.name] = float(_eval_expr(ov.value_expr, self))
        snapshot = self._snapshot_state()
        try:
            self._apply_overrides(evaluated)
            self._recompute_after_overrides(evaluated)
            return [self.magyarázd(stmt.belief_name) for stmt in block.body]
        finally:
            self._restore_state(snapshot)

    def _run_adhoc_what_if(self, overrides: dict) -> dict[str, float]:
        if not overrides:
            return {}
        snapshot = self._snapshot_state()
        try:
            original_confs = {n: s.confidence for n, s in self.beliefs.items()}
            # M4.1: ElTensor felülírások már nem float-ozhatók; megőrizzük őket.
            normalized = {
                k: (v if isinstance(v, ElTensor) else float(v))
                for k, v in overrides.items()
            }
            self._apply_overrides(normalized)
            self._recompute_after_overrides(overrides)
            return {
                n: state.confidence
                for n, state in self.beliefs.items()
                if abs(state.confidence - original_confs[n]) > 1e-9
            }
        finally:
            self._restore_state(snapshot)

    def _snapshot_state(self) -> dict:
        """Mély másolat a hipotetikus számoláshoz (M4.1: ElTensor-mély másolat)."""
        return {
            "weights": {
                n: (
                    ElTensor(list(w.data), list(w.shape))
                    if isinstance(w, ElTensor)
                    else w
                )
                for n, w in self.weights.items()
            },
            "goals": dict(self.goals),
            "context": dict(self.context),
            "beliefs": {
                n: (s.confidence, list(s.last_trace), s.meta_uncertainty)
                for n, s in self.beliefs.items()
            },
            "belief_overrides": dict(self._belief_overrides),
        }

    def _restore_state(self, snapshot: dict) -> None:
        """Pontosan visszaállítja az állapotot a snapshotból."""
        self.weights = snapshot["weights"]
        self.goals = snapshot["goals"]
        self.context = snapshot["context"]
        for n, (conf, trace, meta_unc) in snapshot["beliefs"].items():
            self.beliefs[n].confidence = conf
            self.beliefs[n].last_trace = trace
            self.beliefs[n].meta_uncertainty = meta_unc
        self._belief_overrides = snapshot["belief_overrides"]

    def _apply_overrides(self, overrides: dict) -> None:
        """Egy felülírás-szótár alkalmazása az állapotra.

        Keresési sorrend: súly → cél → hiedelem → context (utolsó: új name-ek).
        A hiedelem-override BYPASS a tényezőkön — bekerül a
        `_belief_overrides`-ba és a `compute_belief` ezt fogja visszaadni.

        M4.1: ElTensor érték is engedélyezett súlyokra.
        """
        for name, raw in overrides.items():
            if name in self.weights:
                # Súly: tenzor vagy skalár megengedett
                if isinstance(raw, ElTensor):
                    self.weights[name] = raw
                else:
                    self.weights[name] = float(raw)
            elif name in self.goals:
                self.goals[name] = float(raw)
            elif name in self.beliefs:
                value = float(raw)
                self._belief_overrides[name] = value
                self.beliefs[name].confidence = value
                self.beliefs[name].last_trace = []
            else:
                # Új vagy meglévő context-key (csak skalár).
                self.context[name] = float(raw)

    def _recompute_after_overrides(self, overrides: dict[str, float]) -> None:
        """Az overrideok hatására érintett hiedelmek újraszámolása."""
        changed = set(overrides.keys())
        affected = self._affected_beliefs(changed)
        # Aktív területek szűrése (consistent az észlel-rel).
        affected = {b for b in affected if self._is_belief_active(b)}
        # Override-olt hiedelmek nem újraszámolódnak (frozen).
        affected = affected - set(self._belief_overrides.keys())
        if not affected:
            return
        order = self._topological_order(affected)
        for belief in order:
            self.compute_belief(belief)

    # ─── Területaktiváció (M3) ───────────────────────────────────────────

    def activate_area(self, name: str) -> None:
        """Egy terület aktívvá tétele — hiedelmei részt vesznek a futtatásban.

        M3.2: kézi aktiváció FELÜLÍRJA a tanult routingot. Az aktiv-jelölés
        prioritást kap a routing-számítás fölött.
        """
        if name not in self._areas:
            raise KeyError(
                f"Nincs `{name}` nevű terület. "
                f"Létezők: {sorted(self._areas)}."
            )
        self._active_areas.add(name)
        self._manual_activated.add(name)
        self._manual_deactivated.discard(name)

    def deactivate_area(self, name: str) -> None:
        """Egy terület alvó állapotba tétele — hiedelmei NEM futnak.

        M3.2: kézi deaktiváció FELÜLÍRJA a tanult routingot.
        """
        if name not in self._areas:
            raise KeyError(
                f"Nincs `{name}` nevű terület. "
                f"Létezők: {sorted(self._areas)}."
            )
        self._active_areas.discard(name)
        self._manual_deactivated.add(name)
        self._manual_activated.discard(name)

    def is_area_active(self, name: str) -> bool:
        """Aktív-e a terület?

        Prioritási sorrend (M3.2):
          1. Kézi deaktiváció → mindig False
          2. Tanult routing OFF → eredeti viselkedés (`_active_areas`-ben van-e)
          3. Kézi aktiváció → mindig True
          4. Tanult routing dönt: max(goal.akt × routing) > küszöb
        """
        if name in self._manual_deactivated:
            return False
        if not self.tanult_routing:
            return name in self._active_areas
        if name in self._manual_activated:
            return True
        return (
            self._compute_routing_activation(name)
            > self.routing_aktivációs_küszöb
        )

    def routing_súly(self, goal_name: str, area_name: str) -> float:
        """A (cél, terület) routing-súly aktuális értéke.

        Ha még nem volt frissítve, a default 0.5-öt adja vissza.
        Klippelve [0, 1].
        """
        return self._routing_weights.get(
            (goal_name, area_name), self.DEFAULT_ROUTING_WEIGHT
        )

    def _compute_routing_activation(self, area_name: str) -> float:
        """A terület aggregált aktivációja: max(goal.akt × routing-súly).

        Cél nélkül 0.0 (semmi nem aktiválja).
        """
        if not self.goals:
            return 0.0
        return max(
            self.goals[g] * self.routing_súly(g, area_name)
            for g in self.goals
        )

    def list_areas(self) -> list[str]:
        """Az összes deklarált terület neve."""
        return list(self._areas.keys())

    def _is_belief_active(self, belief_name: str) -> bool:
        """Egy hiedelem aktív-e? Top-level (területen kívüli) hiedelmek
        MINDIG aktívak; területbeliek csak ha a terület aktív.
        """
        area = self._area_of.get(belief_name)
        if area is None:
            return True
        return area in self._active_areas

    # ─── Észlelés és reaktív frissítés (M3) ──────────────────────────────

    def észlel(self, **inputs: float) -> dict[str, float]:
        """Egy észlelés feldolgozása.

        Lépések:
          1. Validálja a paramétereket (ha van észlelés-blokk).
          2. Frissíti a context-et a kapott értékekkel.
          3. Megkeresi azokat a hiedelmeket, amelyek (transitíve) függenek
             a változott bemenetektől.
          4. Szűri őket az aktív területekre.
          5. Topo-sort a hiedelem-hiedelem függőségek szerint.
          6. Újraszámolja őket sorrendben.

        Visszatérés: dict[belief_név → új_confidence] csak az ÚJRASZÁMOLT
        hiedelmekre. A nem-érintettek értéke változatlan és nincs a dict-ben.
        """
        # 1. Validáció — ha van észlelés-blokk, csak deklarált paramok engedélyezettek.
        if self._perception_params:
            extra = set(inputs.keys()) - set(self._perception_params)
            if extra:
                raise ValueError(
                    f"Ismeretlen észlelés-paraméter(ek): {sorted(extra)}. "
                    f"A tudat `{self.decl.name}` ezeket deklarálja: "
                    f"{self._perception_params}."
                )

        # 2. Context frissítése — csak a TÉNYLEGESEN változott értékeket jelöljük.
        changed_names: set[str] = set()
        for name, val in inputs.items():
            # M6.3: szöveg-bemenet stringként marad; minden más float.
            new_val = val if isinstance(val, str) else float(val)
            old = self.context.get(name)
            self.context[name] = new_val
            if old != new_val:
                changed_names.add(name)

        if not changed_names:
            return {}  # semmi nem változott, semmit nem újraszámolunk

        # 3. Érintett hiedelmek (transitív lezárás).
        affected = self._affected_beliefs(changed_names)

        # 4. Szűrés aktív területekre.
        active_affected = {b for b in affected if self._is_belief_active(b)}

        # 5. Topo-sort.
        order = self._topological_order(active_affected)

        # 6. Újraszámolás.
        result: dict[str, float] = {}
        for belief in order:
            result[belief] = self.compute_belief(belief)

        # M4.2: észlelés-esemény, ha sok hiedelem változott
        if len(result) >= self.észlelés_jelentős_küszöb:
            self._record_event(
                "észlelés",
                belief_name=None,
                részletek={
                    "inputs": dict(inputs),
                    "changed_count": len(result),
                    "changed_beliefs": list(result.keys()),
                },
            )

        return result

    def _affected_beliefs(self, changed: set[str]) -> set[str]:
        """Transitív lezárás: minden hiedelem, amely közvetlenül vagy
        közvetve függ valamelyik változott névtől.

        Megjegyzés: ha egy hiedelem maga is "név", akkor a rajta függő
        hiedelmek is érintettek (belief-belief függés).
        """
        affected: set[str] = set()
        frontier = set(changed)
        while frontier:
            next_frontier: set[str] = set()
            for n in frontier:
                for b in self._dependents_of.get(n, ()):
                    if b not in affected:
                        affected.add(b)
                        # Egy belief maga is "név" lehet, amitől más belief függ.
                        next_frontier.add(b)
            frontier = next_frontier
        return affected

    def _topological_order(self, beliefs: set[str]) -> list[str]:
        """Kahn-féle topo-sort a hiedelem-hiedelem deps mentén,
        a megadott halmazon belül. Körkörös függés → hiba.
        """
        in_degree: dict[str, int] = {b: 0 for b in beliefs}
        for b in beliefs:
            for d in self._belief_deps.get(b, ()):
                if d in beliefs:
                    in_degree[b] += 1

        queue = [b for b in beliefs if in_degree[b] == 0]
        order: list[str] = []
        while queue:
            b = queue.pop(0)
            order.append(b)
            for other in beliefs:
                if b in self._belief_deps.get(other, ()) and other in in_degree:
                    in_degree[other] -= 1
                    if in_degree[other] == 0 and other not in order and other not in queue:
                        queue.append(other)

        if len(order) != len(beliefs):
            missing = beliefs - set(order)
            raise ValueError(
                f"Körkörös hiedelem-függőség észlelve: {sorted(missing)}. "
                f"Phase 1-ben ez nem támogatott — Phase 2+ kezeli."
            )
        return order


# ─────────────────────────────────────────────────────────────────────────────
# Függőség-analízis segédfüggvények (modul-szint)
# ─────────────────────────────────────────────────────────────────────────────


def _names_in_expr(expr: object) -> set[str]:
    """Rekurzív: összes Var-név egy kifejezésben."""
    if isinstance(expr, base_ast.Var):
        return {expr.name}
    if isinstance(expr, base_ast.Binary):
        return _names_in_expr(expr.left) | _names_in_expr(expr.right)
    if isinstance(expr, base_ast.Unary):
        return _names_in_expr(expr.operand)
    if isinstance(expr, base_ast.Call):
        names: set[str] = set()
        for a in expr.args:
            names |= _names_in_expr(a)
        return names
    if isinstance(expr, base_ast.Index):
        return _names_in_expr(expr.target) | _names_in_expr(expr.index)
    if isinstance(expr, base_ast.ListLit):
        names = set()
        for e in expr.elements:
            names |= _names_in_expr(e)
        return names
    return set()


def _collect_factor_deps(factor: object) -> set[str]:
    """Egy tényező által (statikusan) hivatkozott összes név."""
    if isinstance(factor, tudat_ast.NeuralFactor):
        return _names_in_expr(factor.expr)
    if isinstance(factor, tudat_ast.RuleFactor):
        return _names_in_expr(factor.condition) | _names_in_expr(factor.confidence)
    if isinstance(factor, tudat_ast.BeliefFactor):
        return {factor.belief_name}
    if isinstance(factor, tudat_ast.GoalFactor):
        return {factor.goal_name}
    if isinstance(factor, tudat_ast.SzövegFactor):
        # M6.3: a szöveg-tényező a bemenet-névtől függ — így a reaktív
        # újraszámolás elindul, amikor a szöveg-bemenet változik.
        return {factor.input_name}
    return set()


def _collect_belief_deps(decl: tudat_ast.BeliefDecl) -> set[str]:
    """Egy hiedelem összes faktorának egyesített név-függősége."""
    deps: set[str] = set()
    for f in decl.factors:
        deps |= _collect_factor_deps(f)
    return deps


def _factor_type_name(factor: object) -> str:
    """Rövid magyar név egy factor-példányhoz (tracing-hez)."""
    name = type(factor).__name__
    mapping = {
        "NeuralFactor": "neurális",
        "RuleFactor": "szabály",
        "BeliefFactor": "hiedelem",
        "GoalFactor": "cél",
        "SzövegFactor": "szöveg",
    }
    return mapping.get(name, name)


def _eval_scalar(expr: object, runtime: "TudatRuntime") -> float:
    """M4.1 segéd: kifejezés evaluálása, kötelezően skalárral.

    1-elemű tenzor kicsomagolható; multi-elem hiba.
    Használja: `_update_neural_weights` numerikus gradient-számolásnál.
    """
    result = _eval_expr(expr, runtime)
    if isinstance(result, ElTensor):
        if len(result.data) == 1:
            return float(result.data[0])
        raise ValueError(
            f"Skalárt vártam (tanulj numerikus gradient), kaptam {result.shape} tenzort."
        )
    return float(result)


def _noisy_or_gradients(values: list[float]) -> list[float]:
    """A Bayes-szerű noisy-OR aggregátum parciális deriváltjai.

    Aggregátum: A(p) = 1 − ∏(1 − pᵢ).
    ∂A/∂pⱼ = ∏ᵢ≠ⱼ(1 − pᵢ).

    Üres lista → üres lista. Egy elem → gradiens = 1.0.
    """
    n = len(values)
    if n == 0:
        return []
    clipped = [max(0.0, min(1.0, v)) for v in values]
    grads: list[float] = []
    for j in range(n):
        prod = 1.0
        for i in range(n):
            if i != j:
                prod *= 1.0 - clipped[i]
        grads.append(prod)
    return grads


def splitt(
    adatok: list,
    *,
    arány: float = 0.8,
    seed: int | None = None,
) -> tuple[list, list]:
    """Train/test split egy adatlistán (Phase 5 / M5.3).

    Random keverés, majd `arány` × len méretű train, többi test.
    Reprodukálható, ha `seed` adott.

    Visszatérés: `(train, test)`.
    """
    if not 0.0 < arány < 1.0:
        raise ValueError(f"`arány` 0 és 1 közötti kell legyen, kapott: {arány}")
    sorok = list(adatok)
    rng = random.Random(seed)
    indices = list(range(len(sorok)))
    rng.shuffle(indices)
    split_idx = int(len(sorok) * arány)
    train_idx = indices[:split_idx]
    test_idx = indices[split_idx:]
    return ([sorok[i] for i in train_idx], [sorok[i] for i in test_idx])


def _compute_meta_uncertainty(values: list[float], alpha: float) -> float:
    """Epistemikus meta-bizonytalanság számolása (Phase 2 / M2.2).

    Formula: α × minta_méret_büntetés + (1-α) × szétszórtság
      - minta_méret_büntetés = 1 / (1 + n)
      - szétszórtság = min(1.0, 2 × std(values))

    Speciális esetek:
      - n = 0 → 1.0 (nincs evidence, max bizonytalanság)
      - n = 1 → szórás nincs, csak a minta-méret büntetés számít (α × 0.5)

    A meta-bizonytalanság [0, 1] között marad. Aleatorikus rész
    (értékek 0.5 közelsége) NEM számít — csak epistemikus.
    """
    n = len(values)
    if n == 0:
        return 1.0

    # Minta-méret büntetés
    sample_penalty = 1.0 / (1.0 + n)

    # Szétszórtság (std × 2, klippelve)
    if n == 1:
        disagreement = 0.0
    else:
        mean = sum(values) / n
        variance = sum((v - mean) ** 2 for v in values) / n
        std = variance ** 0.5
        disagreement = min(1.0, 2.0 * std)

    return alpha * sample_penalty + (1.0 - alpha) * disagreement

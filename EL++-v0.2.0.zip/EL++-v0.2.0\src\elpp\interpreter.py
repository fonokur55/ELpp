"""Interpreter: AST végrehajtás (tree-walk, referencia / debug mód)."""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Any

from elpp import ast
from elpp.builtins.tensor import TENSOR_BUILTINS
from elpp.errors import RuntimeError, type_error, undefined_variable
from elpp.graph.runtime import GraphExecutor
from elpp.parser import parse
from elpp.reasoning.engine import ReasoningEngine
from elpp.runtime_values import Belief, ElTensor, FunctionValue
from elpp.synonyms import Dialect


class _ReturnSignal(Exception):
    def __init__(self, value: Any):
        self.value = value


class Interpreter:
    def __init__(self, stdout: Any = None, dialect: Dialect = "easy"):
        self.globals: dict[str, Any] = {}
        self.env_stack: list[dict[str, Any]] = [self.globals]
        self.stdout = stdout if stdout is not None else sys.stdout
        self.dialect = dialect
        self.reasoning = ReasoningEngine()
        self.graph = GraphExecutor()
        self.stats_cost = 0.0
        self._register_builtins()

    @property
    def env(self) -> dict[str, Any]:
        return self.env_stack[-1]

    def _register_builtins(self) -> None:
        for name, fn in TENSOR_BUILTINS.items():
            self.globals[name] = fn

    def run(self, program: ast.Program) -> None:
        self.dialect = program.dialect  # type: ignore[arg-type]
        for stmt in program.statements:
            self._exec_stmt(stmt)

    def run_source(self, source: str, dialect: Dialect = "easy") -> None:
        self.run(parse(source, dialect=dialect))

    def _push_env(self) -> None:
        self.env_stack.append({})

    def _pop_env(self) -> None:
        if len(self.env_stack) > 1:
            self.env_stack.pop()

    def _exec_stmt(self, stmt: ast.Stmt) -> Any:
        if isinstance(stmt, ast.Def):
            params = stmt.params
            self.env[stmt.name] = FunctionValue(
                stmt.name, params, stmt.body, dict(self.env)
            )
            return None

        if isinstance(stmt, ast.Return):
            val = self._eval(stmt.value) if stmt.value else None
            raise _ReturnSignal(val)

        if isinstance(stmt, ast.Let):
            self.env[stmt.name] = self._eval(stmt.value)
            return None

        if isinstance(stmt, ast.Print):
            parts = [self._format_value(self._eval(e)) for e in stmt.values]
            print(" ".join(parts), file=self.stdout)
            return None

        if isinstance(stmt, ast.If):
            if self._truthy(self._eval(stmt.condition)):
                for s in stmt.then_body:
                    self._exec_stmt(s)
            elif stmt.else_body:
                for s in stmt.else_body:
                    self._exec_stmt(s)
            return None

        if isinstance(stmt, ast.While):
            while self._truthy(self._eval(stmt.condition)):
                for s in stmt.body:
                    self._exec_stmt(s)
            return None

        if isinstance(stmt, ast.For):
            iterable = self._eval(stmt.iterable)
            if not isinstance(iterable, (list, tuple, str)):
                raise type_error("A for ciklus listát, tömböt vagy szöveget vár.", stmt.line)
            for item in iterable:
                self.env[stmt.var] = item
                for s in stmt.body:
                    self._exec_stmt(s)
            return None

        if isinstance(stmt, ast.Import):
            self._do_import(stmt.module, stmt.line)
            return None

        if isinstance(stmt, ast.Assume):
            conf = float(self._as_number(self._eval(stmt.confidence), stmt.line))
            self.reasoning.assume(stmt.claim, conf)
            self.env[stmt.claim] = Belief(stmt.claim, conf)
            return None

        if isinstance(stmt, ast.Rule):
            conf = float(self._as_number(self._eval(stmt.confidence), stmt.line))
            cond_val = self._eval(stmt.condition)
            key = (
                stmt.condition.name
                if isinstance(stmt.condition, ast.Var)
                else str(cond_val)
            )
            self.reasoning.add_rule(key, cond_val, stmt.conclusion, conf)
            return None

        if isinstance(stmt, ast.Query):
            result = self.reasoning.query(stmt.claim)
            if result:
                print(
                    f"{stmt.claim}: {result.confidence:.3f}",
                    file=self.stdout,
                )
            else:
                print(f"{stmt.claim}: ismeretlen", file=self.stdout)
            return None

        if isinstance(stmt, ast.GraphNodeDef):
            self.graph.define_node(
                stmt.node_id, stmt.op, stmt.inputs, stmt.cost
            )
            self.stats_cost += stmt.cost
            return None

        if isinstance(stmt, ast.RunGraph):
            val = self.graph.run(stmt.target)
            print(self._format_value(val), file=self.stdout)
            self.stats_cost += self.graph.total_cost
            return None

        if isinstance(stmt, ast.Train):
            epochs = int(self._as_number(self._eval(stmt.epochs), stmt.line))
            target = self.env.get(stmt.target)
            for ep in range(epochs):
                if isinstance(target, ElTensor):
                    pass
            print(f"train {stmt.target} epochs={epochs} loss={stmt.loss}", file=self.stdout)
            return None

        raise type_error("Ismeretlen utasítás.", getattr(stmt, "line", 0))

    def _do_import(self, module: str, line: int) -> None:
        base = Path.cwd()
        candidates = [
            base / f"{module}.elpp",
            base / f"{module}.elc",
            base / f"{module}.el",
            base / module / "__init__.elpp",
        ]
        for path in candidates:
            if path.exists():
                src = path.read_text(encoding="utf-8")
                from elpp.dialect import detect_dialect

                d = detect_dialect(src, path)
                prog = parse(src, dialect=d)
                self.run(prog)
                return
        raise RuntimeError(f"Modul nem található: {module}", line=line)

    def _call_function(self, fn: FunctionValue, args: list[Any]) -> Any:
        if len(args) != len(fn.params):
            raise type_error(
                f"{fn.name}(): {len(fn.params)} paraméter kell, {len(args)} adtál.",
                0,
            )
        self._push_env()
        frame = self.env_stack[-1]
        for k, v in fn.closure.items():
            if k not in frame:
                frame[k] = v
        for p, a in zip(fn.params, args):
            frame[p] = a
        result = None
        try:
            for s in fn.body:
                self._exec_stmt(s)
        except _ReturnSignal as ret:
            result = ret.value
        finally:
            self._pop_env()
        return result

    def _truthy(self, val: Any) -> bool:
        if isinstance(val, Belief):
            return val.confidence >= 0.5
        if isinstance(val, bool):
            return val
        if isinstance(val, (int, float)):
            return val != 0
        if isinstance(val, str):
            return len(val) > 0
        if isinstance(val, (list, dict)):
            return len(val) > 0
        return bool(val)

    def _format_value(self, val: Any) -> str:
        if isinstance(val, Belief):
            return f"{val.claim}({val.confidence:.2f})"
        if isinstance(val, ElTensor):
            return str(val)
        if isinstance(val, float) and val == int(val):
            return str(int(val))
        return str(val)

    def _eval(self, expr: ast.Expr) -> Any:
        if isinstance(expr, ast.Number):
            return int(expr.value) if expr.value == int(expr.value) else expr.value

        if isinstance(expr, ast.String):
            return expr.value

        if isinstance(expr, ast.Bool):
            return expr.value

        if isinstance(expr, ast.Var):
            if expr.name not in self.env:
                raise undefined_variable(expr.name, expr.line)
            return self.env[expr.name]

        if isinstance(expr, ast.ListLit):
            return [self._eval(e) for e in expr.elements]

        if isinstance(expr, ast.DictLit):
            return {
                self._eval(k): self._eval(v) for k, v in expr.pairs
            }

        if isinstance(expr, ast.Index):
            target = self._eval(expr.target)
            idx = self._eval(expr.index)
            if isinstance(target, (list, str)):
                return target[int(idx)]
            if isinstance(target, dict):
                return target[idx]
            raise type_error("Indexelés listán vagy szótáron működik.", expr.line)

        if isinstance(expr, ast.Call):
            args = [self._eval(a) for a in expr.args]
            callee = self.env.get(expr.name)
            if isinstance(callee, FunctionValue):
                return self._call_function(callee, args)
            if callable(callee):
                return callee(args)
            if expr.name in TENSOR_BUILTINS:
                return TENSOR_BUILTINS[expr.name](args)
            raise undefined_variable(expr.name, expr.line)

        if isinstance(expr, ast.Unary):
            v = self._eval(expr.operand)
            if expr.op == "NOT":
                return not self._truthy(v)
            if expr.op == "MINUS":
                return -self._as_number(v, expr.line)
            raise type_error(f"Ismeretlen operátor: {expr.op}", expr.line)

        if isinstance(expr, ast.Binary):
            if expr.op in ("AND", "OR"):
                left = self._truthy(self._eval(expr.left))
                if expr.op == "AND":
                    return left and self._truthy(self._eval(expr.right))
                return left or self._truthy(self._eval(expr.right))
            left = self._eval(expr.left)
            right = self._eval(expr.right)
            if expr.op in ("PLUS", "MINUS", "STAR", "SLASH"):
                if isinstance(left, str) or isinstance(right, str):
                    if expr.op == "PLUS":
                        return str(left) + str(right)
                    raise type_error("Szöveggel csak + működik.", expr.line)
                ln = self._as_number(left, expr.line)
                rn = self._as_number(right, expr.line)
                if expr.op == "PLUS":
                    return ln + rn
                if expr.op == "MINUS":
                    return ln - rn
                if expr.op == "STAR":
                    return ln * rn
                if expr.op == "SLASH":
                    if rn == 0:
                        raise type_error("Nullával nem lehet osztani.", expr.line)
                    return ln / rn
            if expr.op in ("EQ", "NE", "LT", "GT", "LE", "GE"):
                return self._compare(expr.op, left, right, expr.line)

        raise type_error("Ismeretlen kifejezés.", getattr(expr, "line", 0))

    def _as_number(self, val: Any, line: int) -> float:
        if isinstance(val, (int, float)):
            return float(val)
        if isinstance(val, bool):
            return 1.0 if val else 0.0
        raise type_error(f"Szám kell, nem: {type(val).__name__}", line)

    def _compare(self, op: str, left: Any, right: Any, line: int) -> bool:
        if isinstance(left, str) and isinstance(right, str):
            ops = {
                "EQ": left == right, "NE": left != right,
                "LT": left < right, "GT": left > right,
                "LE": left <= right, "GE": left >= right,
            }
            return ops[op]
        if isinstance(left, (int, float)) and isinstance(right, (int, float)):
            ops = {
                "EQ": left == right, "NE": left != right,
                "LT": left < right, "GT": left > right,
                "LE": left <= right, "GE": left >= right,
            }
            return ops[op]
        if isinstance(left, bool) and isinstance(right, bool) and op in ("EQ", "NE"):
            return left == right if op == "EQ" else left != right
        raise type_error(
            "Összehasonlításnál azonos típus kell.",
            line,
        )


def run_source(
    source: str, stdout: Any = None, dialect: Dialect = "easy"
) -> Interpreter:
    interp = Interpreter(stdout=stdout, dialect=dialect)
    interp.run_source(source, dialect=dialect)
    return interp

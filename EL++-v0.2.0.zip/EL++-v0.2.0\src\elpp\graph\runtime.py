"""Lazy gráf kiértékelés költségszámlálással."""

from __future__ import annotations

import math
from typing import Any, Callable

from elpp.runtime_values import ComputationGraph


class GraphExecutor:
    def __init__(self, confidence_threshold: float = 0.01) -> None:
        self.graph = ComputationGraph()
        self.confidence_threshold = confidence_threshold
        self._ops: dict[str, Callable[[list[Any]], Any]] = {
            "add": lambda xs: sum(float(x) for x in xs),
            "mul": lambda xs: math.prod(float(x) for x in xs) if xs else 1.0,
            "identity": lambda xs: xs[0] if xs else None,
        }
        self.env: dict[str, Any] = {}

    def define_node(
        self, node_id: str, op: str, inputs: list[str], cost: float = 1.0
    ) -> None:
        self.graph.add_node(node_id, op, inputs, cost)

    def set_input(self, name: str, value: Any) -> None:
        self.env[name] = value
        if name not in self.graph.nodes:
            self.graph.add_node(name, "input", [], cost=0.0)
        self.graph.nodes[name].value = value
        self.graph.nodes[name].computed = True

    def _eval_node(self, node_id: str, visiting: set[str]) -> Any:
        if node_id in self.env and (
            node_id not in self.graph.nodes
            or self.graph.nodes[node_id].computed
        ):
            return self.env[node_id]
        node = self.graph.nodes.get(node_id)
        if node is None:
            if node_id in self.env:
                return self.env[node_id]
            raise KeyError(f"Ismeretlen csomópont: {node_id}")
        if node.computed:
            return node.value
        if node_id in visiting:
            raise RuntimeError(f"Körkörös gráf: {node_id}")
        if node.cost < self.confidence_threshold and node.op != "input":
            return None
        visiting.add(node_id)
        vals = [self._eval_node(inp, visiting) for inp in node.inputs]
        op_fn = self._ops.get(node.op, self._ops["identity"])
        node.value = op_fn(vals)
        node.computed = True
        self.graph.total_cost += node.cost
        visiting.discard(node_id)
        return node.value

    def run(self, target: str) -> Any:
        return self._eval_node(target, set())

    @property
    def total_cost(self) -> float:
        return self.graph.total_cost

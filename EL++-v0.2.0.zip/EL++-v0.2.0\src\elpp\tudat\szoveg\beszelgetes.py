"""Önaware beszélgetés-kezelő — Phase 7 / M7.3.

Összeköti a kompozíciós generálót (M7.1) és az EL++ kifejezés-palettát (M7.2)
élő, több-körös párbeszéddé. A kulcs: a tudat KÖRÖNKÉNT A SAJÁT ÁLLAPOTÁBÓL
választ stratégiát — nincs előre megírt forgatókönyv:

  • meta-bizonytalanság magas →  tisztázó KÉRDÉS (nem tippel)
  • ellentmondás (feszültség)  →  „egyrészt… másrészt…" (ELLENPONT)
  • magabiztos hiedelem        →  grounded ÁLLÍTÁS (+ INDOK a tényezőből)
  • „miért?" a felhasználótól   →  a hiedelem MAGYARÁZATA beszéddé fordítva
  • helyesbítés                →  online TANULÁS, majd a frissült nézet kimondása

A `HiedelemPillanat`-okat a runtime tényleges hiedelmeiből építi (confidence,
meta-bizonytalanság, feszültség, domináns tényező). Grounded: csak a paletta
darabjaiból beszél, sosem talál ki szöveget.
"""

from __future__ import annotations

import pickle
from pathlib import Path
from typing import TYPE_CHECKING

from elpp.tudat.szoveg.generalas import Generáló, HiedelemPillanat

if TYPE_CHECKING:
    from elpp.tudat.runtime import TudatRuntime

# A felhasználói üzenetben felismert „miért?" kérdés jelei (egyszerű, grounded).
_MIÉRT_JELEK = ("miért", "miert", "mért", "why", "indokold", "magyarázd")

# A beszélgetés-mentés formátum verziója (a runtime-é külön: PERSISTENCE_VERSION).
BESZÉLGETÉS_VERZIÓ = "2.1"


class Beszélgetés:
    """Több-körös, önaware párbeszéd egy tudat-runtime körül.

    Paraméterek:
        runtime: a betanított TudatRuntime.
        fókusz_hiedelmek: mely hiedelmekről beszélhet (default: mind).
        üzenet_mező: melyik észlelési paraméter a felhasználó szabad szövege
            (ebben keressük a „miért?" jelet). Default: "üzenet".
        seed: reprodukálható megfogalmazás-variációhoz (körönként + lépésszám).
    """

    def __init__(
        self,
        runtime: "TudatRuntime",
        *,
        fókusz_hiedelmek: list[str] | None = None,
        üzenet_mező: str = "üzenet",
        kód_mező: str | None = None,
        seed: int | None = None,
        tanult_generátor: "tuple | None" = None,
    ) -> None:
        self.rt = runtime
        self.gen = Generáló(runtime.kifejezés_forrás())
        self.fókusz_hiedelmek = fókusz_hiedelmek or list(runtime.beliefs.keys())
        self.üzenet_mező = üzenet_mező
        # M8.4.c: ha meg van adva, ez az észlelési paraméter a beküldött KÓD —
        # erre konkrét, grounded diagnózist fűzünk a válaszhoz (AST-ből).
        self.kód_mező = kód_mező
        self._seed = seed
        self._lépés = 0
        self.történet: list[dict] = []
        self.legutóbbi_fókusz: str | None = None
        # M8.3.d: opcionális TANULT generátor (NyelvModell, Szótár). Ha be van
        # kötve, a fő válasz a tanult, belief-kondicionált modellből jön.
        self.tanult_generátor = tanult_generátor

    def csatol_tanult(self, modell, szótár) -> None:
        """Tanult, belief-kondicionált generátor bekötése (felülírja a sablonosat)."""
        self.tanult_generátor = (modell, szótár)

    # ── Publikus API ─────────────────────────────────────────────────────────

    def fordul(self, **bemenetek) -> str:
        """Egy beszélgetési kör: észlel → stratégia → grounded válasz.

        A `bemenetek` a tudat észlelési paraméterei (pl. diák_kódja=...,
        üzenet=...). Ha az üzenet-mező „miért?"-et tartalmaz, magyarázattal felel.
        """
        üzenet = str(bemenetek.get(self.üzenet_mező, "") or "")
        kód = bemenetek.get(self.kód_mező) if self.kód_mező else None
        van_kód = isinstance(kód, str) and bool(kód.strip())
        miért_kérdés = self._miért_kérdés(üzenet)

        # M8.4.c: ha VAN kód a körben, MINDIG észlelünk — a „miért nem megy"
        # többé nem irányít félre (a kódot meg kell néznünk!). Csak akkor
        # ugorjuk át az észlelést, ha tiszta meta-kérdés érkezik, kód nélkül.
        if bemenetek and (van_kód or not miért_kérdés):
            self.rt.észlel(**bemenetek)

        if miért_kérdés and not van_kód:
            válasz = self.miért()
        else:
            válasz = self._fő_válasz()

        # M8.4.c: konkrét, grounded diagnózis hozzáfűzése, ha van kód.
        if van_kód:
            diag = self._diagnózis_szöveg(kód)
            if diag:
                válasz = f"{válasz} {diag}".strip() if válasz else diag

        self._rögzít(bemenetek, válasz)
        return válasz

    def _diagnózis_szöveg(self, kód: str) -> str:
        """A kód legfontosabb konkrét megállapítása mondatként (AST-alapú, grounded).

        A blokkoló szintaktikai hiba elsőbbséget élvez; egyébként a legfontosabb
        minőségi javaslat. A dicséretet (rendben) nem ismételjük, ha a keret már pozitív."""
        from elpp.tudat.szoveg.diagnozis import diagnózis, szövegezd

        megáll = diagnózis(kód)
        if not megáll:
            return ""
        rang = {"hiba": 0, "javaslat": 1, "dicséret": 2}
        megáll.sort(key=lambda m: rang.get(m.súlyosság, 3))
        első = megáll[0]
        if első.kategória == "rendben":
            return ""  # a keret már kifejezi; ne legyen redundáns
        return szövegezd(első)

    def miért(self, hiedelem: str | None = None) -> str:
        """Egy hiedelem MAGYARÁZATA beszéddé fordítva (a „miért?"-re).

        A palettából INDOK-kal megtámasztott választ ad. Ha nincs paletta-darab,
        a tényleges tényező-nyomvonalra esik vissza (sosem talál ki — grounded).
        """
        b = hiedelem or self.legutóbbi_fókusz or self._alap_fókusz()
        if b is None:
            return ""
        p = self._pillanat(b, fókusz=True)
        szöveg = self.gen.generál([p], seed=self._kör_seed())
        if szöveg:
            return szöveg
        return self._nyomvonal_szöveg(b)

    def helyesbít(self, **célok: float) -> str:
        """Online korrekció: a tudat tanul a felhasználó javításából, majd
        kimondja a frissült nézetét."""
        self.rt.tanulj(**célok)
        válasz = self._fő_válasz()
        self._rögzít({"helyesbítés": dict(célok)}, válasz)
        return válasz

    def előzmény(self) -> list[dict]:
        """A beszélgetés eddigi köreinek listája (másolat)."""
        return [dict(k) for k in self.történet]

    # ── Perzisztencia (M7.5) ──────────────────────────────────────────────────

    def ments(self, útvonal: "str | Path") -> None:
        """A teljes beszélgetés mentése (tudat + paletta + előzmény).

        A `gen` újraépíthető a runtime palettájából, ezért nem mentjük —
        betöltéskor frissen készül. Így a runtime marad az egyetlen forrás."""
        útvonal = Path(útvonal)
        útvonal.parent.mkdir(parents=True, exist_ok=True)
        csomag = {
            "version": BESZÉLGETÉS_VERZIÓ,
            "runtime": self.rt,
            "fókusz_hiedelmek": self.fókusz_hiedelmek,
            "üzenet_mező": self.üzenet_mező,
            "seed": self._seed,
            "lépés": self._lépés,
            "történet": self.történet,
            "legutóbbi_fókusz": self.legutóbbi_fókusz,
        }
        with open(útvonal, "wb") as f:
            pickle.dump(csomag, f)

    @classmethod
    def betölt(cls, útvonal: "str | Path") -> "Beszélgetés":
        """Mentett beszélgetés visszaállítása (a generáló frissen épül)."""
        with open(útvonal, "rb") as f:
            csomag = pickle.load(f)
        if not isinstance(csomag, dict) or csomag.get("version") != BESZÉLGETÉS_VERZIÓ:
            raise ValueError(
                f"Inkompatibilis beszélgetés-mentés: `{útvonal}` "
                f"(verzió: {csomag.get('version') if isinstance(csomag, dict) else '?'})."
            )
        b = cls(
            csomag["runtime"],
            fókusz_hiedelmek=csomag["fókusz_hiedelmek"],
            üzenet_mező=csomag["üzenet_mező"],
            seed=csomag["seed"],
        )
        b._lépés = csomag["lépés"]
        b.történet = csomag["történet"]
        b.legutóbbi_fókusz = csomag["legutóbbi_fókusz"]
        return b

    # ── Belső: válasz-építés ──────────────────────────────────────────────────

    def _fő_válasz(self) -> str:
        pillanatok = self._pillanatok()   # frissíti a legutóbbi_fókuszt is
        if self.tanult_generátor is not None:
            return self._tanult_válasz()
        return self.gen.generál(pillanatok, seed=self._kör_seed())

    def _tanult_válasz(self) -> str:
        """A tanult, belief-kondicionált generátor válasza (M8.3.d).

        A kondíció a fókusz-hiedelmek AKTUÁLIS confidence-eiből áll össze (fix
        sorrendben), így a tudat hiedelmei vezérlik a tanult modellt → grounded.
        """
        from elpp.tudat.szoveg.grounded import (
            generál_állapotból,
            kondíció_vektor,
        )

        modell, szótár = self.tanult_generátor
        állapot = {b: self.rt.compute_belief(b) for b in self.fókusz_hiedelmek}
        kondíció = kondíció_vektor(állapot, self.fókusz_hiedelmek)
        return generál_állapotból(
            modell, szótár, kondíció, hőmérséklet=0.3, seed=self._kör_seed()
        )

    def _pillanatok(self) -> list[HiedelemPillanat]:
        """A fókusz-hiedelmekből pillanatképek; a legjelentősebbet fókusznak
        jelöli (ezt mindig kimondja)."""
        nyers: list[tuple[float, str]] = []
        for b in self.fókusz_hiedelmek:
            conf = self.rt.compute_belief(b)
            meta = self.rt.meta_bizonytalanság(b)
            # Jelentősség: erős vélemény VAGY magas bizonytalanság (kérdezni kell).
            sal = max(meta, abs(conf - 0.5) * 2.0)
            nyers.append((sal, b))
        if not nyers:
            return []
        fókusz_b = max(nyers, key=lambda x: x[0])[1]
        self.legutóbbi_fókusz = fókusz_b
        return [self._pillanat(b, fókusz=(b == fókusz_b)) for _, b in nyers]

    def _pillanat(self, belief: str, *, fókusz: bool) -> HiedelemPillanat:
        conf = self.rt.compute_belief(belief)
        meta = self.rt.meta_bizonytalanság(belief)
        fesz = self.rt.feszültség(belief)
        return HiedelemPillanat(
            név=belief,
            confidence=conf,
            meta_bizonytalanság=meta,
            feszültség=fesz,
            fókusz=fókusz,
            indok=self._domináns_indok(belief),
        )

    def _domináns_indok(self, belief: str) -> str | None:
        """A legerősebb (legnagyobb értékű) tényező leírása — INDOK-triggerhez.

        A tényleges INDOK-szöveg a palettából jön; ez csak eldönti, VAN-e mire
        indokot fűzni (tüzelt-e tényező)."""
        nyomok = self.rt.list_factors(belief)
        if not nyomok:
            self.rt.compute_belief(belief)
            nyomok = self.rt.list_factors(belief)
        if not nyomok:
            return None
        legjobb = max(nyomok, key=lambda t: t.value)
        return legjobb.description if legjobb.value > 0 else None

    def _nyomvonal_szöveg(self, belief: str) -> str:
        """Fallback magyarázat a tényleges tényező-nyomvonalból (ha nincs paletta).

        Nem talál ki prózát — a tudat saját nyomvonalát sorolja fel."""
        magy = self.rt.magyarázd(belief)
        sorok = [f"A(z) `{belief}` bizonyosságom {magy.confidence:.2f}."]
        for tr in magy.factor_traces:
            sorok.append(f"  • {tr.description}")
        return "\n".join(sorok)

    # ── Belső: segédek ─────────────────────────────────────────────────────────

    def _miért_kérdés(self, üzenet: str) -> bool:
        a = üzenet.lower()
        return any(jel in a for jel in _MIÉRT_JELEK)

    def _alap_fókusz(self) -> str | None:
        return self.fókusz_hiedelmek[0] if self.fókusz_hiedelmek else None

    def _kör_seed(self) -> int | None:
        return None if self._seed is None else self._seed + self._lépés

    def _rögzít(self, bemenetek: dict, válasz: str) -> None:
        self.történet.append({"bemenetek": dict(bemenetek), "válasz": válasz})
        self._lépés += 1

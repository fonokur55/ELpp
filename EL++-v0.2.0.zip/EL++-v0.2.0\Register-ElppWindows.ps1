# Windows .elpp fajltarsitas es ikon (HKCU – admin jog NEM kell)
# Hasznalat: . .\Register-ElppWindows.ps1; Register-ElppWindowsAssociation

function Notify-ShellAssociationChanged {
    if (-not ("ShellNotify" -as [type])) {
        Add-Type @"
using System;
using System.Runtime.InteropServices;
public class ShellNotify {
    [DllImport("shell32.dll")]
    public static extern void SHChangeNotify(int eventId, int flags, IntPtr item1, IntPtr item2);
}
"@
    }
    [ShellNotify]::SHChangeNotify(0x08000000, 0, [IntPtr]::Zero, [IntPtr]::Zero)
}

function Restart-ExplorerIconCache {
    # BIZTONSAGOS ikon-frissites.
    # A regi valtozat kiloite az Explorert ES letorolte az OSSZES
    # iconcache*/thumbcache* fajlt. Emiatt nemcsak a .elpp, hanem a TOBBI
    # kiterjesztes ikonja is ures (feher) lapra valtott, amig a rendszer
    # ujra nem epitette a gyorsitotarat (neha csak reboot utan).
    #
    # Helyette a Windows beepitett, tamogatott ie4uinit.exe-jet hasznaljuk:
    # csak az ikon-gyorsitotarat frissiti (a rendszer igeny szerint ujraepiti
    # az egyes ikonokat a sajat forrasukbol), az Explorert NEM loji ki, a
    # thumbnaileket NEM bantja -> tobbe nem serulnek a tobbi tipus ikonjai.
    $ie4 = Join-Path $env:WINDIR "System32\ie4uinit.exe"
    if (Test-Path $ie4) {
        & $ie4 -show 2>$null
        & $ie4 -ClearIconCache 2>$null
    }
    Notify-ShellAssociationChanged
}

function Set-ElppUserChoiceDefault {
    param([Parameter(Mandatory = $true)][string]$ProgId)

    $userChoiceScript = Join-Path $PSScriptRoot "scripts\win-userchoice.ps1"
    if (-not (Test-Path $userChoiceScript)) {
        Write-Host "  ! win-userchoice.ps1 hianyzik" -ForegroundColor Yellow
        return $false
    }
    . $userChoiceScript
    try {
        Set-ElppDefaultFileAssociation -Extension ".elpp" -ProgId $ProgId | Out-Null
        return $true
    } catch {
        Write-Host "  ! UserChoice beallitas sikertelen: $_" -ForegroundColor Yellow
        return $false
    }
}

function Register-ElppWindowsAssociation {
    param(
        [Parameter(Mandatory = $true)][string]$IcoPath,
        [Parameter(Mandatory = $true)][string]$WrapperPath
    )

    if (-not (Test-Path $IcoPath)) {
        Write-Host "  ! Ikon hianyzik: $IcoPath" -ForegroundColor Yellow
        return $false
    }
    if (-not (Test-Path $WrapperPath)) {
        Write-Host "  ! Wrapper hianyzik: $WrapperPath" -ForegroundColor Yellow
        return $false
    }

    $progId = "ELplusplus.elpp"
    $extKey = "HKCU:\Software\Classes\.elpp"
    $typeKey = "HKCU:\Software\Classes\$progId"
    $iconValue = "$IcoPath,0"

    New-Item -Path $extKey -Force | Out-Null
    Set-ItemProperty -Path $extKey -Name "(Default)" -Value $progId
    New-Item -Path "$extKey\DefaultIcon" -Force | Out-Null
    Set-ItemProperty -Path "$extKey\DefaultIcon" -Name "(Default)" -Value $iconValue
    Set-ItemProperty -Path $extKey -Name "PerceivedType" -Value "document" -ErrorAction SilentlyContinue

    New-Item -Path $typeKey -Force | Out-Null
    Set-ItemProperty -Path $typeKey -Name "(Default)" -Value "EL++ program"
    Set-ItemProperty -Path $typeKey -Name "FriendlyTypeName" -Value "EL++ program"
    New-Item -Path "$typeKey\DefaultIcon" -Force | Out-Null
    Set-ItemProperty -Path "$typeKey\DefaultIcon" -Name "(Default)" -Value $iconValue

    New-Item -Path "$typeKey\shell\open\command" -Force | Out-Null
    Set-ItemProperty -Path "$typeKey\shell\open\command" -Name "(Default)" -Value "`"$WrapperPath`" `"%1`""

    # Regi .el tarsitas torlese (ha volt)
    Remove-Item -Path "HKCU:\Software\Classes\.el" -Recurse -Force -ErrorAction SilentlyContinue

    # VS Code UserChoice felulirhatja az ikont – hash-sel allitjuk EL++-ra
    $userChoiceOk = Set-ElppUserChoiceDefault -ProgId $progId
    if (-not $userChoiceOk) {
        Write-Host "  ! Alapertelmezett app: jobb klikk .elpp -> Tovabbi beallitasok -> Asztal valtoztatasa -> EL++ program" -ForegroundColor Yellow
    }

    Notify-ShellAssociationChanged
    return $true
}

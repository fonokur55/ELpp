"""Dialect felismerés forrásból vagy fájlnévből."""

from __future__ import annotations

import re
from pathlib import Path

from elpp.synonyms import Dialect

_SHEBANG = re.compile(r"^#!elpp\s+(easy|core)\b", re.IGNORECASE)


def detect_dialect(source: str, path: Path | None = None) -> Dialect:
    if path is not None:
        if path.suffix.lower() == ".elc":
            return "core"
        if path.suffix.lower() in (".elpp", ".el"):
            pass
    first_lines = source.splitlines()[:3]
    for line in first_lines:
        m = _SHEBANG.match(line.strip())
        if m:
            return "core" if m.group(1).casefold() == "core" else "easy"
    if path is not None and path.suffix.lower() == ".elc":
        return "core"
    return "easy"

#!/usr/bin/env python3
"""KódTanár (szöveg) — Interaktív bemutató CLI (Phase 6 / M6.4).

A klasszikus KódTanár demótól eltérően ITT a tudat NYERS SZÖVEGET olvas:
bemásolod a diák kódját és üzenetét, és a tudat onnantól értelmesen reagál —
senki nem ad meg kézzel kiszámolt számokat.

Indítás:
    python scripts/kodtanar_szöveg_demo.py

Funkciók:
    • Modell betanítása a hibrid adatból (20 mag + 30 szintetikus)
    • Held-out értékelés (becsületes pontosság)
    • Interaktív elemzés: kód + üzenet beírása → hiedelmek + magyarázat
"""

from __future__ import annotations

import sys
from pathlib import Path

# Windows console UTF-8-ra (Unicode box-drawing + ékezetek miatt)
if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    except (AttributeError, OSError):
        pass

ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "examples" / "ai"))

from elpp.parser import parse  # noqa: E402
from elpp.tudat import TudatRuntime  # noqa: E402

import kodtanar_szöveg_adat as kd  # noqa: E402
import kodtanar_szöveg_eval as ev  # noqa: E402

MODELL_PATH = ROOT / "examples" / "ai" / "kodtanar_szöveg.elpp"

# Az M6.4 kísérletben bevált hiperparaméterek (gyenge a legnehezebb belief).
EPOCHOK = 100
TANULÁSI_RÁTA = 0.5


# ─── Kiírás-segédek ─────────────────────────────────────────────────────────


def fej(címe: str) -> None:
    sáv = "═" * (len(címe) + 4)
    print(f"\n╔{sáv}╗\n║  {címe}  ║\n╚{sáv}╝")


# ─── Modell betöltése + tanítása (tesztelhető, újrahasználható) ──────────────


def betölt_és_tanít(*, seed: int = 1, epochok: int = EPOCHOK) -> TudatRuntime:
    """Friss tudatot épít a .elpp-ből és betanítja a hibrid adatból."""
    src = MODELL_PATH.read_text(encoding="utf-8")
    rt = TudatRuntime(parse(src).statements[0], seed=seed)
    rt.fit(
        kd.tanító_adat(seed=42),
        célok=kd.CÉLOK,
        epochok=epochok,
        tanulási_ráta=TANULÁSI_RÁTA,
    )
    return rt


def elemez(rt: TudatRuntime, kód: str, üzenet: str) -> dict[str, float]:
    """Egy (kód, üzenet) pár elemzése → {hiedelem: confidence}."""
    rt.észlel(diák_kódja=kód, diák_üzenete=üzenet)
    return {b: rt.compute_belief(b) for b in kd.CÉLOK}


def értékelés_kiírása(rt: TudatRuntime) -> None:
    fej("Held-out értékelés (a tudat ezeket tanítva NEM látta)")
    m = rt.értékelés(ev.eval_adat(), célok=kd.CÉLOK)
    for b, d in m.items():
        print(
            f"  {b:20s} pontosság={d['pontosság']:.2f}  "
            f"MAE={d['átlagos_hiba']:.3f}  (n={d['n']})"
        )


def elemzés_kiírása(rt: TudatRuntime, kód: str, üzenet: str) -> None:
    értékek = elemez(rt, kód, üzenet)
    print("\n  A tudat olvasata:")
    for b, v in értékek.items():
        sáv = "█" * int(v * 20)
        print(f"    {b:20s} {v:.2f}  {sáv}")
    # Magyarázat a legerősebb hiedelemre.
    legerősebb = max(értékek, key=értékek.get)
    print(f"\n  Miért `{legerősebb}`?")
    for tr in rt.magyarázd(legerősebb).factor_traces:
        print(f"    • {tr.description}")


# ─── Interaktív loop ─────────────────────────────────────────────────────────


def _olvass_több_sort(prompt: str) -> str:
    print(prompt + " (üres sor = vége):")
    sorok: list[str] = []
    while True:
        try:
            sor = input("    ")
        except EOFError:
            break
        if sor == "":
            break
        sorok.append(sor)
    return "\n".join(sorok)


def interaktív(rt: TudatRuntime) -> None:
    fej("Interaktív elemzés — írd be a diák kódját és üzenetét")
    print("(Kilépés: üres kód.)")
    while True:
        kód = _olvass_több_sort("\nDiák kódja")
        if not kód.strip():
            print("\nViszlát! 👋")
            return
        üzenet = input("Diák üzenete: ")
        elemzés_kiírása(rt, kód, üzenet)


def main() -> None:
    fej("KódTanár (szöveg) — Phase 6 demo")
    print("• Modell tanítása a hibrid adatból (20 mag + 30 szintetikus)...")
    rt = betölt_és_tanít()
    print("  ✓ kész.")
    értékelés_kiírása(rt)
    interaktív(rt)


if __name__ == "__main__":
    main()

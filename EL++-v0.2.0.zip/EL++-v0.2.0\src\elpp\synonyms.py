"""HU/EN kulcsszavak és szinonimák → belső token nevek."""

from __future__ import annotations

from typing import Literal

Dialect = Literal["easy", "core"]

TOKEN_KINDS = (
    "LET", "IF", "THEN", "ELSE", "END", "WHILE", "PRINT",
    "DEF", "FN", "RETURN", "FOR", "IN", "IMPORT",
    "ASSUME", "RULE", "QUERY", "CONF",
    "NODE", "RUN", "COST", "TENSOR", "TRAIN",
    # Tudat alrendszer (Phase 1 / M1): csontváz-tokenek
    "TUDAT", "AREA", "BELIEF_DECL", "WEIGHT_DECL", "GOAL_DECL",
    # Tudat alrendszer (Phase 1 / M2): tényezők
    "FACTOR", "FROM", "NEURAL",
    # Tudat alrendszer (Phase 8 / M8.2): előjeles (ellen) evidencia
    "ELLEN",
    # Tudat alrendszer (Phase 6 / M6.3): szöveg-tényező
    "SZÖVEG",
    # Tudat alrendszer (Phase 7 / M7.2): kifejezés-blokk (válasz-paletta)
    "KIFEJEZÉS",
    # Tudat alrendszer (Phase 1 / M3): észlelés
    "PERCEPTION",
    # Tudat alrendszer (Phase 1 / M4): önreflexió
    "REFLECTION", "EXPLAIN",
    # Tudat alrendszer (Phase 1 / M5): tanulás
    "TRAINING", "LEARN",
    # Tudat alrendszer (Phase 2 / M2.1): hipotetikus
    "WHAT_IF",
    "EQ", "NE", "LT", "GT", "LE", "GE",
    "AND", "OR", "NOT", "ARROW",
    "PLUS", "MINUS", "STAR", "SLASH",
    "LPAREN", "RPAREN", "LBRACKET", "RBRACKET",
    "LBRACE", "RBRACE", "COMMA", "COLON",
    "TRUE", "FALSE",
    "NUMBER", "STRING", "IDENT",
    "NEWLINE", "EOF",
)

FILLER_WORDS: frozenset[str] = frozenset({
    "az", "the", "hogy", "that",
    "also", "pedig",
})

_PHRASES: list[tuple[str, str]] = [
    # WHILE
    ("ismételd amíg", "WHILE"),
    ("repeat while", "WHILE"),
    ("amíg", "WHILE"),
    ("while", "WHILE"),
    # FOR
    ("minden", "FOR"),
    ("for each", "FOR"),
    ("for", "FOR"),
    # PRINT
    ("írd ki", "PRINT"),
    ("ird ki", "PRINT"),
    ("mutasd", "PRINT"),
    ("print", "PRINT"),
    ("show", "PRINT"),
    ("say", "PRINT"),
    # Comparisons
    ("nagyobb egyen", "GE"),
    ("greater than or equal", "GE"),
    ("greater than or equal to", "GE"),
    ("at least", "GE"),
    ("legalább", "GE"),
    ("kisebb egyen", "LE"),
    ("less than or equal", "LE"),
    ("less than or equal to", "LE"),
    ("at most", "LE"),
    ("legfeljebb", "LE"),
    ("nagyobb mint", "GT"),
    ("greater than", "GT"),
    ("is above", "GT"),
    ("kisebb mint", "LT"),
    ("less than", "LT"),
    ("is below", "LT"),
    ("nem egyen", "NE"),
    ("not equal to", "NE"),
    ("not equal", "NE"),
    ("does not equal", "NE"),
    # DEF / RETURN
    ("függvény", "DEF"),
    ("fuggveny", "DEF"),
    ("function", "DEF"),
    ("def", "DEF"),
    ("vissza", "RETURN"),
    ("return", "RETURN"),
    # IMPORT
    ("tölts be", "IMPORT"),
    ("tolts be", "IMPORT"),
    ("load", "IMPORT"),
    ("import", "IMPORT"),
    # Belief / AI
    ("feltételezem", "ASSUME"),
    ("feltetelezem", "ASSUME"),
    ("assume", "ASSUME"),
    ("tudom hogy", "ASSUME"),
    ("szabály", "RULE"),
    ("szabaly", "RULE"),
    ("rule", "RULE"),
    ("kérdés", "QUERY"),
    ("kerdes", "QUERY"),
    ("query", "QUERY"),
    ("bizonyosság", "CONF"),
    ("bizonyossag", "CONF"),
    ("confidence", "CONF"),
    ("conf", "CONF"),
    # Graph
    ("csomópont", "NODE"),
    ("csomopont", "NODE"),
    ("node", "NODE"),
    ("futtasd graf", "RUN"),
    ("run graph", "RUN"),
    ("költség", "COST"),
    ("koltseg", "COST"),
    ("cost", "COST"),
    # Tensor / train
    ("tenzor", "TENSOR"),
    ("tensor", "TENSOR"),
    ("taníts", "TRAIN"),
    ("tanits", "TRAIN"),
    ("train", "TRAIN"),
    # Tudat alrendszer (Phase 1 / M1)
    # Központi fogalmak — magyar és angol szinonimákkal.
    # A `tudat` az AI-paradigma fő építőeleme; az `elme` és `mind`
    # azonos jelentésű (lásd Phase 0 döntés).
    ("tudat", "TUDAT"),
    ("elme", "TUDAT"),
    ("mind", "TUDAT"),
    ("terület", "AREA"),
    ("terulet", "AREA"),
    ("area", "AREA"),
    ("region", "AREA"),
    ("hiedelem", "BELIEF_DECL"),
    ("belief", "BELIEF_DECL"),
    ("súly", "WEIGHT_DECL"),
    ("suly", "WEIGHT_DECL"),
    ("weight", "WEIGHT_DECL"),
    ("cél", "GOAL_DECL"),
    ("cel", "GOAL_DECL"),
    ("goal", "GOAL_DECL"),
    # Tudat alrendszer (Phase 1 / M2): tényezők
    # `hiedelem X jön: tényező neurális ... kész`
    ("tényező", "FACTOR"),
    ("tenyezo", "FACTOR"),
    ("factor", "FACTOR"),
    ("jön", "FROM"),
    ("jon", "FROM"),
    ("comes", "FROM"),
    ("from", "FROM"),
    ("neurális", "NEURAL"),
    ("neuralis", "NEURAL"),
    ("neural", "NEURAL"),
    # Tudat alrendszer (Phase 8 / M8.2): `tényező ellen ...` — kivonó evidencia
    ("ellen", "ELLEN"),
    ("against", "ELLEN"),
    # Tudat alrendszer (Phase 6 / M6.3): szöveg-tényező
    # `tényező szöveg(diák_kódja, dim=128, érzékeny=nem)`
    ("szöveg", "SZÖVEG"),
    ("szoveg", "SZÖVEG"),
    ("text", "SZÖVEG"),
    # Tudat alrendszer (Phase 1 / M3): észlelés
    # `észlelés (felhő, ...): ... kész` — a tudat bemeneti kapuja.
    ("észlelés", "PERCEPTION"),
    ("eszleles", "PERCEPTION"),
    ("perception", "PERCEPTION"),
    ("perceive", "PERCEPTION"),
    # Tudat alrendszer (Phase 1 / M4): önreflexió
    # `reflexió "címke": magyarázd <név> ... kész`
    ("reflexió", "REFLECTION"),
    ("reflexio", "REFLECTION"),
    ("reflection", "REFLECTION"),
    ("magyarázd", "EXPLAIN"),
    ("magyarazd", "EXPLAIN"),
    ("explain", "EXPLAIN"),
    # Tudat alrendszer (Phase 7 / M7.2): kifejezés-blokk
    # `kifejezés <hiedelem>: <szerep> <sáv>: "darab", ... kész`
    ("kifejezés", "KIFEJEZÉS"),
    ("kifejezes", "KIFEJEZÉS"),
    ("expression", "KIFEJEZÉS"),
    # Tudat alrendszer (Phase 1 / M5): tanulás
    # `tanulás[(params)]: tanulj <belief> -> <expr> ... kész`
    # M5-ben a body parse-ol, de a tényleges tanulás Python API-n megy.
    ("tanulás", "TRAINING"),
    ("tanulas", "TRAINING"),
    ("training", "TRAINING"),
    ("tanulj", "LEARN"),
    ("learn", "LEARN"),
    # Tudat alrendszer (Phase 2 / M2.1): hipotetikus kérdezés
    # `mi_lenne_ha "címke" (W = 0.8, ...): magyarázd ... kész`
    # FONTOS: a "mi lenne ha" (több szavas) elsőbbséget kell kapjon
    # a "mi" / "lenne" / "ha" elől, ezért a frázis-sorrend (hossz szerinti
    # rendezés a synonyms.py végén) ezt magától megoldja.
    ("mi_lenne_ha", "WHAT_IF"),
    ("mi lenne ha", "WHAT_IF"),
    ("what_if", "WHAT_IF"),
    ("what if", "WHAT_IF"),
    # LET
    ("állítsd be", "LET"),
    ("allitsd be", "LET"),
    ("legyen", "LET"),
    ("állíts", "LET"),
    ("allits", "LET"),
    ("tegyük", "LET"),
    ("tegyuk", "LET"),
    ("make", "LET"),
    ("let", "LET"),
    ("set", "LET"),
    # IF / THEN / ELSE / END
    ("amennyiben", "IF"),
    ("ha", "IF"),
    ("when", "IF"),
    ("if", "IF"),
    ("akkor", "THEN"),
    ("then", "THEN"),
    ("egyébként", "ELSE"),
    ("egyebkent", "ELSE"),
    ("különben", "ELSE"),
    ("kulonben", "ELSE"),
    ("otherwise", "ELSE"),
    ("else", "ELSE"),
    ("vége", "END"),
    ("vege", "END"),
    ("kész", "END"),
    ("kesz", "END"),
    ("done", "END"),
    ("end", "END"),
    # EQ
    ("egyenlő", "EQ"),
    ("egyenlo", "EQ"),
    ("egyen", "EQ"),
    ("equals", "EQ"),
    ("equal to", "EQ"),
    ("equal", "EQ"),
    # AND / OR / NOT
    ("és", "AND"),
    ("and", "AND"),
    ("vagy", "OR"),
    ("or", "OR"),
    ("nem", "NOT"),
    ("not", "NOT"),
    # IN
    ("között", "IN"),
    ("kozott", "IN"),
    ("in", "IN"),
    # Boolean
    ("hamis", "FALSE"),
    ("false", "FALSE"),
    ("igaz", "TRUE"),
    ("true", "TRUE"),
    ("to", "EQ"),
    ("is", "EQ"),
]

# Core dialect: rövid kulcsszavak (elsőbbség easy felett core módban)
_CORE_PHRASES: list[tuple[str, str]] = [
    ("fn", "FN"),
    ("def", "DEF"),
    ("let", "LET"),
    ("if", "IF"),
    ("then", "THEN"),
    ("else", "ELSE"),
    ("end", "END"),
    ("while", "WHILE"),
    ("for", "FOR"),
    ("in", "IN"),
    ("return", "RETURN"),
    ("print", "PRINT"),
    ("import", "IMPORT"),
    ("assume", "ASSUME"),
    ("rule", "RULE"),
    ("query", "QUERY"),
    ("conf", "CONF"),
    ("node", "NODE"),
    ("run", "RUN"),
    ("cost", "COST"),
    ("tensor", "TENSOR"),
    ("train", "TRAIN"),
    ("and", "AND"),
    ("or", "OR"),
    ("not", "NOT"),
    ("true", "TRUE"),
    ("false", "FALSE"),
    ("->", "ARROW"),
]

PHRASE_TO_KIND: list[tuple[str, str]] = sorted(
    _PHRASES, key=lambda p: len(p[0]), reverse=True
)

CORE_PHRASE_TO_KIND: list[tuple[str, str]] = sorted(
    _CORE_PHRASES + _PHRASES, key=lambda p: len(p[0]), reverse=True
)

SYMBOLS: dict[str, str] = {
    "=": "EQ",
    "+": "PLUS",
    "-": "MINUS",
    "*": "STAR",
    "/": "SLASH",
    "(": "LPAREN",
    ")": "RPAREN",
    "[": "LBRACKET",
    "]": "RBRACKET",
    "{": "LBRACE",
    "}": "RBRACE",
    ",": "COMMA",
    ":": "COLON",
    "<=": "LE",
    ">=": "GE",
    "<": "LT",
    ">": "GT",
    "==": "EQ",
    "!=": "NE",
    "->": "ARROW",
}

COMMENT_STARTERS: tuple[str, ...] = ("#", "//", "megjegyzés:", "megjegyzes:", "note:")


def phrases_for_dialect(dialect: Dialect) -> list[tuple[str, str]]:
    if dialect == "core":
        return CORE_PHRASE_TO_KIND
    return PHRASE_TO_KIND


def use_fillers(dialect: Dialect) -> bool:
    return dialect == "easy"

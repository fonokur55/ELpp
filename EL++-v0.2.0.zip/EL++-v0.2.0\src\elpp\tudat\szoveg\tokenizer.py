"""Tokenizáció + szótár — Phase 6 / M6.1.

A `tudat` szöveg-támogatásának legalsó rétege: nyers szövegből (kód, üzenet,
dokumentum) tokenek listáját, majd a szótáron át token→index leképezést készít.

**Tervezési döntések (lásd memory/project_phase6_scope.md):**
  • D1 — szavas, Unicode-aware tokenizáció: `\\w+` (betűk + számok + `_`,
    ékezetekkel együtt) VAGY egyetlen írásjel/szimbólum. Így `range(10)` →
    `range`, `(`, `10`, `)`, és `nem!!!` → `nem`, `!`, `!`, `!`
    (a felkiáltójelek mint frusztráció-jel megőrződnek).
  • D6 — nyelv-agnosztikus: a szótár a korpuszból épül, nincs beégetett nyelv.
    A magyar ékezetes betűk (á é í ó ö ő ú ü ű) megőrződnek.
  • D7 — nincs kemény hossz-limit, csak figyelmeztetés `>500` token felett.
  • Finomítás #1 — case-sensitivity konfigurálható: `Tokenizer(case_sensitive=True)`
    a default (információ-megőrző). Kódhoz `igen`, szabad szöveghez `nem` ajánlott.

Speciális tokenek a szótárban (mindig jelen, fix index):
  • `<padding>`    → 0  (fix hosszú szekvenciák feltöltéséhez, M6.2)
  • `<ismeretlen>` → 1  (OOV — a szótárban nem szereplő token)
"""

from __future__ import annotations

import re
import warnings
from collections import Counter
from typing import Iterable

# ─────────────────────────────────────────────────────────────────────────────
# Speciális tokenek
# ─────────────────────────────────────────────────────────────────────────────

PADDING = "<padding>"
ISMERETLEN = "<ismeretlen>"

PADDING_INDEX = 0
ISMERETLEN_INDEX = 1

# Egy "szó" (betűk + számjegyek + aláhúzás, Unicode-kal) VAGY egyetlen
# nem-whitespace, nem-szó karakter (írásjel, szimbólum). A `re.UNICODE` a
# Python 3-ban a `\w`-nél alapból aktív, így az ékezetes betűk is bekerülnek.
_TOKEN_MINTA = re.compile(r"\w+|[^\w\s]", re.UNICODE)

# D7: e fölött figyelmeztetünk (de NEM vágunk).
ALAPÉRTELMEZETT_FIGYELMEZTETÉSI_KÜSZÖB = 500


class Tokenizer:
    """Nyers szöveget tokenek listájára bont (Unicode-aware, szavas).

    Paraméterek:
        case_sensitive: ha ``True`` (default), a kis/nagybetű megkülönböztetve
            marad — kódhoz ajánlott (``for`` ≠ ``For``). Ha ``False``, minden
            token kisbetűsítve — szabad szöveghez ajánlott (``Nem`` = ``nem``).
        figyelmeztetési_küszöb: e token-szám fölött ``warnings.warn`` szól
            (D7: nincs kemény vágás).
    """

    __slots__ = ("case_sensitive", "figyelmeztetési_küszöb")

    def __init__(
        self,
        case_sensitive: bool = True,
        figyelmeztetési_küszöb: int = ALAPÉRTELMEZETT_FIGYELMEZTETÉSI_KÜSZÖB,
    ) -> None:
        self.case_sensitive = case_sensitive
        self.figyelmeztetési_küszöb = figyelmeztetési_küszöb

    def tokenizál(self, szöveg: str) -> list[str]:
        """Szövegből tokenek listája. Üres/None → üres lista."""
        if not szöveg:
            return []
        if not self.case_sensitive:
            szöveg = szöveg.lower()
        tokenek = _TOKEN_MINTA.findall(szöveg)
        if len(tokenek) > self.figyelmeztetési_küszöb:
            warnings.warn(
                f"A szöveg {len(tokenek)} tokenből áll, ez túllépi a "
                f"{self.figyelmeztetési_küszöb} token-es ajánlott határt. "
                f"A tudat ettől még feldolgozza (nincs vágás), de lassabb lehet.",
                stacklevel=2,
            )
        return tokenek

    def __repr__(self) -> str:  # pragma: no cover - kényelmi
        return f"Tokenizer(case_sensitive={self.case_sensitive})"


class Szótár:
    """Token → index leképezés, frekvencia-számlálással és OOV-kezeléssel.

    A `<padding>` (0) és `<ismeretlen>` (1) tokenek MINDIG jelen vannak, még
    üres szótárban is. A korpuszból tanult tokenek a 2. indextől kezdődnek.

    Determinisztikus index-kiosztás: csökkenő gyakoriság, holtversenyben
    ábécé szerint — így ugyanaz a korpusz mindig ugyanazt a szótárat adja
    (reprodukálható mentés/betöltés, M6.5).

    Paraméterek:
        min_gyakoriság: e gyakoriság alatti tokenek NEM kerülnek a szótárba
            (OOV-ként `<ismeretlen>`-re képződnek). Default 1 = minden token.
    """

    __slots__ = ("min_gyakoriság", "_token_index", "_index_token", "_gyakoriság")

    def __init__(self, min_gyakoriság: int = 1) -> None:
        if min_gyakoriság < 1:
            raise ValueError("min_gyakoriság legalább 1 legyen.")
        self.min_gyakoriság = min_gyakoriság
        self._token_index: dict[str, int] = {}
        self._index_token: list[str] = []
        self._gyakoriság: Counter[str] = Counter()
        self._reset()

    def _reset(self) -> None:
        """Csak a speciális tokenekkel inicializál."""
        self._token_index = {PADDING: PADDING_INDEX, ISMERETLEN: ISMERETLEN_INDEX}
        self._index_token = [PADDING, ISMERETLEN]
        self._gyakoriság = Counter()

    def illeszt(self, dokumentumok: Iterable[list[str]]) -> "Szótár":
        """Szótár felépítése tokenizált dokumentumok korpuszából.

        Minden hívás NULLÁRÓL építi a szótárat (nem akkumulál). A bemenet
        tokenizált dokumentumok iterálható halmaza (pl. tokenizer kimenetei).
        Láncolható: visszaadja önmagát.
        """
        self._reset()
        for tokenek in dokumentumok:
            self._gyakoriság.update(tokenek)

        # Determinisztikus sorrend: gyakoriság csökkenő, majd token ábécé.
        rendezett = sorted(
            self._gyakoriság.items(), key=lambda kv: (-kv[1], kv[0])
        )
        for token, gyak in rendezett:
            if gyak < self.min_gyakoriság:
                continue
            if token in self._token_index:
                continue  # elvileg nem fordulhat elő (speciális tokenek külön)
            self._token_index[token] = len(self._index_token)
            self._index_token.append(token)
        return self

    def index(self, token: str) -> int:
        """Token → index. Ismeretlen token → `<ismeretlen>` indexe."""
        return self._token_index.get(token, ISMERETLEN_INDEX)

    def token(self, index: int) -> str:
        """Index → token. Tartományon kívül → ValueError."""
        if not (0 <= index < len(self._index_token)):
            raise ValueError(
                f"Index a szótár tartományán kívül: {index} "
                f"(méret={len(self._index_token)})."
            )
        return self._index_token[index]

    def kódol(self, tokenek: list[str]) -> list[int]:
        """Tokenek listája → indexek listája (OOV → `<ismeretlen>`)."""
        return [self.index(t) for t in tokenek]

    def dekódol(self, indexek: list[int]) -> list[str]:
        """Indexek listája → tokenek listája."""
        return [self.token(i) for i in indexek]

    def gyakoriság(self, token: str) -> int:
        """Egy token előfordulási száma a tanító korpuszban (0 ha nem volt)."""
        return self._gyakoriság.get(token, 0)

    def tartalmaz(self, token: str) -> bool:
        """Igaz, ha a token a szótárban van (a speciálisakat is beleértve)."""
        return token in self._token_index

    @property
    def méret(self) -> int:
        """A szótár mérete (a 2 speciális tokennel együtt)."""
        return len(self._index_token)

    def __len__(self) -> int:
        return len(self._index_token)

    def __contains__(self, token: str) -> bool:
        return token in self._token_index

    def __repr__(self) -> str:  # pragma: no cover - kényelmi
        return f"Szótár(méret={self.méret}, min_gyakoriság={self.min_gyakoriság})"

"""Kód-diagnózis réteg — Phase 8 / M8.4.a.

Az AST-elemző MÉRT tényeiből (KódTények) KONKRÉT, barátságos magyar
megállapításokat készít: „A 3. sorból hiányzik a kettőspont a sor végéről."
Ez a réteg adja a KódTanár válaszának a *konkrét* részét (a hiedelem-keret a
Phase 7 palettából jön) — és GROUNDED: csak azt mondja, amit az AST tényleg talált.

A Python `ast` (angol) hibaüzeneteit gyakori kezdő-hibákra kurált magyar
megfogalmazásra fordítjuk, ismeretlen esetre barátságos fallback-kel.
"""

from __future__ import annotations

from dataclasses import dataclass

from elpp.tudat.szoveg.kodelemzo import KódTények, elemez


@dataclass(frozen=True)
class Megállapítás:
    """Egy konkrét, grounded diagnózis-megállapítás a kódról.

    Mezők:
        kategória: "szintaxis" | "minőség" | "rendben".
        súlyosság: "hiba" | "javaslat" | "dicséret".
        sor: az érintett sor (None, ha nem sor-specifikus).
        üzenet: barátságos magyar leírás.
        javaslat: opcionális konkrét tipp a javításra.
    """

    kategória: str
    súlyosság: str
    sor: int | None
    üzenet: str
    javaslat: str | None = None


# ── A Python szintaxis-hibák kurált magyar fordítása (D2) ────────────────────
# (minta-részlet az `ast` hibaüzenetében) → (barátságos magyar, javaslat)
_SZINTAXIS_TÉRKÉP: list[tuple[str, str, str | None]] = [
    ("expected ':'",
     "hiányzik a kettőspont a sor végéről",
     "tedd ki a `:`-t a `for`/`if`/`def`/`while` sor végére"),
    ("expected an indented block",
     "hiányzik a behúzott blokk (a kettőspont után behúzva kell folytatni)",
     "húzd be (4 szóközzel) a blokk törzsét"),
    ("unexpected indent",
     "váratlan behúzás van",
     "igazítsd a behúzást a környező sorokhoz"),
    ("was never closed",
     "egy zárójel nincs lezárva",
     "ellenőrizd a `(`, `[`, `{` párokat"),
    ("unterminated string",
     "egy szöveg-literál nincs lezárva",
     "tedd ki a hiányzó idézőjelet"),
    ("invalid syntax",
     "szintaktikai hiba van",
     "nézd át a sort elgépelés vagy hiányzó jel után"),
    ("cannot assign",
     "ide nem lehet értéket adni (talán `==` kellett `=` helyett?)",
     "összehasonlításhoz `==` kell, értékadáshoz `=`"),
]


def _fordítsd_szintaxis_hibát(üzenet: str | None) -> tuple[str, str | None]:
    """Egy `ast` hibaüzenet → (barátságos magyar, javaslat). Fallback: az eredeti."""
    nyers = (üzenet or "").lower()
    for minta, magyar, tipp in _SZINTAXIS_TÉRKÉP:
        if minta in nyers:
            return magyar, tipp
    return (f"szintaktikai hiba ({üzenet})" if üzenet else "szintaktikai hiba", None)


def diagnózis(kód: str) -> list[Megállapítás]:
    """A kód konkrét, grounded megállapításai.

    - Ha a kód NEM fut le (szintaktikai hiba): ezt jelenti (sorral + tipp). Ez
      blokkoló — ilyenkor csak ezt adjuk vissza (előbb fusson le egyáltalán).
    - Egyébként: minőségi megállapítások a MÉRT tényekből. Ha nincs gond,
      egy „rendben" dicséret.
    """
    t = elemez(kód)

    if t.szintaktikailag_hibás:
        magyar, tipp = _fordítsd_szintaxis_hibát(t.hiba_üzenet)
        hol = f"A {t.hiba_sor}. sorban " if t.hiba_sor else "A kódban "
        return [
            Megállapítás(
                kategória="szintaxis",
                súlyosság="hiba",
                sor=t.hiba_sor,
                üzenet=f"{hol}{magyar} — emiatt nem fut le.",
                javaslat=tipp,
            )
        ]

    return _minőségi_megállapítások(t)


def _minőségi_megállapítások(t: KódTények) -> list[Megállapítás]:
    """Grounded minőségi megállapítások a mért tényekből (üres kódra üres)."""
    ki: list[Megállapítás] = []
    if t.sorok == 0:
        return ki

    if t.egybetűs_nevek > 2:
        ki.append(Megállapítás(
            "minőség", "javaslat", None,
            f"Sok az egybetűs változónév ({t.egybetűs_nevek} db).",
            "adj beszédesebb neveket (pl. `osszeg`, `szamlalo`) az olvashatóságért",
        ))
    if t.max_ismételt_értékadás > 3:
        ki.append(Megállapítás(
            "minőség", "javaslat", None,
            f"Egy változó sokszor ({t.max_ismételt_értékadás}×) kap új értéket.",
            "talán egy ciklus tömörebbé tenné",
        ))
    if t.max_függvény_hossz > 30:
        ki.append(Megállapítás(
            "minőség", "javaslat", None,
            f"Van egy hosszú függvényed ({t.max_függvény_hossz} sor).",
            "érdemes lehet kisebb függvényekre bontani",
        ))
    if t.max_mélység > 4:
        ki.append(Megállapítás(
            "minőség", "javaslat", None,
            f"Mély a beágyazás ({t.max_mélység} szint).",
            "korai visszatéréssel (`return`) laposabbá tehető",
        ))

    if not ki:
        ki.append(Megállapítás(
            "rendben", "dicséret", None,
            "A kód szerkezete rendben van — szép, olvasható munka.",
            None,
        ))
    return ki


def szövegezd(megállapítás: Megállapítás) -> str:
    """Egy megállapítás ember-olvasható mondatként (a javaslattal együtt)."""
    if megállapítás.javaslat:
        return f"{megállapítás.üzenet} Javaslat: {megállapítás.javaslat}."
    return megállapítás.üzenet

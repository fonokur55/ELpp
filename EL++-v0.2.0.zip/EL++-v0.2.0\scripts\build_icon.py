"""EL++.png -> Windows-kompatibilis .ico (16, 32, 48, 256 px).

A telepito hivja. FONTOS: soha ne dobjon nyers traceback-et! A PowerShell
telepito ErrorActionPreference = Stop mellett fut, es egy nativ parancs
stderr-je ilyenkor megallitja az egesz telepitest. Ezert itt minden hibat
elkapunk, olvashato uzenetet irunk a STDOUT-ra (nem stderr-re), es 0 koddal
terunk vissza. Ha nincs .ico, a telepito egyszeruen kihagyja az ikont.
"""

from __future__ import annotations

import sys
from pathlib import Path


def build_ico(png_path: Path, ico_path: Path) -> None:
    from PIL import Image

    img = Image.open(png_path).convert("RGBA")
    # Csak a forrasnal nem nagyobb meretek kerulnek az .ico-ba (kulonben Pillow hibazhat).
    wanted = [(16, 16), (32, 32), (48, 48), (256, 256)]
    sizes = [s for s in wanted if s[0] <= img.width and s[1] <= img.height]
    if not sizes:
        sizes = [(img.width, img.height)]
    ico_path.parent.mkdir(parents=True, exist_ok=True)
    img.save(ico_path, format="ICO", sizes=sizes)


def main(argv: list[str]) -> int:
    if len(argv) < 2:
        print("Hasznalat: build_icon.py <forras.png> <cel.ico>")
        return 0
    src = Path(argv[0])
    dst = Path(argv[1])

    try:
        import PIL  # noqa: F401
    except ImportError:
        print("Pillow nincs telepitve - ikon kihagyva (nem hiba).")
        return 0

    try:
        build_ico(src, dst)
    except Exception as exc:  # a telepitest SOHA ne allitsa meg egy ikon miatt
        print(f"Ikon-generalas kihagyva: {exc}")
        return 0

    print("ico ok", dst)
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))

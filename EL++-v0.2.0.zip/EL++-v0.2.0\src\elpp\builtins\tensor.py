"""Tensor primitívek."""

from __future__ import annotations

import math
import random
from typing import Any

from elpp.runtime_values import ElTensor


def _as_tensor(x: Any) -> ElTensor:
    if isinstance(x, ElTensor):
        return x
    if isinstance(x, (list, tuple)):
        flat = [float(v) for v in x]
        return ElTensor(flat)
    if isinstance(x, (int, float)):
        return ElTensor([float(x)])
    raise TypeError(f"Tensor kell, kapott: {type(x).__name__}")


def randn(rows: int, cols: int) -> ElTensor:
    data = [random.gauss(0, 1) for _ in range(rows * cols)]
    return ElTensor(data, [rows, cols])


def matmul(a: ElTensor, b: ElTensor) -> ElTensor:
    ar, ac = (a.shape + [1, 1])[:2]
    br, bc = (b.shape + [1, 1])[:2]
    if ac != br:
        raise ValueError(f"matmul shape: {a.shape} x {b.shape}")
    out = []
    for i in range(ar):
        for j in range(bc):
            s = 0.0
            for k in range(ac):
                s += a.data[i * ac + k] * b.data[k * bc + j]
            out.append(s)
    return ElTensor(out, [ar, bc])


def relu(t: ElTensor) -> ElTensor:
    return ElTensor([max(0.0, x) for x in t.data], t.shape)


def mse(pred: ElTensor, target: ElTensor) -> float:
    n = min(len(pred.data), len(target.data))
    if n == 0:
        return 0.0
    return sum((pred.data[i] - target.data[i]) ** 2 for i in range(n)) / n


TENSOR_BUILTINS: dict[str, Any] = {
    "randn": lambda args: randn(int(args[0]), int(args[1])),
    "matmul": lambda args: matmul(_as_tensor(args[0]), _as_tensor(args[1])),
    "relu": lambda args: relu(_as_tensor(args[0])),
    "mse": lambda args: mse(_as_tensor(args[0]), _as_tensor(args[1])),
    "tensor": lambda args: ElTensor(
        [float(x) for x in args[0]] if len(args) == 1 else [float(args[0])],
        list(int(x) for x in args[1:]) if len(args) > 1 else None,
    ),
}

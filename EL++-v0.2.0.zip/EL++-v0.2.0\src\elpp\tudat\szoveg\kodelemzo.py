"""Kód-szerkezet elemző — Phase 8 / M8.1.a.

A tudat eddig a kód FELSZÍNÉT tippelte (Phase 6: szöveg-beágyazás, ami a
kódminőségen 0.70-en megállt). Innentől a VALÓDI SZERKEZETET olvassa: a Python
`ast` és `tokenize` modulokkal MÉRHETŐ, IGAZ tényeket nyer ki a beküldött kódból.
Ezekre a tényekre a hiedelmek `ast_*` builtineken át hivatkoznak (M8.1.b).

**Graceful a törött kódra (D2):** a kezdő/frusztrált diák kódja gyakran hibás
(hiányzó kettőspont, zárójel). Ez NEM hiba, hanem JEL: ha az `ast.parse` elbukik,
elmentjük a `SyntaxError`-t (sor + üzenet) evidenciaként, és token-szintre esünk
vissza a többi tényhez. Így mindig kapunk használható eredményt.

A modul nyelv-specifikus (Python, D1), de a `KódTények` felület nyelv-agnosztikus
— később más elemző-háttér is mögé tehető.
"""

from __future__ import annotations

import ast
import io
import tokenize
from collections import Counter
from dataclasses import dataclass, field
from functools import lru_cache

# A beágyazás-mélységet növelő (blokk-nyitó) Python-csomópontok.
_BLOKK_TÍPUSOK: tuple[type, ...] = (
    ast.FunctionDef,
    ast.AsyncFunctionDef,
    ast.ClassDef,
    ast.For,
    ast.AsyncFor,
    ast.While,
    ast.If,
    ast.With,
    ast.AsyncWith,
    ast.Try,
)
_CIKLUS_TÍPUSOK: tuple[type, ...] = (ast.For, ast.AsyncFor, ast.While)


@dataclass(frozen=True)
class KódTények:
    """Egy kódrészlet MÉRT, igaz szerkezeti tényei (grounded evidencia).

    Minden mező a tényleges kódból származik — nincs tippelés. Törött kódnál a
    `szintaktikailag_hibás` igaz, a strukturális mezők a token-szintű
    becslésre vagy 0-ra esnek vissza.
    """

    szintaktikailag_hibás: bool = False
    hiba_sor: int | None = None
    hiba_üzenet: str | None = None

    sorok: int = 0
    token_szám: int = 0

    függvények_száma: int = 0
    max_függvény_hossz: int = 0      # sorokban
    max_mélység: int = 0             # beágyazás-mélység
    ciklusok_száma: int = 0
    elágazások_száma: int = 0

    egybetűs_nevek: int = 0          # különböző, 1 hosszú változónevek száma
    rövid_nevek: int = 0             # különböző, <=2 hosszú változónevek száma
    max_ismételt_értékadás: int = 0  # ugyanannak a névnek hányszor adunk értéket
    változónevek: tuple[str, ...] = field(default_factory=tuple)


# ─────────────────────────────────────────────────────────────────────────────
# Fő belépési pont
# ─────────────────────────────────────────────────────────────────────────────


@lru_cache(maxsize=256)
def elemez(kód: str) -> KódTények:
    """Egy kódrészlet szerkezeti tényei. Cache-elt (ugyanaz a kód → ugyanaz).

    Üres/whitespace kód → üres, hibátlan tények. Törött kód → graceful.
    """
    if kód is None:
        kód = ""
    sorok = _nem_üres_sorok(kód)
    token_szám = _token_szám(kód)

    try:
        fa = ast.parse(kód)
    except SyntaxError as e:
        return KódTények(
            szintaktikailag_hibás=True,
            hiba_sor=e.lineno,
            hiba_üzenet=(e.msg or "szintaktikai hiba"),
            sorok=sorok,
            token_szám=token_szám,
        )

    return _elemezd_fa(fa, sorok=sorok, token_szám=token_szám)


# ─────────────────────────────────────────────────────────────────────────────
# AST-alapú tény-kinyerés
# ─────────────────────────────────────────────────────────────────────────────


def _elemezd_fa(fa: ast.AST, *, sorok: int, token_szám: int) -> KódTények:
    függvény_hosszak: list[int] = []
    ciklusok = 0
    elágazások = 0
    assign_számláló: Counter[str] = Counter()
    nevek: list[str] = []

    for node in ast.walk(fa):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            függvény_hosszak.append(_csomópont_hossz(node))
            for a in _argumentum_nevek(node.args):
                nevek.append(a)
        elif isinstance(node, _CIKLUS_TÍPUSOK):
            ciklusok += 1
        elif isinstance(node, ast.If):
            elágazások += 1
        elif isinstance(node, ast.Assign):
            for cél in node.targets:
                for nm in _cél_nevek(cél):
                    assign_számláló[nm] += 1
                    nevek.append(nm)
        elif isinstance(node, ast.Name) and isinstance(node.ctx, ast.Store):
            nevek.append(node.id)

    egyedi = {n for n in nevek if n != "_"}
    return KódTények(
        szintaktikailag_hibás=False,
        sorok=sorok,
        token_szám=token_szám,
        függvények_száma=len(függvény_hosszak),
        max_függvény_hossz=max(függvény_hosszak, default=0),
        max_mélység=_max_mélység(fa, 0),
        ciklusok_száma=ciklusok,
        elágazások_száma=elágazások,
        egybetűs_nevek=len({n for n in egyedi if len(n) == 1}),
        rövid_nevek=len({n for n in egyedi if len(n) <= 2}),
        max_ismételt_értékadás=max(assign_számláló.values(), default=0),
        változónevek=tuple(sorted(egyedi)),
    )


def _csomópont_hossz(node: ast.AST) -> int:
    """Egy csomópont sorhossza (end_lineno − lineno + 1). Py3.8+."""
    kezdet = getattr(node, "lineno", None)
    vég = getattr(node, "end_lineno", None)
    if kezdet is None or vég is None:
        return 0
    return vég - kezdet + 1


def _max_mélység(node: ast.AST, mélység: int) -> int:
    """A legmélyebb beágyazás (blokk-nyitó csomópontok mentén)."""
    maxd = mélység
    for gyerek in ast.iter_child_nodes(node):
        if isinstance(gyerek, _BLOKK_TÍPUSOK):
            maxd = max(maxd, _max_mélység(gyerek, mélység + 1))
        else:
            maxd = max(maxd, _max_mélység(gyerek, mélység))
    return maxd


def _cél_nevek(cél: ast.AST) -> list[str]:
    """Egy értékadás-cél nevei (egyszerű név, vagy tuple/list kicsomagolás)."""
    if isinstance(cél, ast.Name):
        return [cél.id]
    if isinstance(cél, (ast.Tuple, ast.List)):
        ki: list[str] = []
        for elem in cél.elts:
            ki.extend(_cél_nevek(elem))
        return ki
    return []


def _argumentum_nevek(args: ast.arguments) -> list[str]:
    nevek: list[str] = []
    for csoport in (args.posonlyargs, args.args, args.kwonlyargs):
        for a in csoport:
            nevek.append(a.arg)
    if args.vararg:
        nevek.append(args.vararg.arg)
    if args.kwarg:
        nevek.append(args.kwarg.arg)
    return nevek


# ─────────────────────────────────────────────────────────────────────────────
# Token-szintű segédek (törött kódra is működnek)
# ─────────────────────────────────────────────────────────────────────────────


def _nem_üres_sorok(kód: str) -> int:
    return sum(1 for s in kód.splitlines() if s.strip())


def _token_szám(kód: str) -> int:
    """Python-tokenek száma; ha a tokenizáló is elbukik, durva szó-szám."""
    if not kód.strip():
        return 0
    try:
        toks = list(tokenize.generate_tokens(io.StringIO(kód).readline))
        return sum(
            1
            for t in toks
            if t.type
            not in (
                tokenize.NEWLINE,
                tokenize.NL,
                tokenize.INDENT,
                tokenize.DEDENT,
                tokenize.ENDMARKER,
                tokenize.ENCODING,
            )
        )
    except (tokenize.TokenError, IndentationError, SyntaxError):
        return len(kód.split())

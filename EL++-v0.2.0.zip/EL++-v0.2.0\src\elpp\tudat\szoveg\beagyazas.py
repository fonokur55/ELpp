"""Beágyazás + szöveg-kódoló — Phase 6 / M6.2.

A tokenek (illetve a szótár-indexeik) innentől VEKTOROKKÁ válnak, amiket
átlag-poolinggal egyetlen fix méretű vektorrá vonunk össze, majd egy lineáris
réteg (`W·v + b`) skalárrá alakít. Ez a skalár lesz a `tényező szöveg` nyers
kimenete (M6.3).

**Finomítás #2 — ANALITIKUS gradient (NEM numerikus!):**
    A beágyazás-mátrix nagy (pl. vocab=1000, dim=64 → 64 000 súly). Numerikus
    gradienssel ez ~128 000 forward/lépés = használhatatlan. A lánc szerkezete
    viszont ismert, így a backward zárt képlettel, O(L·dim) költséggel pontos:

        v[k]   = (1/L) · Σ_i E[idx_i][k]        (átlag-pooling)
        z      = Σ_k W[k]·v[k] + b              (lineáris)
        kimenet = aktiváció(z)                   (lineáris vagy sigmoid)

        d(kim)/dz       = 1            (lineáris)  |  out·(1−out)  (sigmoid)
        d(kim)/db       = d(kim)/dz
        d(kim)/dW[k]    = d(kim)/dz · v[k]
        d(kim)/dE[i][k] = d(kim)/dz · W[k] · (1/L)   (csak a bemeneti tokenekre!)

    HATÁRVONAL: ismert szerkezet (szöveg) → analitikus. Tetszőleges felhasználói
    képlet (`tényező neurális`) → marad numerikus. A kettő békésen megfér.
"""

from __future__ import annotations

import math
import random
from typing import Iterable

ALAPÉRTELMEZETT_DIM = 64
INIT_SZÓRÁS = 0.1


def _sigmoid(x: float) -> float:
    """Numerikusan stabil sigmoid (azonos a factors._sigmoid_op-pal)."""
    if x >= 500:
        return 1.0
    if x <= -500:
        return 0.0
    return 1.0 / (1.0 + math.exp(-x))


class SzövegKódoló:
    """Token-index szekvenciát skalárrá kódol, analitikus gradienssel.

    Tanulható paraméterek:
        E: beágyazás-mátrix, `[vocab_méret][dim]` (a `<padding>` sora 0).
        W: projekciós vektor, `[dim]`.
        b: skaláris bias.

    Paraméterek:
        vocab_méret: a szótár mérete (a 2 speciális tokennel együtt).
        dim: a beágyazás dimenziója (D2: default 64).
        aktiváció: ``"lineáris"`` (default, nyers z) vagy ``"sigmoid"``
            (a [0,1] tartományba képez — a `tényező szöveg` ezt használja majd).
        seed: reprodukálható random inicializáláshoz.
    """

    __slots__ = ("vocab_méret", "dim", "aktiváció", "E", "W", "b")

    def __init__(
        self,
        vocab_méret: int,
        dim: int = ALAPÉRTELMEZETT_DIM,
        aktiváció: str = "lineáris",
        seed: int | None = None,
    ) -> None:
        if vocab_méret < 1:
            raise ValueError("vocab_méret legalább 1 legyen.")
        if dim < 1:
            raise ValueError("dim legalább 1 legyen.")
        if aktiváció not in ("lineáris", "sigmoid"):
            raise ValueError(
                f"Ismeretlen aktiváció: `{aktiváció}`. "
                f"Választható: 'lineáris' vagy 'sigmoid'."
            )
        self.vocab_méret = vocab_méret
        self.dim = dim
        self.aktiváció = aktiváció

        rng = random.Random(seed)
        # E: minden sor egy token-vektor. A 0. sor (<padding>) maradjon 0.
        self.E: list[list[float]] = [
            [0.0] * dim
            if i == 0
            else [rng.gauss(0.0, INIT_SZÓRÁS) for _ in range(dim)]
            for i in range(vocab_méret)
        ]
        self.W: list[float] = [rng.gauss(0.0, INIT_SZÓRÁS) for _ in range(dim)]
        self.b: float = 0.0

    # ── Forward ──────────────────────────────────────────────────────────────

    def pool(self, indexek: list[int]) -> list[float]:
        """Token-indexek → átlag-poololt vektor `[dim]` (üres → 0-vektor)."""
        v = [0.0] * self.dim
        if not indexek:
            return v
        for idx in indexek:
            sor = self.E[idx]
            for k in range(self.dim):
                v[k] += sor[k]
        L = len(indexek)
        return [x / L for x in v]

    def _z(self, v: list[float]) -> float:
        """Lineáris réteg: z = W·v + b."""
        return sum(self.W[k] * v[k] for k in range(self.dim)) + self.b

    def forward(self, indexek: list[int]) -> float:
        """Token-indexek → skalár kimenet (aktiváció szerint)."""
        z = self._z(self.pool(indexek))
        return _sigmoid(z) if self.aktiváció == "sigmoid" else z

    # ── Backward (analitikus) ─────────────────────────────────────────────────

    def gradiens(
        self, indexek: list[int], grad_kimenet: float
    ) -> tuple[dict[int, list[float]], list[float], float]:
        """Analitikus gradiens a kimenetre adott `grad_kimenet` mellett.

        Visszatérés: ``(grad_E, grad_W, grad_b)`` ahol
            grad_E: ``{token_index: [dim] gradiens}`` — CSAK a bemeneti tokenekre,
                    ismétlődő tokenek gradiense összeadódik (sparse).
            grad_W: ``[dim]`` gradiens.
            grad_b: skalár.

        Tiszta függvény: nem módosít állapotot.
        """
        v = self.pool(indexek)
        z = self._z(v)
        if self.aktiváció == "sigmoid":
            out = _sigmoid(z)
            dout_dz = out * (1.0 - out)
        else:
            dout_dz = 1.0
        g = grad_kimenet * dout_dz  # = dL/dz

        grad_b = g
        grad_W = [g * v[k] for k in range(self.dim)]

        grad_E: dict[int, list[float]] = {}
        L = len(indexek)
        if L > 0:
            inv_L = 1.0 / L
            for idx in indexek:
                # dz/dE[idx][k] = W[k]; dv/dE = 1/L; ismétlődés → összeadás.
                sor = grad_E.get(idx)
                if sor is None:
                    sor = [0.0] * self.dim
                    grad_E[idx] = sor
                for k in range(self.dim):
                    sor[k] += g * self.W[k] * inv_L
        return grad_E, grad_W, grad_b

    def tanulj_lépés(
        self, indexek: list[int], hiba: float, tanulási_ráta: float
    ) -> None:
        """Egy SGD-lépés: a paramétereket a `hiba` ellen igazítja.

        `hiba` = (jósolt − cél) konvenció (mint a runtime tanulásnál): a
        gradienst ennek irányában vonjuk le, így a kimenet a cél felé mozog.
        """
        grad_E, grad_W, grad_b = self.gradiens(indexek, hiba)
        self.b -= tanulási_ráta * grad_b
        for k in range(self.dim):
            self.W[k] -= tanulási_ráta * grad_W[k]
        for idx, sor in grad_E.items():
            cél_sor = self.E[idx]
            for k in range(self.dim):
                cél_sor[k] -= tanulási_ráta * sor[k]

    def __repr__(self) -> str:  # pragma: no cover - kényelmi
        return (
            f"SzövegKódoló(vocab={self.vocab_méret}, dim={self.dim}, "
            f"aktiváció={self.aktiváció!r})"
        )

"""Bytecode formátum és opcode-ok."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Any


class Op(Enum):
    CONST = auto()
    LOAD = auto()
    STORE = auto()
    ADD = auto()
    SUB = auto()
    MUL = auto()
    DIV = auto()
    EQ = auto()
    NE = auto()
    LT = auto()
    GT = auto()
    LE = auto()
    GE = auto()
    AND = auto()
    OR = auto()
    NOT = auto()
    NEG = auto()
    PRINT = auto()
    POP = auto()
    JMP = auto()
    JMP_IF_FALSE = auto()
    CALL = auto()
    RETURN = auto()
    TENSOR_NEW = auto()
    MATMUL = auto()
    RELU = auto()
    HALT = auto()


@dataclass
class Instruction:
    op: Op
    arg: Any = None


@dataclass
class Chunk:
    code: list[Instruction] = field(default_factory=list)
    constants: list[Any] = field(default_factory=list)

    def emit(self, op: Op, arg: Any = None) -> int:
        self.code.append(Instruction(op, arg))
        return len(self.code) - 1

    def add_constant(self, value: Any) -> int:
        self.constants.append(value)
        return len(self.constants) - 1

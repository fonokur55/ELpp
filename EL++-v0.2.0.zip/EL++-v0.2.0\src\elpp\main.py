"""CLI és REPL belépési pont."""

from __future__ import annotations

import io
import sys
from pathlib import Path

from elpp import __version__, ui
from elpp.dialect import detect_dialect
from elpp.errors import ELPPError
from elpp.interpreter import Interpreter
from elpp.parser import parse
from elpp.updater import check_update, print_update_help, run_update
from elpp.vm import VM

REPL_EXIT = frozenset({"kilép", "kilep", "exit", "quit", "vége", "vege"})
EL_EXTENSIONS = {".elpp", ".el", ".elc"}

# REPL meta-parancsok (kettősponttal, hogy ne ütközzenek a nyelvvel).
_META_HELP = frozenset({":súgó", ":sugo", ":help", ":h", ":?"})
_META_EXAMPLES = frozenset({":példák", ":peldak", ":examples", ":ex"})
_META_CLEAR = frozenset({":töröl", ":torol", ":clear", ":cls"})
_META_VERSION = frozenset({":verzió", ":verzio", ":version", ":v"})
_META_EXIT = frozenset({":kilép", ":kilep", ":exit", ":quit", ":q"})

# Beépített példák a :példák parancshoz (hiteles, futtatható szintaxis).
_REPL_EXAMPLES: list[tuple[str, str]] = [
    (
        "Magyar",
        'legyen x egyen 10\nha x nagyobb mint 5 akkor\n'
        '    írd ki "nagy"\nkülönben\n    írd ki "kicsi"\nkész',
    ),
    (
        "Angol",
        'set x to 10\nif x is greater than 5 then\n'
        '    print "big"\nelse\n    print "small"\nend',
    ),
]


def _is_el_file(path: Path) -> bool:
    return path.suffix.lower() in EL_EXTENSIONS


def _vm_compatible(program) -> bool:
    """VM csak egyszerű programokhoz (Let, Print, If, While)."""
    from elpp import ast

    for stmt in program.statements:
        if not isinstance(stmt, (ast.Let, ast.Print, ast.If, ast.While)):
            return False
        if isinstance(stmt, ast.If):

            def check_body(body):
                for s in body:
                    if not isinstance(s, (ast.Let, ast.Print, ast.If, ast.While)):
                        return False
                return True

            if not check_body(stmt.then_body):
                return False
            if stmt.else_body and not check_body(stmt.else_body):
                return False
    return True


def _run_file(
    path: Path,
    *,
    use_vm: bool = False,
    use_interpret: bool = False,
    dialect: str | None = None,
) -> int:
    source = path.read_text(encoding="utf-8")
    d = dialect or detect_dialect(source, path)
    try:
        program = parse(source, dialect=d)  # type: ignore[arg-type]
        if use_vm and not use_interpret and _vm_compatible(program):
            VM().run_source(source, dialect=d)  # type: ignore[arg-type]
        else:
            Interpreter().run(program)
    except ELPPError as e:
        print(str(e), file=sys.stderr)
        return 1
    return 0


def _repl_show_meta_help() -> None:
    """A :súgó kimenete a sárga keret-lécen belül."""
    lines = [
        ui.paint("Meta-parancsok:", ui.BOLD),
        f"  {ui.paint(':súgó', ui.CYAN)}     ez a súgó",
        f"  {ui.paint(':példák', ui.CYAN)}   beépített példák",
        f"  {ui.paint(':töröl', ui.CYAN)}    képernyő törlése",
        f"  {ui.paint(':verzió', ui.CYAN)}   verzió",
        f"  {ui.paint(':kilép', ui.CYAN)}    kilépés",
        "",
        ui.paint("Nyelv gyorstalpaló:", ui.BOLD),
        "  legyen x egyen 5              változó",
        "  írd ki x                      kiírás",
        "  ha x nagyobb mint 3 akkor     feltétel (zárás: kész)",
    ]
    for line in lines:
        print(ui.rail_line(line))


def _repl_show_examples() -> None:
    """A :példák kimenete: hiteles, futtatható kódrészletek."""
    for title, code in _REPL_EXAMPLES:
        print(ui.rail_line(ui.paint(f"# {title}", ui.CYAN + ui.BOLD)))
        for line in code.split("\n"):
            print(ui.rail_line(line))
        print(ui.rail_line(""))


def _repl_eval(
    interp: Interpreter, capture: io.StringIO, source: str, dialect: str
) -> None:
    """Egy kész kódrészlet futtatása; a kimenet a sárga keretbe kerül."""
    capture.seek(0)
    capture.truncate(0)
    err: str | None = None
    try:
        program = parse(source, dialect=dialect)  # type: ignore[arg-type]
        interp.run(program)
    except ELPPError as e:
        err = str(e)
    for line in capture.getvalue().splitlines():
        print(ui.rail_line(line))
    if err is not None:
        for line in err.splitlines():
            print(ui.rail_line(ui.paint(line, ui.RED)))


def _repl(dialect: str = "easy") -> int:
    ui.init()
    print(ui.banner(__version__, dialect))
    capture = io.StringIO()
    interp = Interpreter(stdout=capture, dialect=dialect)  # type: ignore[arg-type]
    buffer: list[str] = []
    block_depth = 0

    while True:
        try:
            base = "EL++> " if block_depth == 0 else "  ..> "
            line = input(ui.rail_prompt(base))
        except (EOFError, KeyboardInterrupt):
            print()
            break

        stripped = line.strip()

        # Meta-parancsok és kilépés: csak sor elején, nyitott blokk nélkül.
        if not buffer:
            low = stripped.casefold()
            if low in _META_EXIT or low in {w.casefold() for w in REPL_EXIT}:
                break
            if low in _META_HELP:
                _repl_show_meta_help()
                continue
            if low in _META_EXAMPLES:
                _repl_show_examples()
                continue
            if low in _META_CLEAR:
                ui.clear_screen()
                print(ui.banner(__version__, dialect))
                continue
            if low in _META_VERSION:
                print(ui.rail_line(f"EL++ {__version__}"))
                continue

        if not stripped and not buffer:
            continue

        buffer.append(line)

        lower = stripped.casefold()
        if any(
            lower.startswith(s)
            for s in (
                "ha ", "if ", "amíg", "amig", "while ", "ismételd", "ismeteld",
                "repeat ", "függvény", "fuggveny", "function ", "def ", "fn ",
                "for ", "minden",
            )
        ) or lower.endswith(" akkor") or lower.endswith(" then"):
            block_depth += 1
        if any(lower == s for s in ("kész", "kesz", "end", "vége", "vege", "done")):
            block_depth = max(0, block_depth - 1)

        if block_depth == 0 and buffer:
            source = "\n".join(buffer)
            buffer = []
            _repl_eval(interp, capture, source, dialect)

    print(ui.rail_close())
    return 0


def _print_stats(interp: Interpreter) -> None:
    print(f"Graf/költség összesen: {interp.stats_cost + interp.graph.total_cost:.2f}")


def _print_help() -> None:
    print(
        f"""EL++ (Easy Language) v{__version__}

Használat:
  el++                         REPL (sárga keretes, ASCII bannerrel)
  el++ új fájl.elpp            új program létrehozása sablonból
  el++ fájl.elpp               program futtatása (teljes interpreter)
  el++ --vm fájl.elpp          bytecode VM (egyszerű programok)
  el++ --interpret fájl.elpp   tree-walk interpreter (debug)
  el++ --core fájl.elc         Core dialect
  el++ stats fájl.elpp         költség statisztika futtatás után
  el++ check-update            frissítés ellenőrzés
  el++ update [--yes]          frissítés

Kiterjesztések: .elpp (Easy), .elc (Core), .el
"""
    )


_NEW_TEMPLATE = """# EL++ program - jó szórakozást!
legyen név egyen "világ"
írd ki "Szia"
írd ki név

legyen x egyen 10
ha x nagyobb mint 5 akkor
    írd ki "nagy szám"
különben
    írd ki "kicsi szám"
kész
"""


def _cmd_new(path_arg: str) -> int:
    """Új EL++ program létrehozása sablonból (kezdőknek gyors indulás)."""
    path = Path(path_arg)
    if path.suffix == "":
        path = path.with_suffix(".elpp")
    if path.exists():
        print(f"Már létezik, nem írom felül: {path}", file=sys.stderr)
        return 1
    try:
        if path.parent and not path.parent.exists():
            path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(_NEW_TEMPLATE, encoding="utf-8")
    except OSError as e:
        print(f"Nem sikerült létrehozni: {e}", file=sys.stderr)
        return 1
    print(f"Létrehozva: {path}")
    print(f"Futtatás:   el++ {path}")
    return 0


def main(argv: list[str] | None = None) -> int:
    args = list(argv if argv is not None else sys.argv[1:])

    if not args:
        return _repl()

    use_vm = False
    use_interpret = False
    dialect: str | None = None

    while args and args[0].startswith("-"):
        flag = args.pop(0)
        if flag in ("-h", "--help"):
            _print_help()
            return 0
        if flag in ("--version", "-V"):
            print(f"EL++ {__version__}")
            return 0
        if flag == "--vm":
            use_vm = True
        elif flag == "--interpret":
            use_interpret = True
        elif flag == "--core":
            dialect = "core"
        elif flag == "--easy":
            dialect = "easy"
        else:
            print(f"Ismeretlen kapcsoló: {flag}", file=sys.stderr)
            return 1

    if not args:
        return _repl(dialect or "easy")

    if args[0] in ("check-update", "check-updates", "frissites-ellenorzes"):
        return check_update()

    if args[0] == "update":
        auto = "--yes" in args or "-y" in args
        if "--help" in args or "-h" in args:
            return print_update_help()
        return run_update(auto=auto)

    if args[0] in ("új", "uj", "new"):
        if len(args) < 2:
            print("Használat: el++ új fájl.elpp", file=sys.stderr)
            return 1
        return _cmd_new(args[1])

    if args[0] == "stats":
        if len(args) < 2:
            print("Hiányzik a fájl: el++ stats példa.elpp", file=sys.stderr)
            return 1
        path = Path(args[1])
        source = path.read_text(encoding="utf-8")
        d = dialect or detect_dialect(source, path)
        interp = Interpreter()
        try:
            interp.run(parse(source, dialect=d))  # type: ignore[arg-type]
            _print_stats(interp)
        except ELPPError as e:
            print(str(e), file=sys.stderr)
            return 1
        return 0

    if args[0] == "run":
        if len(args) < 2:
            print("Hiányzik a fájl.", file=sys.stderr)
            return 1
        return _run_file(
            Path(args[1]),
            use_vm=use_vm,
            use_interpret=use_interpret,
            dialect=dialect,
        )

    path = Path(args[0])
    if path.exists() or _is_el_file(path):
        return _run_file(
            path,
            use_vm=use_vm,
            use_interpret=use_interpret,
            dialect=dialect,
        )

    print(f"Ismeretlen parancs vagy fájl: {args[0]}", file=sys.stderr)
    _print_help()
    return 1


if __name__ == "__main__":
    sys.exit(main())

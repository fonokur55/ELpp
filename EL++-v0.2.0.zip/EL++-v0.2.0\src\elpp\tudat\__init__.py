"""Tudat alrendszer — neuro-szimbolikus AI-paradigma EL++-ban.

A `tudat` az EL++ központi AI-fogalma: önreflexióra képes, hiedelmekkel és
tanulható súlyokkal rendelkező, célokkal motivált entitás, ami eseményekre
reagálva inkrementálisan frissül.

Phase 1 — M1 (csontváz):
    Csak deklaráció-szintű támogatás: TudatDecl, AreaDecl,
    BeliefDecl, WeightDecl, GoalDecl + parser hook.

Phase 1 — M2 (tényezők):
    4 tényező-típus (NeuralFactor, RuleFactor, BeliefFactor, GoalFactor),
    registry-architektúrával egyetlen helyen.
    TudatRuntime: compute_belief / list_factors API.
    Bayes-szerű aggregálás.

Phase 1 — M3 (élet):
    PerceptionBlock — `észlelés (params): ... kész`.
    TudatRuntime.észlel(**inputs) — reaktív frissítés statikus függőség-
    analízis alapján; activate_area / deactivate_area — szelektív aktiváció.

Phase 1 — M4 (önreflexió):
    ReflectionBlock + ExplainStmt — `reflexió "<címke>": magyarázd ...`.
    TudatRuntime.magyarázd / reflektál / list_reflections.
    Explanation osztály — ember-olvasható kimenettel.

Phase 1 — M5 (tanulás):
    TrainingBlock + LearnStmt — `tanulás[(params)]: tanulj X -> expr ...`.
    TudatRuntime.tanulj(**targets) — hibafelelősség-eloszlás:
      • neurális súlyok: numerikus gradient SGD-vel
      • szabály-súlyok (rule_weight): tanult skalár szorzó (default 1.0)
      • cél-súlyok (goal_weight): tanult skalár (M2 placeholder helyett)
    Per-tényező tanult paraméterek a runtime-ban.

Phase 2 — M2.1 (hipotetikus):
    WhatIfBlock + WhatIfOverride — `mi_lenne_ha "címke" (W = 0.8, ...): ...`.
    TudatRuntime.mi_lenne_ha overloaded: nevesített és ad-hoc.
    PURE: snapshot → apply → recompute → action → restore.
    Hiedelem-override BYPASS a tényezőkön (`_belief_overrides`).

Phase 2 — M2.2 (meta-bizonytalanság):
    BeliefState.meta_uncertainty (epistemikus) + Explanation bővítés
    + TudatRuntime.meta_bizonytalanság(name). α konfigurálható.

Phase 2 — M2.3 (ellentmondás):
    Conflict dataclass. TudatRuntime.feszültség(name) +
    TudatRuntime.ellentmondások(name, küszöb). Explanation auto-figyelmeztetés.
    PASSZÍV: nem módosítja az aggregálást.

Lásd: memory/project_phase1_*.md a teljes tervhez.
"""

from elpp.tudat.ast import (
    AreaDecl,
    BeliefDecl,
    BeliefFactor,
    ExplainStmt,
    Factor,
    GoalDecl,
    GoalFactor,
    KifejezésBejegyzés,
    KifejezésBlokk,
    LearnStmt,
    NeuralFactor,
    PerceptionBlock,
    ReflectionBlock,
    RuleFactor,
    SzövegFactor,
    TrainingBlock,
    TudatDecl,
    TudatItem,
    WeightDecl,
    WhatIfBlock,
    WhatIfOverride,
)
# A factors modul betöltésekor regisztrálódnak az alaptípusok.
from elpp.tudat.factors import (
    FactorTypeRegistration,
    aggregate,
    all_factor_types,
    describe_factor,
    evaluate_factor,
    register_factor_type,
)
from elpp.tudat.kinds import Kind, kind_name
from elpp.tudat.runtime import (
    BeliefState,
    Conflict,
    Esemény,
    Explanation,
    FactorTrace,
    TudatRuntime,
    splitt,
)

__all__ = [
    # AST
    "AreaDecl",
    "BeliefDecl",
    "BeliefFactor",
    "ExplainStmt",
    "Factor",
    "GoalDecl",
    "GoalFactor",
    "KifejezésBejegyzés",
    "KifejezésBlokk",
    "LearnStmt",
    "NeuralFactor",
    "PerceptionBlock",
    "ReflectionBlock",
    "RuleFactor",
    "SzövegFactor",
    "TrainingBlock",
    "TudatDecl",
    "TudatItem",
    "WeightDecl",
    "WhatIfBlock",
    "WhatIfOverride",
    # Tényező-rendszer
    "FactorTypeRegistration",
    "aggregate",
    "all_factor_types",
    "describe_factor",
    "evaluate_factor",
    "register_factor_type",
    # Runtime
    "BeliefState",
    "Conflict",
    "Esemény",
    "Explanation",
    "FactorTrace",
    "TudatRuntime",
    "splitt",
    # Kindek
    "Kind",
    "kind_name",
]

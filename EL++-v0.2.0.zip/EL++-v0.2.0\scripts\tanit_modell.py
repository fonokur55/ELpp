#!/usr/bin/env python3
"""~133M GPT-2 stílusú transzformer tanítása a magyar korpuszon — 2. KÖR (Black-Sheep).

(133M = a degeneráció-mentes recept a ~36,5 Mrd token magyar korpuszra: ~276 token/param,
GPT-2 small szint, FOLYÉKONY zóna. A ~500M konfig a kód-fázisra van előkészítve — több adattal.)

EZ A SCRIPT A BÉRELT GPU-N FUT (torch + CUDA kell hozzá). Lokálisan nincs torch,
ezért NEM itt teszteljük — előbb INGYENES GPU-n (Colab/Kaggle) dry-run-nal
validáljuk (kis konfig, pár lépés), és csak utána a fizetős éles tanítás.

Bemenet: a `korpusz_tokenizalo.py` által készített shardok:
    moodel_corpus/tokenized/train.bin   (uint16 token-folyam)
    moodel_corpus/tokenized/val.bin
és a tokenizáló: moodel_corpus/tokenizalo.json (vocab=32000).

Architektúra: HF GPT2LMHeadModel egy ~250M-es konfiggal (bejáratott, nem hand-roll).
Az EL++ később ezt BURKOLJA (TorchGenerátor a `Generátor` szerződés ellen) —
ez a script csak az ALAP nyelvi modellt tanítja be.

Telepítés a bérelt gépen:  pip install torch transformers numpy
Dry-run (ingyenes GPU):     python tanit_modell.py --dryrun
Éles tanítás:               python tanit_modell.py
"""

from __future__ import annotations

import argparse
import math
import time
from pathlib import Path

import numpy as np

# ── Konfiguráció ─────────────────────────────────────────────────────────────
ADAT_DIR = Path("moodel_corpus/tokenized")
KIMENET_DIR = Path("moodel_corpus/modell_133m")
VOCAB_MÉRET = 32_000
BLOCK_SIZE = 2048            # kontextus-hossz (~1200 szó / ~1 oldal ablak)

# ~133M konfig (n_embd=768, n_layer=15, n_head=12 → ~132M paraméter). 2. KÖR — Black-Sheep beszélgetős.
# 36,5 Mrd token / 133M ≈ 274 token/param → FOLYÉKONY zóna (degeneráció-mentes recept; GPT-2 small szint).
N_EMBD, N_LAYER, N_HEAD = 768, 15, 12
# Kód-fázishoz (több adat) a ~500M konfig: N_EMBD, N_LAYER, N_HEAD = 1280, 24, 20

# Tanítás (80GB GPU-ra: A100/H100). A 133M kicsi, de a 2048 ctx miatt a batch korlátos.
BATCH_SIZE = 8            # per lépés (80GB-ra BIZTONSÁGOS: a 2048 ctx + eager attention miatt a batch korlátos; ~28-38GB aktiváció).
GRAD_ACCUM = 64           # effektív batch = 512 szekv. × 2048 token ≈ 1.05M token/lépés. A 512-es SZORZAT a kulcs az 1 epoch-hoz.
# Ha a GPU-n VAN bőven szabad VRAM (nvidia-smi mutatja): batch↑ + grad_accum↓ úgy, hogy BATCH×GRAD_ACCUM=512 maradjon → gyorsabb (jobb kihasználtság).
MAX_ITERS = 34_800        # ~36,5 Mrd token ≈ 1 epoch (train.bin: 36,506,782,094 token; 512×2048×34800)
WARMUP_ITERS = 700
LR = 3e-4
MIN_LR = 3e-5
WEIGHT_DECAY = 0.1
GRAD_CLIP = 1.0
EVAL_INTERVAL = 1000
EVAL_ITERS = 50
CKPT_INTERVAL = 8000       # ~4 köztes mentés — disk-kímélő (133M ~0.5GB/db)


def _adat(split: str, dryrun: bool) -> np.ndarray:
    if dryrun:
        # Szintetikus pici adat a logika-próbához (nem kell valódi shard).
        return np.random.randint(0, VOCAB_MÉRET, size=200_000, dtype=np.uint16)
    út = ADAT_DIR / f"{split}.bin"
    return np.memmap(út, dtype=np.uint16, mode="r")


def _batch(adat, batch_size, block_size, device):
    import torch
    ix = np.random.randint(0, len(adat) - block_size - 1, size=batch_size, dtype=np.int64)
    x = np.stack([adat[i : i + block_size].astype(np.int64) for i in ix])
    y = np.stack([adat[i + 1 : i + 1 + block_size].astype(np.int64) for i in ix])
    x = torch.from_numpy(x).to(device, non_blocking=True)
    y = torch.from_numpy(y).to(device, non_blocking=True)
    return x, y


def _lr(it: int) -> float:
    if it < WARMUP_ITERS:
        return LR * (it + 1) / WARMUP_ITERS
    if it > MAX_ITERS:
        return MIN_LR
    arány = (it - WARMUP_ITERS) / (MAX_ITERS - WARMUP_ITERS)
    return MIN_LR + 0.5 * (1 + math.cos(math.pi * arány)) * (LR - MIN_LR)


def main(dryrun: bool = False):
    import torch
    from transformers import GPT2Config, GPT2LMHeadModel

    device = "cuda" if torch.cuda.is_available() else "cpu"
    print(f"Eszköz: {device} | dryrun={dryrun}", flush=True)

    if dryrun:  # mini konfig + kevés lépés a logika-ellenőrzéshez
        global N_EMBD, N_LAYER, N_HEAD, MAX_ITERS, EVAL_INTERVAL, BATCH_SIZE, GRAD_ACCUM
        N_EMBD, N_LAYER, N_HEAD = 128, 2, 4
        MAX_ITERS, EVAL_INTERVAL, BATCH_SIZE, GRAD_ACCUM = 20, 10, 4, 1

    config = GPT2Config(
        vocab_size=VOCAB_MÉRET, n_positions=BLOCK_SIZE, n_ctx=BLOCK_SIZE,
        n_embd=N_EMBD, n_layer=N_LAYER, n_head=N_HEAD,
        # A mi 32k BPE tokenizálónk speciális tokenjei (különben a GPT2 default
        # 50256-ot venné, ami a 32000-es vocab-on kívül esik → generáláskor sosem állna le).
        bos_token_id=2, eos_token_id=3, pad_token_id=0,
    )
    model = GPT2LMHeadModel(config).to(device)
    params = sum(p.numel() for p in model.parameters())
    print(f"Modell: {params/1e6:.0f}M paraméter", flush=True)

    train, val = _adat("train", dryrun), _adat("val", dryrun)
    opt = torch.optim.AdamW(model.parameters(), lr=LR, weight_decay=WEIGHT_DECAY,
                            betas=(0.9, 0.95))
    use_amp = device == "cuda"
    # A kártyához igazítjuk a dtype-ot: A100/4090 → bf16 (scaler nem kell),
    # T4/régebbi (pl. ingyenes Colab) → fp16 (scaler KELL). Egy script, mindkét helyen helyes.
    amp_dtype = torch.bfloat16 if (use_amp and torch.cuda.is_bf16_supported()) else torch.float16
    scaler = torch.amp.GradScaler("cuda", enabled=(use_amp and amp_dtype == torch.float16))
    KIMENET_DIR.mkdir(parents=True, exist_ok=True)

    @torch.no_grad()
    def val_loss():
        model.eval()
        v = 0.0
        for _ in range(EVAL_ITERS):
            x, y = _batch(val, BATCH_SIZE, BLOCK_SIZE, device)
            with torch.autocast(device_type="cuda", dtype=amp_dtype, enabled=use_amp):
                v += model(input_ids=x, labels=y).loss.item()
        model.train()
        return v / EVAL_ITERS

    t0 = time.time()
    for it in range(MAX_ITERS + 1):
        for g in opt.param_groups:
            g["lr"] = _lr(it)
        opt.zero_grad(set_to_none=True)
        for _ in range(GRAD_ACCUM):
            x, y = _batch(train, BATCH_SIZE, BLOCK_SIZE, device)
            with torch.autocast(device_type="cuda", dtype=amp_dtype, enabled=use_amp):
                loss = model(input_ids=x, labels=y).loss / GRAD_ACCUM
            scaler.scale(loss).backward()
        scaler.unscale_(opt)
        torch.nn.utils.clip_grad_norm_(model.parameters(), GRAD_CLIP)
        scaler.step(opt)
        scaler.update()

        if it % EVAL_INTERVAL == 0:
            print(f"[{time.time()-t0:.0f}s] iter {it}/{MAX_ITERS} "
                  f"val_loss={val_loss():.3f} lr={_lr(it):.2e}", flush=True)
        if it > 0 and it % CKPT_INTERVAL == 0 and not dryrun:
            model.save_pretrained(KIMENET_DIR / f"ckpt_{it}")

    if not dryrun:
        model.save_pretrained(KIMENET_DIR / "vegleges")
    print(f"KÉSZ ({time.time()-t0:.0f}s).", flush=True)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--dryrun", action="store_true", help="mini konfig, pár lépés")
    main(dryrun=ap.parse_args().dryrun)

#!/usr/bin/env python3
"""Magyar alap-nyelvmodell betanítása a korpuszon — Phase 8 / M8.3 (B pont).

A `data/korpusz/` szövegén tanít egy `NyelvModell`-t (tiszta nyelvi modell,
kondíció nélkül), és elmenti a betanított modellt + szótárat. Erre épül majd a
belief-kondicionálás (M8.3.c) finomhangolása.

Futtatás (háttérben ajánlott, ~20-30 perc):
    python scripts/tanitsd_alapmodell.py
"""

from __future__ import annotations

import pickle
import sys
import time
from pathlib import Path

# A háttér-folyamat kimenete cp1250 lehet — UTF-8-ra állítjuk az ékezetekhez.
try:
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")
except (AttributeError, OSError):
    pass

ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(ROOT / "src"))

from elpp.tudat.szoveg import NyelvModell, építs_korpuszt, folytat_szöveg, tanítsd

KORPUSZ = ROOT / "data" / "korpusz"
MENTÉS = ROOT / "models" / "nyelvmodell_alap.pkl"

# Hiperparaméterek (sebesség/minőség egyensúly tiszta-Python+numpy mellett).
MIN_GYAKORISÁG = 8
MAX_TOKEN = 800_000
ABLAK = 3
DIM = 32
REJTETT = 64
EPOCHOK = 2
TANULÁSI_RÁTA = 0.05


def main() -> None:
    t0 = time.time()
    print(f"[{0:>4.0f}s] Korpusz betöltése: {KORPUSZ}", flush=True)
    szótár, idx = építs_korpuszt(
        KORPUSZ, min_gyakoriság=MIN_GYAKORISÁG, max_token=MAX_TOKEN
    )
    print(
        f"[{time.time()-t0:>4.0f}s] szótár={szótár.méret}, tokenek={len(idx)}",
        flush=True,
    )

    m = NyelvModell(szótár.méret, ablak=ABLAK, dim=DIM, rejtett=REJTETT, seed=0)
    MENTÉS.parent.mkdir(parents=True, exist_ok=True)

    for ep in range(EPOCHOK):
        te = time.time()
        napló = tanítsd(
            m, idx, epochok=1, tanulási_ráta=TANULÁSI_RÁTA,
            napló_lépésenként=100_000,
        )
        átlag = napló[-1][1] if napló else float("nan")
        # Checkpoint minden epoch után — ne vesszen el a tanítás.
        with open(MENTÉS, "wb") as f:
            pickle.dump({"modell": m, "szótár": szótár}, f)
        print(
            f"[{time.time()-t0:>4.0f}s] epoch {ep+1}/{EPOCHOK} kesz "
            f"({time.time()-te:.0f}s), veszteseg~{átlag:.2f}, mentve",
            flush=True,
        )

    print("\n--- Minta-generálás ---", flush=True)
    for kezd in ["a férfi", "az asszony", "nem tudom", "egyszer"]:
        print(
            f"  [{kezd}] -> "
            f"{folytat_szöveg(m, szótár, kezd, hossz=12, hőmérséklet=0.5, seed=5)}",
            flush=True,
        )
    print(f"\n[{time.time()-t0:>4.0f}s] KÉSZ.", flush=True)


if __name__ == "__main__":
    main()

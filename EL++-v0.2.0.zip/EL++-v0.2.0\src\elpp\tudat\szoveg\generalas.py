"""Kompozíciós, állapot-vezérelt szöveg-generálás — Phase 7 / M7.1.

A tudat NEM kész mondatokat választ, hanem a SAJÁT hiedelem-állapotából RAKJA
ÖSSZE a választ, kis, jelentéshez kötött darabokból. Három lépcső, mind a
hiedelmekből vezérelve (lásd memory/project_phase7_scope.md):

  1. Tartalom-választás — MIT mondjon és milyen SZEREPBEN (állítás / indok /
     kérdés / ellenpont). Vezérlők: confidence, meta-bizonytalanság (→ kérdez),
     feszültség/ellentmondás (→ "egyrészt… másrészt…").
  2. Üzenet-tervezés — koherens SORREND + kötőszavak a hiedelmek viszonyából.
  3. Felszíni megfogalmazás — a darabokat egy `FragmentForrás`-ból veszi
     (az EL++ kifejezés-paletta tölti fel M7.2-ben), a confidence-SÁV választja
     a megfelelő darabokat. Itt NINCS beégetett mondat.

**Grounded garancia:** a generáló soha nem talál ki szöveget. Ha egy
(hiedelem, szerep, sáv) hármashoz nincs darab a forrásban, az az egység
kimarad — a tudat csak azt mondja ki, amihez van „szava", és amit tényleg hisz.

Ez a modul RUNTIME-FÜGGETLEN: `HiedelemPillanat` + `FragmentForrás` absztrakción
dolgozik, így önállóan tesztelhető. A runtime-ból pillanatokat építeni M7.3 dolga.
"""

from __future__ import annotations

import random
from abc import ABC, abstractmethod
from dataclasses import dataclass, field


# ─────────────────────────────────────────────────────────────────────────────
# Szerepek és sávok
# ─────────────────────────────────────────────────────────────────────────────


class Szerep:
    """Egy megnyilvánulás kommunikációs szerepe (mit csinál a mondatban)."""

    NYUGTÁZÁS = "nyugtázás"   # a helyzet elismerése ("Látom...")
    ÁLLÍTÁS = "állítás"        # grounded kijelentés a hiedelemről
    INDOK = "indok"            # a kijelentés alátámasztása (a tényezőből)
    ELLENPONT = "ellenpont"    # ellentmondás másik oldala ("ugyanakkor...")
    JAVASLAT = "javaslat"      # cselekvési tanács
    KÉRDÉS = "kérdés"          # tisztázó kérdés (meta-bizonytalanságból)


class Sáv:
    """Confidence-sáv — a megfogalmazás erősségét/árnyalatát választja."""

    MAGAS = "magas"            # confidence ≥ magas_küszöb
    KÖZEPES = "közepes"        # a kettő között
    ALACSONY = "alacsony"      # confidence < alacsony_küszöb (a tudat NEM hiszi)
    BIZONYTALAN = "bizonytalan"  # meta-bizonytalanság magas → felülír mindent


# A megfogalmazásnál clause-szinten kapcsolódó szerepek (nem új mondat, hanem
# az előző mondathoz fűzött tagmondat).
_CLAUSE_SZEREPEK = frozenset({Szerep.INDOK, Szerep.ELLENPONT})

# Alapértelmezett kötőszavak (generikus magyar, nem domain-függő).
_ALAP_KÖTŐSZÓ = {
    Szerep.INDOK: "mert",
    Szerep.ELLENPONT: "ugyanakkor",
}

# A mondat-kezdő szerepek prioritása a tervezésnél (kisebb = előrébb).
_SZEREP_PRIORITÁS = {
    Szerep.NYUGTÁZÁS: 0,
    Szerep.ÁLLÍTÁS: 1,
    Szerep.ELLENPONT: 1,
    Szerep.INDOK: 1,
    Szerep.JAVASLAT: 2,
    Szerep.KÉRDÉS: 3,
}


# ─────────────────────────────────────────────────────────────────────────────
# Adatszerkezetek
# ─────────────────────────────────────────────────────────────────────────────


@dataclass
class HiedelemPillanat:
    """Egy hiedelem pillanatképe a generáláshoz — runtime-független.

    Mezők:
        név: a hiedelem neve.
        confidence: aktuális [0,1] bizonyosság.
        meta_bizonytalanság: epistemikus bizonytalanság (Phase 2.2).
        feszültség: ellentmondás-feszültség (Phase 2.3).
        fókusz: ez a beszélgetés aktuális fókusz-hiedelme?
        indok: a domináns tényező ember-olvasható leírása (grounded indokhoz),
            vagy None.
    """

    név: str
    confidence: float
    meta_bizonytalanság: float = 0.0
    feszültség: float = 0.0
    fókusz: bool = False
    indok: str | None = None

    @property
    def fontosság(self) -> float:
        """Mennyire 'mondandó' ez a hiedelem — a fókusz mindig 1.0, egyébként
        a 0.5-től való távolság (erős igen VAGY erős nem egyaránt fontos)."""
        if self.fókusz:
            return 1.0
        return min(1.0, abs(self.confidence - 0.5) * 2.0)


@dataclass
class Megnyilvánulás:
    """Egy tartalmi egység: mit mond a tudat, milyen szerepben, melyik
    hiedelemre alapozva, milyen sávban — plusz a tervezéskor kapott kötőszó."""

    szerep: str
    hiedelem: str
    sáv: str
    kötőszó: str = ""


# ─────────────────────────────────────────────────────────────────────────────
# Fragment-forrás (a felszíni darabok absztrakciója)
# ─────────────────────────────────────────────────────────────────────────────


class FragmentForrás(ABC):
    """A komponálható, RAGOZOTT felszíni darabok forrása.

    M7.2-ben az EL++ `kifejezés` blokkok töltik fel; itt absztrakt, hogy az M7.1
    generáló önállóan tesztelhető legyen.
    """

    @abstractmethod
    def fragmensek(self, hiedelem: str, szerep: str, sáv: str) -> list[str]:
        """A (hiedelem, szerep, sáv) hármashoz tartozó darabok. Üres lista, ha
        nincs ilyen — ekkor a generáló kihagyja (grounded: nem talál ki)."""
        raise NotImplementedError


class DictForrás(FragmentForrás):
    """Egyszerű, dict-alapú forrás — teszteléshez és alapértelmezéshez.

    Kulcs: (hiedelem, szerep, sáv) → darabok listája.
    """

    def __init__(self, tábla: dict[tuple[str, str, str], list[str]] | None = None):
        self._tábla: dict[tuple[str, str, str], list[str]] = dict(tábla or {})

    def add(self, hiedelem: str, szerep: str, sáv: str, darabok: list[str]) -> None:
        self._tábla[(hiedelem, szerep, sáv)] = list(darabok)

    def fragmensek(self, hiedelem: str, szerep: str, sáv: str) -> list[str]:
        return list(self._tábla.get((hiedelem, szerep, sáv), []))


# ─────────────────────────────────────────────────────────────────────────────
# Sáv meghatározás
# ─────────────────────────────────────────────────────────────────────────────


def sáv_meghatározás(
    confidence: float,
    meta_bizonytalanság: float = 0.0,
    *,
    bizonytalan_küszöb: float = 0.5,
    magas_küszöb: float = 0.7,
    alacsony_küszöb: float = 0.4,
) -> str:
    """A confidence-ből és meta-bizonytalanságból sávot határoz meg.

    A meta-bizonytalanság FELÜLÍR: ha túl magas, a tudat nem állít, hanem kérdez.
    """
    if meta_bizonytalanság > bizonytalan_küszöb:
        return Sáv.BIZONYTALAN
    if confidence >= magas_küszöb:
        return Sáv.MAGAS
    if confidence < alacsony_küszöb:
        return Sáv.ALACSONY
    return Sáv.KÖZEPES


# ─────────────────────────────────────────────────────────────────────────────
# 1. lépcső — Tartalom-választás
# ─────────────────────────────────────────────────────────────────────────────


def tartalom_választás(
    pillanatok: list[HiedelemPillanat],
    *,
    bizonytalan_küszöb: float = 0.5,
    magas_küszöb: float = 0.7,
    alacsony_küszöb: float = 0.4,
    feszültség_küszöb: float = 0.5,
    fontosság_küszöb: float = 0.4,
    max_hiedelem: int = 2,
) -> list[Megnyilvánulás]:
    """A hiedelem-pillanatokból eldönti, MIT mond a tudat és milyen szerepben.

    - Fókusz + a legfontosabb hiedelmek (max_hiedelem-ig).
    - BIZONYTALAN sáv → tisztázó KÉRDÉS (a tudat nem tippel).
    - Magas feszültség → ÁLLÍTÁS + ELLENPONT (ellentmondás kifejezése).
    - Egyébként → ÁLLÍTÁS (+ INDOK, ha van grounded indok).
    """
    if not pillanatok:
        return []

    rendezett = sorted(
        pillanatok, key=lambda p: (not p.fókusz, -p.fontosság)
    )
    kiválasztott: list[HiedelemPillanat] = []
    for p in rendezett:
        if len(kiválasztott) >= max_hiedelem:
            break
        # Mindig legyen legalább egy (a legfontosabb), különben csak a fontosak.
        if p.fókusz or p.fontosság >= fontosság_küszöb or not kiválasztott:
            kiválasztott.append(p)

    egységek: list[Megnyilvánulás] = []
    for p in kiválasztott:
        # A megfogalmazás SÁVJA a confidence-ből jön (a meta-felülírás nélkül),
        # hogy ellentmondásnál is a tényleges erősséget tükrözze.
        conf_sáv = sáv_meghatározás(
            p.confidence,
            0.0,
            magas_küszöb=magas_küszöb,
            alacsony_küszöb=alacsony_küszöb,
        )
        bizonytalan = p.meta_bizonytalanság > bizonytalan_küszöb

        if p.feszültség > feszültség_küszöb and conf_sáv == Sáv.KÖZEPES:
            # Ellentmondás → "egyrészt… másrészt…". CSAK ha a tudat tényleg
            # INGADOZIK (közepes sáv): ekkor az ütköző evidencia kimondása
            # informatívabb, mint kérdezni. Magabiztos hiedelem (magas/alacsony)
            # magabiztosan állít, akkor is, ha egy gyengébb csatorna eltér.
            egységek.append(Megnyilvánulás(Szerep.ÁLLÍTÁS, p.név, conf_sáv))
            egységek.append(Megnyilvánulás(Szerep.ELLENPONT, p.név, conf_sáv))
        elif bizonytalan:
            # Nem állít — kérdez.
            egységek.append(
                Megnyilvánulás(Szerep.KÉRDÉS, p.név, Sáv.BIZONYTALAN)
            )
        else:
            egységek.append(Megnyilvánulás(Szerep.ÁLLÍTÁS, p.név, conf_sáv))
            if p.indok:
                egységek.append(Megnyilvánulás(Szerep.INDOK, p.név, conf_sáv))
    return egységek


# ─────────────────────────────────────────────────────────────────────────────
# 2. lépcső — Üzenet-tervezés
# ─────────────────────────────────────────────────────────────────────────────


def tervezés(egységek: list[Megnyilvánulás]) -> list[Megnyilvánulás]:
    """Koherens sorrendbe rendezi az egységeket és kötőszavakat rendel.

    Sorrend: nyugtázás → állítások/indokok/ellenpontok (blokk-szomszédság
    megőrizve) → javaslatok → kérdések a végén. Stabil rendezés, így az egy
    hiedelemhez tartozó állítás+indok együtt marad.
    """
    rendezett = sorted(
        egységek, key=lambda e: _SZEREP_PRIORITÁS.get(e.szerep, 9)
    )
    eredmény: list[Megnyilvánulás] = []
    for e in rendezett:
        kötőszó = e.kötőszó or _ALAP_KÖTŐSZÓ.get(e.szerep, "")
        eredmény.append(
            Megnyilvánulás(e.szerep, e.hiedelem, e.sáv, kötőszó)
        )
    return eredmény


# ─────────────────────────────────────────────────────────────────────────────
# 3. lépcső — Felszíni megfogalmazás
# ─────────────────────────────────────────────────────────────────────────────


def megfogalmazás(
    tervezett: list[Megnyilvánulás],
    forrás: FragmentForrás,
    *,
    rng: random.Random | None = None,
) -> str:
    """A tervezett egységeket grounded szöveggé fűzi a forrás darabjaiból.

    - Clause-szerepek (INDOK, ELLENPONT) az ELŐZŐ mondathoz kapcsolódnak
      (", kötőszó darab"), nem új mondatként.
    - Minden más egység új mondatot kezd.
    - Mondat-kezdő nagybetű + záró írásjel ('?' a kérdésnél, egyébként '.').
    - Ha egy egységhez nincs darab a forrásban, kimarad (grounded).
    """
    rng = rng or random.Random()
    mondatok: list[dict] = []  # {szöveg, kérdés}

    for e in tervezett:
        darabok = forrás.fragmensek(e.hiedelem, e.szerep, e.sáv)
        if not darabok:
            continue  # grounded: nincs szó rá → nem mond rá semmit
        darab = rng.choice(darabok)

        if e.szerep in _CLAUSE_SZEREPEK and mondatok:
            kötő = e.kötőszó or _ALAP_KÖTŐSZÓ.get(e.szerep, "")
            toldás = f", {kötő} {darab}" if kötő else f", {darab}"
            mondatok[-1]["szöveg"] += toldás
        else:
            mondatok.append(
                {"szöveg": darab, "kérdés": e.szerep == Szerep.KÉRDÉS}
            )

    részek: list[str] = []
    for m in mondatok:
        sz = m["szöveg"].strip()
        if not sz:
            continue
        sz = sz[0].upper() + sz[1:]
        sz += "?" if m["kérdés"] else "."
        részek.append(sz)
    return " ".join(részek)


# ─────────────────────────────────────────────────────────────────────────────
# A teljes csővezeték
# ─────────────────────────────────────────────────────────────────────────────


@dataclass
class Generáló:
    """A 3-lépcsős kompozíciós generáló egyetlen belépési ponttal.

    Használat:
        gen = Generáló(forrás)
        szöveg = gen.generál(pillanatok, seed=0)
    """

    forrás: FragmentForrás
    bizonytalan_küszöb: float = 0.5
    magas_küszöb: float = 0.7
    alacsony_küszöb: float = 0.4
    feszültség_küszöb: float = 0.5
    max_hiedelem: int = 2

    def generál(
        self, pillanatok: list[HiedelemPillanat], *, seed: int | None = None
    ) -> str:
        """Hiedelem-pillanatokból grounded, összerakott választ generál."""
        egységek = tartalom_választás(
            pillanatok,
            bizonytalan_küszöb=self.bizonytalan_küszöb,
            magas_küszöb=self.magas_küszöb,
            alacsony_küszöb=self.alacsony_küszöb,
            feszültség_küszöb=self.feszültség_küszöb,
            max_hiedelem=self.max_hiedelem,
        )
        tervezett = tervezés(egységek)
        return megfogalmazás(
            tervezett, self.forrás, rng=random.Random(seed)
        )

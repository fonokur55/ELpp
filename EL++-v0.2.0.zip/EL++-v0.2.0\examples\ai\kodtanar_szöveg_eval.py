"""Held-out értékelő-szett a szöveg-alapú KódTanárhoz (Phase 6 / M6.4).

20 KÉZZEL ÍRT példa, amit a tudat tanítás közben SOHA nem lát. Ezért a rajta
mért pontosság becsületes (nincs adat-szivárgás a tanításból). Más szövegek,
mint a tanító-magban — ugyanazok az archetípusok, friss megfogalmazásban.

Használat:
    import kodtanar_szöveg_eval as ev
    import kodtanar_szöveg_adat as kd
    metrikák = rt.értékelés(ev.eval_adat(), célok=kd.CÉLOK)
"""

from __future__ import annotations

# 5-5 példa a 4 archetípusra (kezdő / frusztrált / haladó / trehány),
# friss szövegekkel — egyik sem szerepel a tanító-magban.
_EVAL: list[dict] = [
    # — kezdő, nyugodt —
    {"diák_kódja": "k = 7\nprint(k)",
     "diák_üzenete": "így kell értéket adni egy változónak?",
     "valós_frusztrált": 0.15, "valós_kezdő": 0.9, "valós_gyenge": 0.4},
    {"diák_kódja": "nev = 'Anna'",
     "diák_üzenete": "mi az a sztring, most ismerkedem vele",
     "valós_frusztrált": 0.1, "valós_kezdő": 0.92, "valós_gyenge": 0.35},
    {"diák_kódja": "print(2 + 2)",
     "diák_üzenete": "ez az első programom, jól csinálom?",
     "valós_frusztrált": 0.15, "valós_kezdő": 0.9, "valós_gyenge": 0.3},
    {"diák_kódja": "ev = 2024\nprint(ev)",
     "diák_üzenete": "tudnál egy egyszerű feladatot adni gyakorlásra?",
     "valós_frusztrált": 0.18, "valós_kezdő": 0.88, "valós_gyenge": 0.4},
    {"diák_kódja": "m = 3\nprint(m)",
     "diák_üzenete": "most kezdtem, mi a következő amit tanuljak?",
     "valós_frusztrált": 0.15, "valós_kezdő": 0.9, "valós_gyenge": 0.4},

    # — frusztrált, hibázik —
    {"diák_kódja": "for j in range(5)\n  print(j)",
     "diák_üzenete": "miért nem jó ez?! teljesen kiborultam!!!",
     "valós_frusztrált": 0.95, "valós_kezdő": 0.6, "valós_gyenge": 0.5},
    {"diák_kódja": "print(szam",
     "diák_üzenete": "megint piros lett az egész, nem bírom már!",
     "valós_frusztrált": 0.92, "valós_kezdő": 0.6, "valós_gyenge": 0.55},
    {"diák_kódja": "x == 5\nprint(x)",
     "diák_üzenete": "nem megy és nem értem miért!!",
     "valós_frusztrált": 0.93, "valós_kezdő": 0.6, "valós_gyenge": 0.5},
    {"diák_kódja": "def g()\n  return 1",
     "diák_üzenete": "egy órája próbálom, feladom!",
     "valós_frusztrált": 0.9, "valós_kezdő": 0.55, "valós_gyenge": 0.5},
    {"diák_kódja": "if a\n print(a)",
     "diák_üzenete": "ez az egész hülyeség, semmi sem működik!!!",
     "valós_frusztrált": 0.95, "valós_kezdő": 0.55, "valós_gyenge": 0.55},

    # — haladó, nyugodt —
    {"diák_kódja": ("def atlag(szamok):\n"
                    "    if not szamok:\n"
                    "        return 0\n"
                    "    return sum(szamok) / len(szamok)"),
     "diák_üzenete": "kezelem az üres esetet is, szerinted elég robusztus?",
     "valós_frusztrált": 0.06, "valós_kezdő": 0.1, "valós_gyenge": 0.12},
    {"diák_kódja": ("def fordit(szoveg):\n"
                    "    return szoveg[::-1]"),
     "diák_üzenete": "egy sorban megoldható, szerintem szép",
     "valós_frusztrált": 0.05, "valós_kezdő": 0.08, "valós_gyenge": 0.1},
    {"diák_kódja": ("def keres(lista, cel):\n"
                    "    for i, e in enumerate(lista):\n"
                    "        if e == cel:\n"
                    "            return i\n"
                    "    return -1"),
     "diák_üzenete": "visszaadom az indexet vagy -1-et, jó konvenció?",
     "valós_frusztrált": 0.06, "valós_kezdő": 0.1, "valós_gyenge": 0.12},
    {"diák_kódja": ("def szum_negyzet(n):\n"
                    "    return sum(i * i for i in range(n))"),
     "diák_üzenete": "generátor-kifejezéssel memóriahatékony, egyetértesz?",
     "valós_frusztrált": 0.05, "valós_kezdő": 0.09, "valós_gyenge": 0.1},
    {"diák_kódja": ("def egyedi(elemek):\n"
                    "    return list(set(elemek))"),
     "diák_üzenete": "duplikátumok kiszűrésére ezt találtam, oké?",
     "valós_frusztrált": 0.06, "valós_kezdő": 0.12, "valós_gyenge": 0.14},

    # — trehány kód, nyugodt —
    {"diák_kódja": "x = 2\ny = 8\nz = x*y\nprint(z)",
     "diák_üzenete": "megy, csak gyorsan kellett valami",
     "valós_frusztrált": 0.18, "valós_kezdő": 0.5, "valós_gyenge": 0.88},
    {"diák_kódja": "a=10\nb=20\nprint(a+b)",
     "diák_üzenete": "működik, a szépségére most nem figyeltem",
     "valós_frusztrált": 0.15, "valós_kezdő": 0.55, "valós_gyenge": 0.9},
    {"diák_kódja": "x = 1\nx = x*2\nx = x*2\nprint(x)",
     "diák_üzenete": "tudom hogy ismétlem magam, de lefut",
     "valós_frusztrált": 0.2, "valós_kezdő": 0.5, "valós_gyenge": 0.9},
    {"diák_kódja": "d = [1,2,3]\ns=0\nfor i in d:s=s+i\nprint(s)",
     "diák_üzenete": "összegez, nekem ennyi most elég",
     "valós_frusztrált": 0.18, "valós_kezdő": 0.45, "valós_gyenge": 0.87},
    {"diák_kódja": "x = 3\ny = x\nz = y\nprint(z)",
     "diák_üzenete": "kész, működik ahogy van",
     "valós_frusztrált": 0.15, "valós_kezdő": 0.55, "valós_gyenge": 0.85},
]


def eval_adat() -> list[dict]:
    """A 20 held-out értékelő-példa (másolatként, hogy ne lehessen módosítani)."""
    return [dict(p) for p in _EVAL]

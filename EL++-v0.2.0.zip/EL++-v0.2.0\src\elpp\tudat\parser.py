"""Tudat-blokk parser.

A fő `elpp.parser.Parser` delegál ide, amikor `TUDAT` tokent lát. A modul
nem importálja a Parser-t modul-szinten (körkörös import elkerülése) —
csak TYPE_CHECKING alatt.

Phase 1 — M1 (csontváz):
    Tudat / terület / hiedelem / súly / cél deklarációk parse.

Phase 1 — M2 (tényezők):
    `hiedelem X jön: tényező ... kész` bővítés. 4 tényező-típus parse:
    neurális, szabály (újrahasznosított RULE token), hiedelem (BELIEF_DECL),
    cél (GOAL_DECL).

Phase 1 — M3 (élet):
    `észlelés (params): ... kész` blokk parse — CSAK tudat-szinten,
    területbe nem kerülhet (a parser barátságos hibát ad, ha mégis).

Phase 1 — M4 (önreflexió):
    `reflexió "<címke>": ... kész` blokk parse, CSAK tudat-szinten.
    Body: `magyarázd <belief_name>` statementek listája.

Phase 1 — M5 (tanulás):
    `tanulás[ (params)]: ... kész` blokk parse, CSAK tudat-szinten.
    Body: `tanulj <belief_name> -> <expr>` statementek. Body M5-ben
    parse-ol, de nem fut — Python API (rt.tanulj) végzi a tanulást.

Phase 2 — M2.1 (hipotetikus):
    `mi_lenne_ha "<címke>" (név1 = érték1, ...): ... kész` blokk,
    CSAK tudat-szinten. Body: csak `magyarázd` statementek. A felülírások
    név=érték párok, ahol a név súly/context/cél/hiedelem lehet.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from elpp.errors import ParseError
from elpp.tudat import ast as tudat_ast

if TYPE_CHECKING:
    from elpp.parser import Parser


# A tudaton belül megengedett item-kezdő tokenek (M2.1: WHAT_IF is).
_TUDAT_ITEM_START_KINDS: tuple[str, ...] = (
    "AREA",
    "BELIEF_DECL",
    "WEIGHT_DECL",
    "GOAL_DECL",
    "PERCEPTION",
    "REFLECTION",
    "TRAINING",
    "WHAT_IF",
    "KIFEJEZÉS",
)

# Phase 7 / M7.2: a kifejezés-blokkban engedélyezett szerepek és sávok.
# (A `kérdés` a lexerben QUERY-re tokenizálódik — a parser ezt is elfogadja.)
_KIFEJEZÉS_SZEREPEK: frozenset[str] = frozenset(
    {"nyugtázás", "állítás", "indok", "ellenpont", "javaslat", "kérdés"}
)
_KIFEJEZÉS_SÁVOK: frozenset[str] = frozenset(
    {"magas", "közepes", "alacsony", "bizonytalan"}
)

# Területen belül megengedett item-kezdő tokenek (PERCEPTION NEM).
_AREA_ITEM_START_KINDS: tuple[str, ...] = (
    "BELIEF_DECL",
    "WEIGHT_DECL",
    "GOAL_DECL",
)


def parse_tudat(parser: "Parser") -> tudat_ast.TudatDecl:
    """`tudat <Név>[:] <body> kész` — teljes tudat blokk parse."""
    line = parser._cur().line
    parser._advance()  # TUDAT

    name_t = parser._expect(
        "IDENT", "Tudat-név kell (pl. `tudat IdőjárásBecslő:`)."
    )
    name = str(name_t.value)
    parser._match("COLON")

    body = _parse_body(
        parser,
        owner_label=f"tudat `{name}`",
        allow_perception=True,
        allow_area=True,
        allow_reflection=True,
        allow_training=True,
        allow_what_if=True,
        allow_kifejezés=True,
    )

    if parser._cur().kind != "END":
        raise ParseError(
            f"Hiányzik a tudat `{name}` záró `kész` / `end`-je.",
            line=parser._cur().line,
        )
    parser._advance()  # END

    return tudat_ast.TudatDecl(name=name, body=body, line=line)


def _parse_body(
    parser: "Parser",
    *,
    owner_label: str,
    allow_perception: bool,
    allow_area: bool,
    allow_reflection: bool = False,
    allow_training: bool = False,
    allow_what_if: bool = False,
    allow_kifejezés: bool = False,
) -> list[tudat_ast.TudatItem]:
    """Egységes body parser tudat- és terület-szintű blokkokhoz.

    Flag-ek döntik, mely item-típusok megengedettek:
      - `allow_perception=True` csak tudat-szinten.
      - `allow_reflection=True` csak tudat-szinten (M4).
      - `allow_training=True`   csak tudat-szinten (M5).
      - `allow_area=True`       csak tudat-szinten.
    """
    items: list[tudat_ast.TudatItem] = []
    while not parser._at_end() and parser._cur().kind != "END":
        k = parser._cur().kind
        if k == "AREA":
            if not allow_area:
                t = parser._cur()
                raise ParseError(
                    f"Terület-en belül NEM lehet újabb terület — itt `{t.kind}` "
                    f"áll (`{owner_label}`).",
                    line=t.line,
                )
            items.append(_parse_area(parser))
        elif k == "PERCEPTION":
            if not allow_perception:
                t = parser._cur()
                raise ParseError(
                    f"`észlelés` blokk CSAK tudat-szinten lehet, területbe "
                    f"nem kerülhet (`{owner_label}`).",
                    line=t.line,
                )
            items.append(_parse_perception(parser))
        elif k == "REFLECTION":
            if not allow_reflection:
                t = parser._cur()
                raise ParseError(
                    f"`reflexió` blokk CSAK tudat-szinten lehet, területbe "
                    f"nem kerülhet (`{owner_label}`).",
                    line=t.line,
                )
            items.append(_parse_reflection(parser))
        elif k == "TRAINING":
            if not allow_training:
                t = parser._cur()
                raise ParseError(
                    f"`tanulás` blokk CSAK tudat-szinten lehet, területbe "
                    f"nem kerülhet (`{owner_label}`).",
                    line=t.line,
                )
            items.append(_parse_training(parser))
        elif k == "WHAT_IF":
            if not allow_what_if:
                t = parser._cur()
                raise ParseError(
                    f"`mi_lenne_ha` blokk CSAK tudat-szinten lehet, területbe "
                    f"nem kerülhet (`{owner_label}`).",
                    line=t.line,
                )
            items.append(_parse_what_if(parser))
        elif k == "KIFEJEZÉS":
            if not allow_kifejezés:
                t = parser._cur()
                raise ParseError(
                    f"`kifejezés` blokk CSAK tudat-szinten lehet, területbe "
                    f"nem kerülhet (`{owner_label}`).",
                    line=t.line,
                )
            items.append(_parse_kifejezés(parser))
        elif k == "BELIEF_DECL":
            items.append(_parse_belief(parser))
        elif k == "WEIGHT_DECL":
            items.append(_parse_weight(parser))
        elif k == "GOAL_DECL":
            items.append(_parse_goal(parser))
        else:
            t = parser._cur()
            allowed = "`hiedelem`, `súly`, `cél`"
            if allow_area:
                allowed += ", `terület`"
            if allow_perception:
                allowed += ", `észlelés`"
            if allow_reflection:
                allowed += ", `reflexió`"
            if allow_training:
                allowed += ", `tanulás`"
            if allow_what_if:
                allowed += ", `mi_lenne_ha`"
            if allow_kifejezés:
                allowed += ", `kifejezés`"
            raise ParseError(
                f"`{owner_label}`-ben csak {allowed} (vagy záró `kész`) "
                f"megengedett — itt `{t.kind}` áll.",
                line=t.line,
            )
    return items


def _parse_area(parser: "Parser") -> tudat_ast.AreaDecl:
    """`terület <Név>[:] <body> kész`"""
    line = parser._cur().line
    parser._advance()  # AREA

    name_t = parser._expect(
        "IDENT", "Terület-név kell (pl. `terület felhőkép:`)."
    )
    name = str(name_t.value)
    parser._match("COLON")

    body = _parse_body(
        parser,
        owner_label=f"terület `{name}`",
        allow_perception=False,
        allow_area=False,
    )

    if parser._cur().kind != "END":
        raise ParseError(
            f"Hiányzik a terület `{name}` záró `kész`-e.",
            line=parser._cur().line,
        )
    parser._advance()  # END

    return tudat_ast.AreaDecl(name=name, body=body, line=line)


def _parse_belief(parser: "Parser") -> tudat_ast.BeliefDecl:
    """`hiedelem <név>` — M1 egyszerű deklaráció.

    M2 bővítés: `hiedelem <név> jön: tényező ... kész` — érték-definíció
    tényezőkből. A `jön:` opcionális — nélküle a hiedelem csak deklaráció,
    confidence-e default 0.5.
    """
    line = parser._cur().line
    parser._advance()  # BELIEF_DECL
    name_t = parser._expect(
        "IDENT", "Hiedelem-név kell (pl. `hiedelem esni_fog`)."
    )
    name = str(name_t.value)

    factors: list[tudat_ast.Factor] = []
    if parser._match("FROM"):  # `jön`
        parser._match("COLON")
        while parser._cur().kind == "FACTOR":
            factors.append(_parse_factor(parser))
        if parser._cur().kind != "END":
            t = parser._cur()
            raise ParseError(
                f"`hiedelem {name} jön:` blokkban csak `tényező` (vagy záró "
                f"`kész`) megengedett — itt `{t.kind}` áll.",
                line=t.line,
            )
        parser._advance()  # END (a `jön:` blokk záró kész-e)

    return tudat_ast.BeliefDecl(name=name, factors=factors, line=line)


def _parse_weight(parser: "Parser") -> tudat_ast.WeightDecl:
    """`súly <név>` vagy `súly <név> : tenzor[n, m, ...]` (M4.1).

    Annotáció nélkül → skalár (visszafelé kompatibilis).
    `: tenzor[shape]` → tenzor-súly a megadott alakkal, random init.
    """
    line = parser._cur().line
    parser._advance()  # WEIGHT_DECL
    name_t = parser._expect(
        "IDENT", "Súly-név kell (pl. `súly W`)."
    )
    name = str(name_t.value)

    tensor_shape: list[int] | None = None
    if parser._match("COLON"):
        # `: tenzor[...]`
        parser._expect(
            "TENSOR",
            "Súly-annotáció után `tenzor` kell (pl. `súly W : tenzor[3]`).",
        )
        parser._expect("LBRACKET", "Tenzor-shape kell `[`-pal.")
        shape: list[int] = []
        dim_tok = parser._expect("NUMBER", "Shape-dimenzió szám kell.")
        shape.append(int(dim_tok.value))
        while parser._match("COMMA"):
            dim_tok = parser._expect("NUMBER", "Shape-dimenzió szám kell.")
            shape.append(int(dim_tok.value))
        parser._expect("RBRACKET", "Hiányzik a záró `]`.")
        tensor_shape = shape

    return tudat_ast.WeightDecl(
        name=name, tensor_shape=tensor_shape, line=line
    )


def _parse_goal(parser: "Parser") -> tudat_ast.GoalDecl:
    """`cél <név>`"""
    line = parser._cur().line
    parser._advance()  # GOAL_DECL
    name_t = parser._expect(
        "IDENT", "Cél-név kell (pl. `cél pontos_jóslat`)."
    )
    return tudat_ast.GoalDecl(name=str(name_t.value), line=line)


# ─────────────────────────────────────────────────────────────────────────────
# Észlelés (M3)
# ─────────────────────────────────────────────────────────────────────────────


def _parse_perception(parser: "Parser") -> tudat_ast.PerceptionBlock:
    """`észlelés (param1, param2, ...): <body> kész`

    M3-ban a body parse-ol (tetszőleges statement-eket fogad el), de NEM
    fut le — a reaktív frissítés automatikus. A body futtatása M4+ téma.
    """
    line = parser._cur().line
    parser._advance()  # PERCEPTION

    # Paraméter-lista: kötelező `(`, opcionálisan üres, `)`
    parser._expect(
        "LPAREN", "Észlelés-paraméterek listája kell (pl. `észlelés (felhő, ...)`)."
    )
    params: list[str] = []
    if parser._cur().kind != "RPAREN":
        params.append(str(parser._expect("IDENT", "Paraméter-név kell.").value))
        while parser._match("COMMA"):
            params.append(
                str(parser._expect("IDENT", "Paraméter-név kell vessző után.").value)
            )
    parser._expect("RPAREN", "Hiányzik a záró `)`.")

    parser._match("COLON")

    # Body: tetszőleges statement-ek, amíg END nem jön.
    # Újrahasznosítjuk a fő parser _block()-ját, ami END-ig olvas.
    body = parser._block()

    if parser._cur().kind != "END":
        raise ParseError(
            "Hiányzik az `észlelés` blokk záró `kész`-e.",
            line=parser._cur().line,
        )
    parser._advance()  # END

    return tudat_ast.PerceptionBlock(params=params, body=body, line=line)


# ─────────────────────────────────────────────────────────────────────────────
# Önreflexió (M4)
# ─────────────────────────────────────────────────────────────────────────────


def _parse_reflection(parser: "Parser") -> tudat_ast.ReflectionBlock:
    """`reflexió "<címke>": <body> kész`

    A `body` M4-ben CSAK `magyarázd <belief_name>` statementeket fogad el.
    Egyéb tartalom barátságos hibát ad.
    """
    line = parser._cur().line
    parser._advance()  # REFLECTION

    # Címke — sztring-literál.
    if parser._cur().kind != "STRING":
        raise ParseError(
            'Reflexió-címke kell sztringként (pl. `reflexió "miért gondolod?":`).',
            line=parser._cur().line,
        )
    label_t = parser._advance()
    label = str(label_t.value)

    parser._match("COLON")

    # Body: csak ExplainStmt-eket fogadunk el M4-ben.
    body: list[tudat_ast.ExplainStmt] = []
    while not parser._at_end() and parser._cur().kind != "END":
        t = parser._cur()
        if t.kind != "EXPLAIN":
            raise ParseError(
                f"`reflexió \"{label}\"` blokkban csak `magyarázd <hiedelem>` "
                f"(vagy záró `kész`) megengedett — itt `{t.kind}` áll.",
                line=t.line,
            )
        body.append(_parse_explain(parser))

    if parser._cur().kind != "END":
        raise ParseError(
            f'Hiányzik a `reflexió "{label}"` záró `kész`-e.',
            line=parser._cur().line,
        )
    parser._advance()  # END

    return tudat_ast.ReflectionBlock(label=label, body=body, line=line)


def _parse_explain(parser: "Parser") -> tudat_ast.ExplainStmt:
    """`magyarázd <belief_name>` — egy hiedelem magyarázat-kérése."""
    line = parser._cur().line
    parser._advance()  # EXPLAIN
    name_t = parser._expect(
        "IDENT", "Magyarázandó hiedelem neve kell (pl. `magyarázd esni_fog`)."
    )
    return tudat_ast.ExplainStmt(belief_name=str(name_t.value), line=line)


# ─────────────────────────────────────────────────────────────────────────────
# Tanulás (M5)
# ─────────────────────────────────────────────────────────────────────────────


def _parse_training(parser: "Parser") -> tudat_ast.TrainingBlock:
    """`tanulás[ (params)]: <body> kész`

    M5-ben a body PARSE-OL, de NEM fut — `rt.tanulj(**targets)` Python
    API végzi a tényleges tanulást. A body csak deklaráció.
    """
    line = parser._cur().line
    parser._advance()  # TRAINING

    # Opcionális paraméter-lista.
    params: list[str] = []
    if parser._match("LPAREN"):
        if parser._cur().kind != "RPAREN":
            params.append(str(parser._expect("IDENT", "Paraméter-név kell.").value))
            while parser._match("COMMA"):
                params.append(
                    str(parser._expect("IDENT", "Paraméter-név kell vessző után.").value)
                )
        parser._expect("RPAREN", "Hiányzik a záró `)`.")

    parser._match("COLON")

    # Body: csak `tanulj <belief> -> <expr>` statementek M5-ben.
    body: list[tudat_ast.LearnStmt] = []
    while not parser._at_end() and parser._cur().kind != "END":
        t = parser._cur()
        if t.kind != "LEARN":
            raise ParseError(
                f"`tanulás` blokkban csak `tanulj <hiedelem> -> <kifejezés>` "
                f"(vagy záró `kész`) megengedett — itt `{t.kind}` áll.",
                line=t.line,
            )
        body.append(_parse_learn(parser))

    if parser._cur().kind != "END":
        raise ParseError(
            "Hiányzik a `tanulás` blokk záró `kész`-e.",
            line=parser._cur().line,
        )
    parser._advance()  # END

    return tudat_ast.TrainingBlock(params=params, body=body, line=line)


def _parse_learn(parser: "Parser") -> tudat_ast.LearnStmt:
    """`tanulj <belief_name> -> <expr>` — egy tanítási cél."""
    line = parser._cur().line
    parser._advance()  # LEARN
    name_t = parser._expect(
        "IDENT", "Tanítandó hiedelem neve kell (pl. `tanulj esni_fog -> valós`)."
    )
    parser._expect(
        "ARROW", "A `tanulj` után `->` (nyíl) kell, majd a cél-érték kifejezése."
    )
    target_expr = parser._expression()
    return tudat_ast.LearnStmt(
        belief_name=str(name_t.value),
        target_expr=target_expr,
        line=line,
    )


# ─────────────────────────────────────────────────────────────────────────────
# Hipotetikus kérdezés (Phase 2 / M2.1)
# ─────────────────────────────────────────────────────────────────────────────


def _parse_what_if(parser: "Parser") -> tudat_ast.WhatIfBlock:
    """`mi_lenne_ha "<címke>" (név = érték, ...): <body> kész`

    A body M2.1-ben CSAK `magyarázd <belief_name>` statementeket fogad el.
    A felülírások KÖTELEZŐEN zárójelben (üres `()` is megengedett).
    """
    line = parser._cur().line
    parser._advance()  # WHAT_IF

    # Címke — sztring-literál.
    if parser._cur().kind != "STRING":
        raise ParseError(
            'Mi_lenne_ha címke kell sztringként '
            '(pl. `mi_lenne_ha "esős nap" (...):`).',
            line=parser._cur().line,
        )
    label_t = parser._advance()
    label = str(label_t.value)

    # Felülírás-lista — kötelezően zárójelben.
    parser._expect(
        "LPAREN",
        "Mi_lenne_ha-felülírások listája kell zárójelben "
        "(üres `()` is megengedett).",
    )
    overrides: list[tudat_ast.WhatIfOverride] = []
    if parser._cur().kind != "RPAREN":
        overrides.append(_parse_what_if_override(parser))
        while parser._match("COMMA"):
            overrides.append(_parse_what_if_override(parser))
    parser._expect("RPAREN", "Hiányzik a záró `)`.")

    parser._match("COLON")

    # Body: csak ExplainStmt-eket fogadunk el (mint reflexió).
    body: list[tudat_ast.ExplainStmt] = []
    while not parser._at_end() and parser._cur().kind != "END":
        t = parser._cur()
        if t.kind != "EXPLAIN":
            raise ParseError(
                f'`mi_lenne_ha "{label}"` blokkban csak `magyarázd <hiedelem>` '
                f'(vagy záró `kész`) megengedett — itt `{t.kind}` áll.',
                line=t.line,
            )
        body.append(_parse_explain(parser))

    if parser._cur().kind != "END":
        raise ParseError(
            f'Hiányzik a `mi_lenne_ha "{label}"` záró `kész`-e.',
            line=parser._cur().line,
        )
    parser._advance()  # END

    return tudat_ast.WhatIfBlock(
        label=label, overrides=overrides, body=body, line=line
    )


def _parse_what_if_override(parser: "Parser") -> tudat_ast.WhatIfOverride:
    """Egy `név = érték_kifejezés` pár."""
    line = parser._cur().line
    name_t = parser._expect(
        "IDENT", "Felülírás-név kell (pl. `W = 0.8`)."
    )
    parser._expect(
        "EQ", "A `=` (vagy `egyen`) kell a felülírás-név után."
    )
    value_expr = parser._expression()
    return tudat_ast.WhatIfOverride(
        name=str(name_t.value),
        value_expr=value_expr,
        line=line,
    )


# ─────────────────────────────────────────────────────────────────────────────
# Kifejezés-blokk (Phase 7 / M7.2) — a tudat beszéd-palettája
# ─────────────────────────────────────────────────────────────────────────────


def _parse_kifejezés(parser: "Parser") -> tudat_ast.KifejezésBlokk:
    """`kifejezés <hiedelem>: <szerep> <sáv>: "darab", ... kész`

    Minden sor egy bejegyzés: szerep (állítás/indok/.../kérdés) + sáv
    (magas/közepes/alacsony/bizonytalan) + kettőspont + vesszős string-lista.
    A darabok RAGOZOTT felszíni töredékek — a generáló komponálja őket.
    """
    line = parser._cur().line
    parser._advance()  # KIFEJEZÉS

    name_t = parser._expect(
        "IDENT", "Kifejezés-blokk után hiedelem-név kell (pl. `kifejezés frusztrált:`)."
    )
    belief_name = str(name_t.value)
    parser._match("COLON")

    bejegyzések: list[tudat_ast.KifejezésBejegyzés] = []
    while not parser._at_end() and parser._cur().kind != "END":
        bejegyzések.append(_parse_kifejezés_bejegyzés(parser, belief_name))

    if parser._cur().kind != "END":
        raise ParseError(
            f"Hiányzik a `kifejezés {belief_name}` záró `kész`-e.",
            line=parser._cur().line,
        )
    parser._advance()  # END

    return tudat_ast.KifejezésBlokk(
        belief_name=belief_name, bejegyzések=bejegyzések, line=line
    )


def _parse_szerep_szó(parser: "Parser") -> str:
    """Egy szerep-szó beolvasása. A `kérdés` a lexerben QUERY — azt is elfogadjuk."""
    t = parser._cur()
    if t.kind == "QUERY":
        parser._advance()
        return "kérdés"
    if t.kind == "IDENT":
        szó = str(t.value)
        if szó in _KIFEJEZÉS_SZEREPEK:
            parser._advance()
            return szó
    raise ParseError(
        f"Kifejezés-szerep kell ({sorted(_KIFEJEZÉS_SZEREPEK)}) — itt "
        f"`{t.kind}` áll.",
        line=t.line,
    )


def _parse_kifejezés_bejegyzés(
    parser: "Parser", belief_name: str
) -> tudat_ast.KifejezésBejegyzés:
    """`<szerep> <sáv>: "darab"[, "darab"]*`"""
    line = parser._cur().line
    szerep = _parse_szerep_szó(parser)

    sáv_t = parser._expect(
        "IDENT",
        f"A `{szerep}` szerep után sáv kell ({sorted(_KIFEJEZÉS_SÁVOK)}).",
    )
    sáv = str(sáv_t.value)
    if sáv not in _KIFEJEZÉS_SÁVOK:
        raise ParseError(
            f"Ismeretlen sáv: `{sáv}` (választható: {sorted(_KIFEJEZÉS_SÁVOK)}).",
            line=sáv_t.line,
        )

    parser._expect("COLON", f"A `{szerep} {sáv}` után `:` kell.")

    darabok: list[str] = []
    if parser._cur().kind != "STRING":
        raise ParseError(
            f"`kifejezés {belief_name}` / `{szerep} {sáv}:` után legalább egy "
            f'szöveg-darab kell (pl. "látom, hogy elakadtál").',
            line=parser._cur().line,
        )
    darabok.append(str(parser._advance().value))
    while parser._match("COMMA"):
        s_t = parser._expect("STRING", "Vessző után újabb szöveg-darab kell.")
        darabok.append(str(s_t.value))

    return tudat_ast.KifejezésBejegyzés(
        szerep=szerep, sáv=sáv, darabok=darabok, line=line
    )


# ─────────────────────────────────────────────────────────────────────────────
# Tényezők (M2)
# ─────────────────────────────────────────────────────────────────────────────


def _parse_factor(parser: "Parser") -> tudat_ast.Factor:
    """`tényező <típus> <részletek>` — egyetlen tényező parse-olása.

    A 4 alaptípus:
      neurális <kifejezés>
      szabály ha <feltétel> akkor <bizonyosság>
      hiedelem <név>
      cél <név>

    Phase 8 / M8.2: opcionális `ellen` módosító — `tényező ellen <típus> ...` —
    a tényező KIVONÓ (negatív) evidencia: csökkenti a hiedelmet, nem emeli.
    """
    line = parser._cur().line
    parser._advance()  # FACTOR

    # M8.2: opcionális `ellen` előjel-módosító (tiszta bool-lá alakítva).
    ellen = parser._match("ELLEN") is not None

    type_tok = parser._cur()

    if type_tok.kind == "NEURAL":
        parser._advance()
        expr = parser._expression()
        return tudat_ast.NeuralFactor(expr=expr, ellen=ellen, line=line)

    if type_tok.kind == "RULE":
        parser._advance()
        parser._expect(
            "IF", "Szabály-tényező után `ha` (`if`) kell."
        )
        cond = parser._expression()
        parser._expect(
            "THEN", "Szabály-tényezőben `akkor` (`then`) kötelező."
        )
        conf = parser._expression()
        return tudat_ast.RuleFactor(
            condition=cond, confidence=conf, ellen=ellen, line=line
        )

    if type_tok.kind == "BELIEF_DECL":
        parser._advance()
        name_t = parser._expect(
            "IDENT", "Hiedelem-tényező után hiedelem-név jön."
        )
        return tudat_ast.BeliefFactor(
            belief_name=str(name_t.value), ellen=ellen, line=line
        )

    if type_tok.kind == "GOAL_DECL":
        parser._advance()
        name_t = parser._expect(
            "IDENT", "Cél-tényező után cél-név jön."
        )
        return tudat_ast.GoalFactor(
            goal_name=str(name_t.value), ellen=ellen, line=line
        )

    if type_tok.kind == "SZÖVEG":
        parser._advance()
        return _parse_szöveg_factor(parser, line, ellen=ellen)

    raise ParseError(
        f"Tényező-típus kell: `neurális`, `szabály`, `hiedelem`, `cél` vagy "
        f"`szöveg` — itt `{type_tok.kind}` áll.",
        line=type_tok.line,
    )


def _parse_szöveg_factor(
    parser: "Parser", line: int, *, ellen: bool = False
) -> tudat_ast.SzövegFactor:
    """`szöveg(<bemenet>[, dim=N][, érzékeny=igen/nem])` — Phase 6 / M6.3.

    A bemenet egy észlelési paraméter neve. Opcionális kulcsszó-argumentumok:
      - `dim=N`         → a beágyazás dimenziója (egész szám).
      - `érzékeny=...`  → kis/nagybetű-érzékenység (`igen`/`nem`/`igaz`/`hamis`).
    """
    parser._expect(
        "LPAREN", "Szöveg-tényező után `(<bemenet>)` kell (pl. `szöveg(diák_kódja)`)."
    )
    input_t = parser._expect(
        "IDENT", "Szöveg-tényező bemenet-neve kell (egy észlelési paraméter)."
    )
    input_name = str(input_t.value)

    dim = 64
    case_sensitive = True
    while parser._match("COMMA"):
        kulcs_t = parser._expect(
            "IDENT", "Szöveg-tényező kulcsszó-argumentum neve kell (`dim` vagy `érzékeny`)."
        )
        kulcs = str(kulcs_t.value)
        parser._expect("EQ", f"A `{kulcs}` után `=` kell.")
        if kulcs in ("dim", "dimenzió", "dimenzio"):
            num_t = parser._expect("NUMBER", "A `dim=` után egész szám kell.")
            dim = int(num_t.value)
        elif kulcs in ("érzékeny", "erzekeny", "case"):
            case_sensitive = _parse_bool_token(parser, kulcs)
        else:
            raise ParseError(
                f"Ismeretlen szöveg-tényező argumentum: `{kulcs}`. "
                f"Választható: `dim`, `érzékeny`.",
                line=kulcs_t.line,
            )
    parser._expect("RPAREN", "Hiányzik a záró `)` a szöveg-tényezőben.")

    return tudat_ast.SzövegFactor(
        input_name=input_name, dim=dim, case_sensitive=case_sensitive,
        ellen=ellen, line=line
    )


def _parse_bool_token(parser: "Parser", kulcs: str) -> bool:
    """Logikai érték parse több formában: igaz/hamis, igen/nem, 1/0.

    Megjegyzés: `nem` a lexerben NOT-ra, `igaz`/`hamis` TRUE/FALSE-ra
    tokenizálódik; `igen`/`yes` IDENT marad.
    """
    t = parser._cur()
    if t.kind == "TRUE":
        parser._advance()
        return True
    if t.kind == "FALSE":
        parser._advance()
        return False
    if t.kind == "NOT":  # a `nem` szó
        parser._advance()
        return False
    if t.kind == "NUMBER":
        parser._advance()
        return float(t.value) != 0.0
    if t.kind == "IDENT":
        szó = str(t.value).lower()
        if szó in ("igen", "yes", "on", "be"):
            parser._advance()
            return True
        if szó in ("nem", "no", "off", "ki"):
            parser._advance()
            return False
    raise ParseError(
        f"A `{kulcs}=` után logikai érték kell (`igen`/`nem`/`igaz`/`hamis`) "
        f"— itt `{t.kind}` áll.",
        line=t.line,
    )

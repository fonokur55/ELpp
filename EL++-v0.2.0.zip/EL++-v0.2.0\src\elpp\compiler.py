"""AST → bytecode fordító."""

from __future__ import annotations

from elpp import ast
from elpp.bytecode import Chunk, Op


class Compiler:
    def __init__(self) -> None:
        self.chunk = Chunk()

    def compile(self, program: ast.Program) -> Chunk:
        for stmt in program.statements:
            self._compile_stmt(stmt)
        self.chunk.emit(Op.HALT)
        return self.chunk

    def _compile_stmt(self, stmt: ast.Stmt) -> None:
        if isinstance(stmt, ast.Let):
            self._compile_expr(stmt.value)
            self.chunk.emit(Op.STORE, stmt.name)
            return
        if isinstance(stmt, ast.Print):
            for e in stmt.values:
                self._compile_expr(e)
            self.chunk.emit(Op.PRINT, len(stmt.values))
            return
        if isinstance(stmt, ast.If):
            self._compile_expr(stmt.condition)
            jmp_false = self.chunk.emit(Op.JMP_IF_FALSE, 0)
            for s in stmt.then_body:
                self._compile_stmt(s)
            jmp_end = self.chunk.emit(Op.JMP, 0)
            self.chunk.code[jmp_false].arg = len(self.chunk.code)
            if stmt.else_body:
                for s in stmt.else_body:
                    self._compile_stmt(s)
            self.chunk.code[jmp_end].arg = len(self.chunk.code)
            return
        if isinstance(stmt, ast.While):
            loop_start = len(self.chunk.code)
            self._compile_expr(stmt.condition)
            jmp_exit = self.chunk.emit(Op.JMP_IF_FALSE, 0)
            for s in stmt.body:
                self._compile_stmt(s)
            self.chunk.emit(Op.JMP, loop_start)
            self.chunk.code[jmp_exit].arg = len(self.chunk.code)
            return
        if isinstance(stmt, ast.Return):
            if stmt.value:
                self._compile_expr(stmt.value)
            self.chunk.emit(Op.RETURN)

    def _compile_expr(self, expr: ast.Expr) -> None:
        if isinstance(expr, ast.Number):
            idx = self.chunk.add_constant(expr.value)
            self.chunk.emit(Op.CONST, idx)
            return
        if isinstance(expr, ast.String):
            idx = self.chunk.add_constant(expr.value)
            self.chunk.emit(Op.CONST, idx)
            return
        if isinstance(expr, ast.Bool):
            idx = self.chunk.add_constant(expr.value)
            self.chunk.emit(Op.CONST, idx)
            return
        if isinstance(expr, ast.Var):
            self.chunk.emit(Op.LOAD, expr.name)
            return
        if isinstance(expr, ast.Unary):
            self._compile_expr(expr.operand)
            if expr.op == "NOT":
                self.chunk.emit(Op.NOT)
            elif expr.op == "MINUS":
                self.chunk.emit(Op.NEG)
            return
        if isinstance(expr, ast.Binary):
            self._compile_expr(expr.left)
            self._compile_expr(expr.right)
            op_map = {
                "PLUS": Op.ADD, "MINUS": Op.SUB, "STAR": Op.MUL, "SLASH": Op.DIV,
                "EQ": Op.EQ, "NE": Op.NE, "LT": Op.LT, "GT": Op.GT,
                "LE": Op.LE, "GE": Op.GE, "AND": Op.AND, "OR": Op.OR,
            }
            if expr.op in op_map:
                self.chunk.emit(op_map[expr.op])
            return
        if isinstance(expr, ast.Call):
            for a in expr.args:
                self._compile_expr(a)
            self.chunk.emit(Op.CALL, (expr.name, len(expr.args)))


def compile_program(program: ast.Program) -> Chunk:
    return Compiler().compile(program)

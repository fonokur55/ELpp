#!/usr/bin/env python3
"""KódTanár SZAKÉRTŐ — interaktív CLI (Phase 8 / M8.4.d).

A „merged" KódTanár: bemásolod a Python-kódod (akár nagyot) + egy üzenetet, és
KONKRÉT, grounded, empatikus választ kapsz — megnevezi, MELYIK SORBAN MI a baj,
és sosem hazudik. A nehéz munkát az AST végzi (determinisztikus, nincs
kontextus-limit → nagy fájlt is elbír), a keretet a hiedelmek (empátia/szint).

Indítás:
    python scripts/kodtanar_szakerto_chat.py
"""

from __future__ import annotations

import sys
from pathlib import Path

if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    except (AttributeError, OSError):
        pass

ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "examples" / "ai"))

from elpp.parser import parse  # noqa: E402
from elpp.tudat import TudatRuntime  # noqa: E402
from elpp.tudat.szoveg import Beszélgetés  # noqa: E402

import kodtanar_szöveg_adat as kd  # noqa: E402

MODELL_PATH = ROOT / "examples" / "ai" / "kodtanar_szakerto.elpp"
FÓKUSZ = ["frusztrált", "kezdő"]
EPOCHOK = 100
TANULÁSI_RÁTA = 0.5


def betölt_és_tanít(*, seed: int = 1, epochok: int = EPOCHOK) -> TudatRuntime:
    """A szakértő KódTanár betanítása a hibrid szöveg-adatból."""
    rt = TudatRuntime(parse(MODELL_PATH.read_text(encoding="utf-8")).statements[0], seed=seed)
    rt.fit(kd.tanító_adat(seed=42), célok=kd.CÉLOK, epochok=epochok,
           tanulási_ráta=TANULÁSI_RÁTA)
    return rt


def beszélgetés_indít(rt: TudatRuntime, *, seed: int | None = None) -> Beszélgetés:
    """Beszélgetés a kód-diagnózisra hangolva (keret + konkrét AST-diagnózis)."""
    return Beszélgetés(
        rt, fókusz_hiedelmek=FÓKUSZ, üzenet_mező="diák_üzenete",
        kód_mező="diák_kódja", seed=seed,
    )


def fej(címe: str) -> None:
    sáv = "═" * (len(címe) + 4)
    print(f"\n╔{sáv}╗\n║  {címe}  ║\n╚{sáv}╝")


def _olvass_több_sort(prompt: str) -> str:
    print(prompt + " (üres sor = vége):")
    sorok: list[str] = []
    while True:
        try:
            sor = input("    ")
        except EOFError:
            break
        if sor == "":
            break
        sorok.append(sor)
    return "\n".join(sorok)


def interaktív(b: Beszélgetés) -> None:
    fej("KódTanár SZAKÉRTŐ — másold be a kódod, segítek")
    print("(Kérdezd: „miért nem megy?” · kilépés: üres kód + üres üzenet)")
    while True:
        kód = _olvass_több_sort("\nA kódod")
        üzenet = input("Az üzeneted: ").strip()
        if not kód.strip() and not üzenet:
            print("\nViszlát! 👋  Jó kódolást!")
            return
        válasz = b.fordul(diák_kódja=kód, diák_üzenete=üzenet)
        print(f"\nKódTanár: {válasz or '(erről nincs határozott véleményem)'}")


def main() -> None:
    fej("KódTanár SZAKÉRTŐ — Phase 8")
    print("• Tanulás a hibrid adatból...")
    rt = betölt_és_tanít()
    print("  ✓ kész. Másold be a kódod (akár nagyot is), és segítek!")
    interaktív(beszélgetés_indít(rt, seed=0))


if __name__ == "__main__":
    main()

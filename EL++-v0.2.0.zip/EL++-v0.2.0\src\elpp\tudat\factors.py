"""Tényező-rendszer: 4 csatornás bizonyíték-aggregálás (Phase 1 / M2).

A `tudat` paradigma magja: minden `hiedelem` több, expliciten látható
forrásból nyer evidence-et. A 4 alaptípus:

  • neurális  — tenzor/számítás-alapú evidence (W·x + b stílus)
  • szabály   — logikai if-then evidence
  • hiedelem  — másik hiedelem értékének átfolyatása
  • cél       — meta-motiváció (a hiedelem segít elérni egy célt)

**Architektúra (Phase 1 / 2. döntés):** EGY HELYEN regisztrált, bővíthető.
Új tényező-típus felvétele = új `FactorTypeRegistration` + `register_factor_type()`.
A felhasználói szintű új-típus-definiálás (`tényező-típus_definiál ...`)
Phase 3+ téma — most csak a belső architektúra rugalmas.

Minden tényező értéke [0, 1] közé esik (clip-pel kikényszerítve).
Az aggregálás Bayes-szerű (noisy-OR): `1 - ∏(1 - p_i)`.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Callable, Union

from elpp import ast as base_ast
from elpp.runtime_values import ElTensor
from elpp.tudat import ast as tudat_ast
from elpp.tudat.szoveg import Tokenizer
from elpp.tudat.szoveg.kodelemzo import KódTények, elemez

if TYPE_CHECKING:
    from elpp.tudat.runtime import TudatRuntime

# M4.1: az evaluátor értékei lehetnek skalárok vagy tenzorok.
# M6.3: szöveg-bemenetek miatt string is lehet (csak hosszúság/tartalmaz kontextusban).
EvalValue = Union[float, ElTensor, str]

# M6.3: a `hosszúság()` builtin egy közös, case-sensitive tokenizer-t használ
# (token-számot ad — ez illik a nyelvi-modell szemlélethez).
_HOSSZÚSÁG_TOKENIZER = Tokenizer(case_sensitive=True)


# ─────────────────────────────────────────────────────────────────────────────
# Registry
# ─────────────────────────────────────────────────────────────────────────────


FactorEvaluator = Callable[[Any, "TudatRuntime"], float]
FactorDescriber = Callable[[Any, float], str]


@dataclass(frozen=True)
class FactorTypeRegistration:
    """Egy tényező-típus regisztrációja: név, AST-osztály, evaluátor, leíró."""

    name: str
    ast_type: type
    evaluator: FactorEvaluator
    describer: FactorDescriber


_REGISTRY: list[FactorTypeRegistration] = []


def register_factor_type(reg: FactorTypeRegistration) -> None:
    """Új tényező-típus felvétele a regiszterbe.

    Idempotens: ugyanaz az ast_type csak egyszer kerülhet be.
    """
    for existing in _REGISTRY:
        if existing.ast_type is reg.ast_type:
            return  # már regisztrált
    _REGISTRY.append(reg)


def all_factor_types() -> list[FactorTypeRegistration]:
    """A bejegyzett tényező-típusok listája (sorrend = regisztráció)."""
    return list(_REGISTRY)


def lookup_factor_type(factor: Any) -> FactorTypeRegistration:
    """Megtalálja a tényező-típushoz tartozó regisztrációt."""
    for reg in _REGISTRY:
        if isinstance(factor, reg.ast_type):
            return reg
    raise TypeError(
        f"Ismeretlen tényező-típus: `{type(factor).__name__}`. "
        f"Lehet, hogy elfelejtetted regisztrálni?"
    )


def evaluate_factor(factor: Any, runtime: "TudatRuntime") -> float:
    """Egy tényező értékének kiszámolása a runtime kontextusban."""
    reg = lookup_factor_type(factor)
    raw = reg.evaluator(factor, runtime)
    # Bizonyosság minden tényezőnél [0, 1] közé clippelve.
    return _clip01(raw)


def describe_factor(factor: Any, value: float) -> str:
    """Ember-olvasható összefoglaló egy tényezőről (reflexióhoz)."""
    reg = lookup_factor_type(factor)
    return reg.describer(factor, value)


def _clip01(x: float) -> float:
    return max(0.0, min(1.0, float(x)))


# ─────────────────────────────────────────────────────────────────────────────
# Aggregálás — egyetlen stratégia M2-ben (Bayes-szerű noisy-OR)
# ─────────────────────────────────────────────────────────────────────────────


def aggregate(values: list[float]) -> float:
    """Több tényező-érték kombinálása egy hiedelem confidence-évé.

    Stratégia: noisy-OR (független evidence-források). Minden új pozitív
    evidence növeli a confidence-et, 1-et soha nem ér el véges sok véges
    erősségű forrással. Üres lista → 0.5 (semmi tudás).
    """
    if not values:
        return 0.5
    accum = 0.0
    for v in values:
        v = _clip01(v)
        accum = 1.0 - (1.0 - accum) * (1.0 - v)
    return accum


# ─────────────────────────────────────────────────────────────────────────────
# Alap-kifejezés evaluátor (M2 minimum)
# ─────────────────────────────────────────────────────────────────────────────


def _eval_expr(expr: base_ast.Expr, runtime: "TudatRuntime") -> EvalValue:
    """Egy kifejezés evaluálása a tudat-runtime kontextusban.

    Visszatérés: float VAGY ElTensor (M4.1).
    M2: skalár-szintű (számok, változók, bin/un. műveletek).
    M4.1: lista-literál → tenzor; broadcasting; `pont`/`dot`/`matmul` hívás.
    """
    if isinstance(expr, base_ast.Number):
        return float(expr.value)

    if isinstance(expr, base_ast.Bool):
        return 1.0 if expr.value else 0.0

    if isinstance(expr, base_ast.String):
        # M6.3: string-literál — a `tartalmaz(szöveg, "minta")` builtinhez.
        return expr.value

    if isinstance(expr, base_ast.Var):
        name = expr.name
        # Keresési sorrend: weights → context → beliefs → goals
        if name in runtime.weights:
            w = runtime.weights[name]
            # M4.1: tenzor-súly esetén a tenzor objektumot adjuk vissza.
            return w if isinstance(w, ElTensor) else float(w)
        if name in runtime.context:
            return runtime.context[name]
        if name in runtime.beliefs:
            return runtime.beliefs[name].confidence
        if name in runtime.goals:
            return runtime.goals[name]
        raise NameError(
            f"Ismeretlen név a tudat-kifejezésben: `{name}`. "
            f"Súlynak, bemenetnek, hiedelemnek vagy célnak kell lennie."
        )

    if isinstance(expr, base_ast.ListLit):
        # M4.1: lista-literál → tenzor. Csak skalárokat vagy 1D-tenzorokat
        # fogadunk el; minden mást barátságos hibával jelzünk.
        elements = [_eval_expr(e, runtime) for e in expr.elements]
        if not elements:
            return ElTensor([], [0])
        # Eset 1: minden skalár → 1D vektor
        if all(isinstance(e, (int, float)) for e in elements):
            return ElTensor([float(e) for e in elements], [len(elements)])
        # Eset 2: minden 1D tenzor azonos hosszal → 2D mátrix
        if all(isinstance(e, ElTensor) and len(e.shape) == 1 for e in elements):
            inner = len(elements[0].data)
            if not all(len(e.data) == inner for e in elements):
                raise ValueError(
                    "Lista-literál belsejében a 1D tenzorok hossza nem egyezik."
                )
            data: list[float] = []
            for e in elements:
                data.extend(e.data)
            return ElTensor(data, [len(elements), inner])
        raise TypeError(
            "Lista-literál csak skalárokból (vektor) vagy azonos hosszú "
            "1D tenzorokból (mátrix) építhető."
        )

    if isinstance(expr, base_ast.Call):
        name = expr.name
        args = [_eval_expr(a, runtime) for a in expr.args]
        # M6.3: szöveg-builtinök a szabály-tényezőkhöz (D5).
        if name in ("hosszúság", "hosszusag", "length", "len"):
            if len(args) != 1:
                raise TypeError(f"`{name}` 1 argumentumot vár.")
            return float(len(_HOSSZÚSÁG_TOKENIZER.tokenizál(_as_text(args[0]))))
        if name in ("tartalmaz", "contains"):
            if len(args) != 2:
                raise TypeError(f"`{name}` 2 argumentumot vár (szöveg, minta).")
            szöveg = _as_text(args[0])
            minta = _as_text(args[1])
            return 1.0 if minta in szöveg else 0.0
        # M8.1.b: ast_* — valós kód-szerkezeti tények (a KódElemző tölti).
        if name.startswith("ast_"):
            if len(args) != 1:
                raise TypeError(f"`{name}` 1 argumentumot vár (a kódot).")
            return _ast_builtin(name, _as_text(args[0]))
        # M4.1: pont / dot / matmul — mátrix/vektor-szorzás
        if name in ("pont", "dot", "matmul"):
            if len(args) != 2:
                raise TypeError(
                    f"`{name}` 2 argumentumot vár (kapott {len(args)})."
                )
            return _matmul_general(args[0], args[1])
        # M5.4: aktivációs függvények — skalárra és tenzorra elementwise
        if name == "sigmoid":
            if len(args) != 1:
                raise TypeError(f"`sigmoid` 1 argumentumot vár.")
            return _apply_unary(args[0], _sigmoid_op)
        if name == "tanh":
            if len(args) != 1:
                raise TypeError(f"`tanh` 1 argumentumot vár.")
            return _apply_unary(args[0], math.tanh)
        if name == "relu":
            if len(args) != 1:
                raise TypeError(f"`relu` 1 argumentumot vár.")
            return _apply_unary(args[0], _relu_op)
        raise NameError(
            f"Ismeretlen függvény a tudat-kifejezésben: `{name}`."
        )

    if isinstance(expr, base_ast.Binary):
        left = _eval_expr(expr.left, runtime)
        right = _eval_expr(expr.right, runtime)
        op = expr.op
        # M4.1: broadcasting +, -, *, /
        if op in ("PLUS", "MINUS", "STAR", "SLASH"):
            return _binary_arith(left, right, op)
        # Skalár-szintű összehasonlítások és logika
        l = _as_scalar(left)
        r = _as_scalar(right)
        if op == "GT":
            return 1.0 if l > r else 0.0
        if op == "LT":
            return 1.0 if l < r else 0.0
        if op == "GE":
            return 1.0 if l >= r else 0.0
        if op == "LE":
            return 1.0 if l <= r else 0.0
        if op == "EQ":
            return 1.0 if l == r else 0.0
        if op == "NE":
            return 1.0 if l != r else 0.0
        if op == "AND":
            return min(l, r)
        if op == "OR":
            return max(l, r)
        raise ValueError(f"Nem támogatott operátor: {op}")

    if isinstance(expr, base_ast.Unary):
        v = _eval_expr(expr.operand, runtime)
        if expr.op == "NOT":
            return 1.0 - _as_scalar(v)
        if expr.op == "MINUS":
            if isinstance(v, ElTensor):
                return ElTensor([-x for x in v.data], list(v.shape))
            return -float(v)

    raise TypeError(
        f"Nem támogatott kifejezés tudat-kontextusban: "
        f"`{type(expr).__name__}`."
    )


# ─────────────────────────────────────────────────────────────────────────────
# Tenzor-segédfüggvények (M4.1)
# ─────────────────────────────────────────────────────────────────────────────


def _sigmoid_op(x: float) -> float:
    """Numerikusan stabil sigmoid."""
    if x >= 500:
        return 1.0
    if x <= -500:
        return 0.0
    return 1.0 / (1.0 + math.exp(-x))


def _relu_op(x: float) -> float:
    return max(0.0, x)


def _apply_unary(v: EvalValue, fn: Callable[[float], float]) -> EvalValue:
    """Skalár-függvényt alkalmazza skalárra vagy elementwise tenzorra."""
    if isinstance(v, ElTensor):
        return ElTensor([fn(x) for x in v.data], list(v.shape))
    return fn(float(v))


# M8.1.b: ast_* builtinek → KódTények-mező leképezés. ÚJ builtin = 1 sor ide.
_AST_BUILTINEK: dict[str, Callable[[KódTények], float]] = {
    "ast_szintaktikailag_hibás": lambda t: 1.0 if t.szintaktikailag_hibás else 0.0,
    "ast_sorok": lambda t: float(t.sorok),
    "ast_függvények": lambda t: float(t.függvények_száma),
    "ast_van_függvény": lambda t: 1.0 if t.függvények_száma > 0 else 0.0,
    "ast_max_függvény_hossz": lambda t: float(t.max_függvény_hossz),
    "ast_mélység": lambda t: float(t.max_mélység),
    "ast_ciklusok": lambda t: float(t.ciklusok_száma),
    "ast_elágazások": lambda t: float(t.elágazások_száma),
    "ast_egybetűs_nevek": lambda t: float(t.egybetűs_nevek),
    "ast_rövid_nevek": lambda t: float(t.rövid_nevek),
    "ast_ismételt_értékadás": lambda t: float(t.max_ismételt_értékadás),
}


def _ast_builtin(name: str, kód: str) -> float:
    """Egy `ast_*` builtin kiértékelése a kód MÉRT tényeiből (grounded)."""
    fn = _AST_BUILTINEK.get(name)
    if fn is None:
        elérhető = ", ".join(sorted(_AST_BUILTINEK))
        raise NameError(
            f"Ismeretlen `ast_` builtin: `{name}`. Elérhető: {elérhető}."
        )
    return fn(elemez(kód))


def _as_text(v: EvalValue) -> str:
    """Szöveggé konvertál a `hosszúság`/`tartalmaz` builtinekhez.

    String → változatlanul; minden más barátságos hibát ad (a szöveg-builtinek
    csak szöveg-bemeneten értelmesek).
    """
    if isinstance(v, str):
        return v
    raise TypeError(
        "Szöveg-builtin (`hosszúság`/`tartalmaz`) szöveg-bemenetet vár, "
        f"de `{type(v).__name__}` érkezett. Egy észlelési szöveg-paramétert "
        f"adj át (pl. `hosszúság(diák_kódja)`)."
    )


def _as_scalar(v: EvalValue) -> float:
    """Skalárrá konvertál — 1-elemű tenzor OK, multi-elem hiba."""
    if isinstance(v, ElTensor):
        if len(v.data) == 1:
            return float(v.data[0])
        raise TypeError(
            f"Skalárt vártam, kaptam {v.shape} alakú tenzort. "
            f"Talán `pont(...)` szükséges?"
        )
    return float(v)


def _binary_arith(
    left: EvalValue, right: EvalValue, op: str
) -> EvalValue:
    """Aritmetikai bináris művelet broadcasting-gal.

    - skalár ↔ skalár → skalár
    - skalár ↔ tenzor / tenzor ↔ skalár → tenzor (broadcasting)
    - tenzor ↔ tenzor → elementwise (azonos shape kötelező)
    """
    def _op(a: float, b: float) -> float:
        if op == "PLUS":
            return a + b
        if op == "MINUS":
            return a - b
        if op == "STAR":
            return a * b
        if op == "SLASH":
            return a / b if b != 0 else 0.0
        raise ValueError(f"Ismeretlen aritmetikai op: {op}")

    l_is_t = isinstance(left, ElTensor)
    r_is_t = isinstance(right, ElTensor)

    if not l_is_t and not r_is_t:
        return _op(float(left), float(right))

    if l_is_t and not r_is_t:
        s = float(right)
        return ElTensor([_op(x, s) for x in left.data], list(left.shape))

    if not l_is_t and r_is_t:
        s = float(left)
        return ElTensor([_op(s, x) for x in right.data], list(right.shape))

    # Mindkettő tenzor — azonos shape kötelező.
    if left.shape != right.shape:
        raise ValueError(
            f"Tenzor-tenzor művelet ({op}): a shape-ek nem egyeznek "
            f"({left.shape} vs {right.shape}). Broadcasting csak skalár-tenzor."
        )
    return ElTensor(
        [_op(x, y) for x, y in zip(left.data, right.data)],
        list(left.shape),
    )


def _as_tensor(v: EvalValue) -> ElTensor:
    """Tenzorrá konvertál — skalár → 1-elemű."""
    if isinstance(v, ElTensor):
        return v
    return ElTensor([float(v)], [1])


def _matmul_general(a: EvalValue, b: EvalValue) -> EvalValue:
    """Általános `pont` művelet — 4 eset:
    - 1D · 1D → skalár (dot product)
    - 2D · 1D → 1D (matrix-vector)
    - 1D · 2D → 1D (row-vector × matrix)
    - 2D · 2D → 2D (matmul)
    """
    a = _as_tensor(a)
    b = _as_tensor(b)
    a_dim = len(a.shape)
    b_dim = len(b.shape)

    if a_dim == 1 and b_dim == 1:
        if a.shape[0] != b.shape[0]:
            raise ValueError(
                f"pont(1D, 1D): hosszak nem egyeznek ({a.shape[0]} vs {b.shape[0]})."
            )
        return sum(x * y for x, y in zip(a.data, b.data))

    if a_dim == 2 and b_dim == 1:
        rows, cols = a.shape
        if cols != b.shape[0]:
            raise ValueError(
                f"pont(2D[{rows},{cols}], 1D[{b.shape[0]}]): inner dim mismatch."
            )
        result = []
        for i in range(rows):
            s = sum(a.data[i * cols + j] * b.data[j] for j in range(cols))
            result.append(s)
        return ElTensor(result, [rows])

    if a_dim == 1 and b_dim == 2:
        n = a.shape[0]
        b_rows, b_cols = b.shape
        if n != b_rows:
            raise ValueError(
                f"pont(1D[{n}], 2D[{b_rows},{b_cols}]): inner dim mismatch."
            )
        result = []
        for j in range(b_cols):
            s = sum(a.data[i] * b.data[i * b_cols + j] for i in range(n))
            result.append(s)
        return ElTensor(result, [b_cols])

    if a_dim == 2 and b_dim == 2:
        a_rows, a_cols = a.shape
        b_rows, b_cols = b.shape
        if a_cols != b_rows:
            raise ValueError(
                f"pont(2D[{a_rows},{a_cols}], 2D[{b_rows},{b_cols}]): "
                f"inner dim mismatch."
            )
        out = []
        for i in range(a_rows):
            for j in range(b_cols):
                s = sum(a.data[i * a_cols + k] * b.data[k * b_cols + j]
                        for k in range(a_cols))
                out.append(s)
        return ElTensor(out, [a_rows, b_cols])

    raise ValueError(
        f"`pont`: nem támogatott dimenziók ({a.shape} × {b.shape}). "
        f"Csak 1D/2D operandusok."
    )


# ─────────────────────────────────────────────────────────────────────────────
# Evaluátorok és leírók a 4 alaptípusra
# ─────────────────────────────────────────────────────────────────────────────


def _eval_neural(factor: tudat_ast.NeuralFactor, runtime: "TudatRuntime") -> float:
    result = _eval_expr(factor.expr, runtime)
    # M4.1: a neurális tényező SKALÁRT vár. 1-elemű tenzor kicsomagolható,
    # multi-elem tenzor barátságos hibát ad.
    if isinstance(result, ElTensor):
        if len(result.data) != 1:
            raise ValueError(
                f"A neurális tényező kifejezésének SKALÁRT kell adnia, "
                f"kapott {result.shape} alakú tenzort. "
                f"Talán `pont(W, [...])` kell a skalárra-csökkentéshez?"
            )
        return float(result.data[0])
    return float(result)


def _describe_neural(factor: tudat_ast.NeuralFactor, value: float) -> str:
    return f"neurális → {value:.3f}"


def _eval_rule(factor: tudat_ast.RuleFactor, runtime: "TudatRuntime") -> float:
    cond_value = _eval_expr(factor.condition, runtime)
    fires = cond_value > 0.5
    if not fires:
        return 0.0
    base = _eval_expr(factor.confidence, runtime)
    # M5: tanult rule_weight szorzó (default 1.0 = változatlan)
    learned = runtime.get_factor_param(factor, "rule_weight", default=1.0)
    return base * learned


def _describe_rule(factor: tudat_ast.RuleFactor, value: float) -> str:
    state = "tüzelt" if value > 0 else "nem tüzelt"
    return f"szabály ({state}) → {value:.3f}"


def _eval_belief(factor: tudat_ast.BeliefFactor, runtime: "TudatRuntime") -> float:
    if factor.belief_name not in runtime.beliefs:
        raise NameError(
            f"Hivatkozott hiedelem nem létezik: `{factor.belief_name}`."
        )
    return runtime.beliefs[factor.belief_name].confidence


def _describe_belief(factor: tudat_ast.BeliefFactor, value: float) -> str:
    return f"hiedelem `{factor.belief_name}` → {value:.3f}"


# A cél-tényező M2-ben placeholder volt (fix 0.1 × aktiváció).
# M5 ÓTA tanult: a goal_weight default 0.1, de a tanulás módosíthatja.
GOAL_DEFAULT_WEIGHT = 0.1


def _eval_goal(factor: tudat_ast.GoalFactor, runtime: "TudatRuntime") -> float:
    if factor.goal_name not in runtime.goals:
        raise NameError(
            f"Hivatkozott cél nem létezik: `{factor.goal_name}`."
        )
    activation = runtime.goals[factor.goal_name]
    # M5: tanult goal_weight (default 0.1 = M2 placeholder volt)
    learned = runtime.get_factor_param(
        factor, "goal_weight", default=GOAL_DEFAULT_WEIGHT
    )
    return activation * learned


def _describe_goal(factor: tudat_ast.GoalFactor, value: float) -> str:
    return f"cél `{factor.goal_name}` súlyozza → {value:.3f}"


# ── Szöveg-tényező (Phase 6 / M6.3) ──────────────────────────────────────────


def _eval_szöveg(factor: tudat_ast.SzövegFactor, runtime: "TudatRuntime") -> float:
    """A szöveg-tényező értéke: a runtime kódolja a context-beli szöveget.

    A tokenizálás + beágyazás + pooling + lineáris réteg + sigmoid a
    runtime-ban él (tanult állapot). Itt csak delegálunk.
    """
    return runtime._text_factor_value(factor)


def _describe_szöveg(factor: tudat_ast.SzövegFactor, value: float) -> str:
    return f"szöveg(`{factor.input_name}`) → {value:.3f}"


# ─────────────────────────────────────────────────────────────────────────────
# Alap-regisztráció — modul-betöltéskor egyszer
# ─────────────────────────────────────────────────────────────────────────────

# A 4 alap-típus felvétele. ÚJ TÍPUS FELVÉTELE = új register_factor_type() hívás
# itt vagy bárhol máshol. Egy helyen, nem szétszórva (lásd Phase 1 / 2. döntés).
register_factor_type(
    FactorTypeRegistration(
        name="neurális",
        ast_type=tudat_ast.NeuralFactor,
        evaluator=_eval_neural,
        describer=_describe_neural,
    )
)
register_factor_type(
    FactorTypeRegistration(
        name="szabály",
        ast_type=tudat_ast.RuleFactor,
        evaluator=_eval_rule,
        describer=_describe_rule,
    )
)
register_factor_type(
    FactorTypeRegistration(
        name="hiedelem",
        ast_type=tudat_ast.BeliefFactor,
        evaluator=_eval_belief,
        describer=_describe_belief,
    )
)
register_factor_type(
    FactorTypeRegistration(
        name="cél",
        ast_type=tudat_ast.GoalFactor,
        evaluator=_eval_goal,
        describer=_describe_goal,
    )
)
# Phase 6 / M6.3: az 5. tényező-típus — egyenrangú a 4 alaptípussal.
register_factor_type(
    FactorTypeRegistration(
        name="szöveg",
        ast_type=tudat_ast.SzövegFactor,
        evaluator=_eval_szöveg,
        describer=_describe_szöveg,
    )
)

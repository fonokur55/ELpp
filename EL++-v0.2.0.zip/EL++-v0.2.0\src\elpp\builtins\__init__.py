"""Beépített függvények."""

from elpp.builtins.tensor import TENSOR_BUILTINS

__all__ = ["TENSOR_BUILTINS"]

"""Belief-horgonyzott (grounded) generálás — Phase 8 / M8.3.c.

A tudat hiedelem-állapota VEZÉRLI a tanult generátort: a hiedelmek confidence-ei
egy KONDÍCIÓ-VEKTORrá állnak össze, és a `NyelvModell` erre feltételezve termel.
Így a modell azt mondja ki, amit a tudat tényleg hisz → grounded, nem hallucinál.

**Self-bootstrap tanítás:** `(hiedelem-állapot → grounded szöveg)` példákból
teacher-forcing tanító-hármasokat `(kontextus, kondíció, cél-token)` készítünk
(közös kondícióval mondatonként), és ezeken tanítjuk a kondicionált modellt. A
grounded szövegek a Phase 7 paletta szellemében készülnek → a horgonyzás öröklődik.

**A grounding lényege:** ugyanabból a kezdő (padding) kontextusból CSAK a kondíció
különbözik — ha a modell a megfelelő szöveget adja minden állapotra, akkor a
hiedelem-állapot bizonyítottan vezérli a beszédet.
"""

from __future__ import annotations

import random

from elpp.tudat.szoveg.generalas import Generáló, HiedelemPillanat
from elpp.tudat.szoveg.nyelvmodell import NyelvModell
from elpp.tudat.szoveg.tokenizer import PADDING_INDEX, Szótár, Tokenizer


def kondíció_vektor(
    állapot: dict[str, float], hiedelmek: list[str]
) -> list[float]:
    """Hiedelem-állapot → fix sorrendű kondíció-vektor.

    `hiedelmek` rögzíti a sorrendet (mindig ugyanaz a vektor-jelentés). A hiányzó
    hiedelem 0.0. Egy élő tudatból: `{b: rt.compute_belief(b) for b in hiedelmek}`.
    """
    return [float(állapot.get(b, 0.0)) for b in hiedelmek]


def készíts_kondicionált_adatot(
    példák: list[tuple[list[float], str]],
    *,
    ablak: int,
    min_gyakoriság: int = 1,
    case_sensitive: bool = False,
) -> tuple[Szótár, list[tuple[list[int], list[float], int]], Tokenizer]:
    """`(kondíció, szöveg)` példákból szótár + teacher-forcing tanító-hármasok.

    Minden mondat végére egy lezáró `<padding>` cél kerül (a modell megtanulja,
    hol van a megnyilatkozás vége → a generálás `leállító`-val megáll).

    Visszatérés: (szótár, hármasok, tokenizer).
    """
    tok = Tokenizer(case_sensitive=case_sensitive, figyelmeztetési_küszöb=10**9)
    dokumentumok = [tok.tokenizál(szöveg) for _, szöveg in példák]
    szótár = Szótár(min_gyakoriság=min_gyakoriság).illeszt(dokumentumok)

    hármasok: list[tuple[list[int], list[float], int]] = []
    for (kondíció, _), tokenek in zip(példák, dokumentumok):
        idx = szótár.kódol(tokenek)
        puffer = [PADDING_INDEX] * ablak
        for cél in idx:
            hármasok.append((list(puffer), list(kondíció), cél))
            puffer = puffer[1:] + [cél]
        # Lezárás: a mondat után <padding> a cél (megnyilatkozás vége).
        hármasok.append((list(puffer), list(kondíció), PADDING_INDEX))
    return szótár, hármasok, tok


def tanítsd_kondicionáltan(
    modell: NyelvModell,
    hármasok: list[tuple[list[int], list[float], int]],
    *,
    epochok: int = 1,
    tanulási_ráta: float = 0.1,
    rng: random.Random | None = None,
    napló_lépésenként: int = 500,
) -> list[tuple[int, float]]:
    """A kondicionált modellt tanítja a `(kontextus, kondíció, cél)` hármasokon.

    Epochonként keveri a hármasokat (reprodukálható a saját RNG-vel).
    Visszatérés: tanulási görbe `(lépés, átlag_veszteség)`.
    """
    rng = rng or random.Random(0)
    napló: list[tuple[int, float]] = []
    lépés = 0
    futó = 0.0
    db = 0
    for _ in range(epochok):
        sorrend = list(hármasok)
        rng.shuffle(sorrend)
        for kontextus, kondíció, cél in sorrend:
            v = modell.tanulj_lépés(kontextus, kondíció, cél, tanulási_ráta)
            futó += v
            db += 1
            lépés += 1
            if lépés % napló_lépésenként == 0:
                napló.append((lépés, futó / db))
                futó = 0.0
                db = 0
    if db:
        napló.append((lépés, futó / db))
    return napló


def bootstrap_állapotokból(
    generáló: Generáló,
    hiedelmek: list[str],
    állapotok: list[dict[str, float]],
    *,
    ismétlés: int = 8,
    seed: int = 0,
) -> list[tuple[list[float], str]]:
    """Self-bootstrap: a Phase 7 KOMPOZÍCIÓS generáló grounded mondataiból
    `(kondíció, szöveg)` tanító-példák.

    Minden hiedelem-állapotra a kompozíciós generáló több (seedelt) grounded
    mondatot ad — ezek lesznek a tanult generátor tanító-jelei. Így a tanult
    modell a grounded mintát örökli (sosem hallucinál), de tanulttá válik.
    """
    példák: list[tuple[list[float], str]] = []
    for állapot in állapotok:
        kondíció = kondíció_vektor(állapot, hiedelmek)
        fókusz_b = max(hiedelmek, key=lambda b: állapot.get(b, 0.0))
        pillanatok = [
            HiedelemPillanat(
                név=b, confidence=állapot.get(b, 0.0), fókusz=(b == fókusz_b)
            )
            for b in hiedelmek
        ]
        for r in range(ismétlés):
            szöveg = generáló.generál(pillanatok, seed=seed + r)
            if szöveg:
                példák.append((kondíció, szöveg))
    return példák


def építs_tanult_generátort(
    generáló: Generáló,
    hiedelmek: list[str],
    állapotok: list[dict[str, float]],
    *,
    ablak: int = 2,
    dim: int = 24,
    rejtett: int = 48,
    epochok: int = 400,
    tanulási_ráta: float = 0.15,
    ismétlés: int = 8,
    seed: int = 0,
) -> tuple[NyelvModell, Szótár]:
    """Tanult, belief-kondicionált generátort épít a kompozíciós palettából.

    1. Self-bootstrap tanító-példák (állapot → grounded szöveg).
    2. Teacher-forcing hármasok + szótár.
    3. Kondicionált NyelvModell betanítása.
    Visszatérés: (modell, szótár) — bekötve a `Beszélgetés`-be.
    """
    példák = bootstrap_állapotokból(
        generáló, hiedelmek, állapotok, ismétlés=ismétlés, seed=seed
    )
    if not példák:
        raise ValueError(
            "A bootstrap nem adott egyetlen példát sem — van kifejezés-paletta?"
        )
    szótár, hármasok, _ = készíts_kondicionált_adatot(példák, ablak=ablak)
    modell = NyelvModell(
        szótár.méret, ablak=ablak, dim=dim, rejtett=rejtett,
        kondíció_méret=len(hiedelmek), seed=seed,
    )
    tanítsd_kondicionáltan(
        modell, hármasok, epochok=epochok, tanulási_ráta=tanulási_ráta,
        rng=random.Random(seed),
    )
    return modell, szótár


def generál_állapotból(
    modell: NyelvModell,
    szótár: Szótár,
    kondíció: list[float],
    *,
    hossz: int = 20,
    hőmérséklet: float = 0.5,
    seed: int | None = None,
) -> str:
    """Adott hiedelem-kondícióból grounded szöveget generál (a megnyilatkozás
    végén — <padding> — megáll)."""
    ki = modell.generál(
        [PADDING_INDEX] * modell.ablak,
        kondíció=kondíció,
        hossz=hossz,
        hőmérséklet=hőmérséklet,
        rng=random.Random(seed),
        leállító=PADDING_INDEX,
    )
    return " ".join(szótár.dekódol(ki))

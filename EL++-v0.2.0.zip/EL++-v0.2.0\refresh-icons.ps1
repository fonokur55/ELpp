# Windows ikon-gyorsitotar frissitese (.elpp fajlokhoz)
# Hasznalat: .\refresh-icons.ps1
$ErrorActionPreference = "Stop"
$Root = $PSScriptRoot

$icoPath = Join-Path $env:LOCALAPPDATA "ELplusplus\el.ico"
$wrapper = Join-Path $env:LOCALAPPDATA "ELplusplus\el++.cmd"

if (-not (Test-Path $icoPath)) {
    Write-Host "Nincs el.ico. Eloszor futtasd: .\install.ps1" -ForegroundColor Yellow
    exit 1
}

. (Join-Path $Root "Register-ElppWindows.ps1")
Register-ElppWindowsAssociation -IcoPath $icoPath -WrapperPath $wrapper | Out-Null

Write-Host "Ikon utvonal: $icoPath" -ForegroundColor Cyan
Write-Host "Ikon-gyorsitotar biztonsagos frissitese..." -ForegroundColor Cyan
Restart-ExplorerIconCache
Write-Host "Keszen. Ha meg feher, nyisd meg ujra a mappat (vagy jelentkezz ki/be)." -ForegroundColor Green

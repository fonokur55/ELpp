"""Tanítási adat-generátor a KódTanár modellhez (KT.3).

A `kodtanar_scenarios.py` 8 szcenáriójára építünk:
  - Minden szcenárióhoz definiáljuk a "valós" cél-értékeket (címkék)
  - Minden szcenárióból generálunk N variánst (zaj-perturbációval)
  - A kimenet: címkézett dict-lista, közvetlenül `rt.fit()`-be illeszthető

Használat:
    from kodtanar_data import generál_tanító_adatot, CÉLOK
    train = generál_tanító_adatot(n_per_szcenárió=10, seed=42)
    rt.fit(train, célok=CÉLOK, epochok=5)
"""

from __future__ import annotations

import random
from typing import Callable

import kodtanar_scenarios as sc


# ─── A tanítás-blokk cél-mapping ────────────────────────────────────────────
# `tudat KódTanár ... tanulás (...): tanulj X -> Y kész` blokkból átveszi.
CÉLOK: dict[str, str] = {
    "syntax_hiba":      "valós_syntax",
    "logikai_hiba":     "valós_logikai",
    "runtime_hiba":     "valós_runtime",
    "kezdő_szintű":     "valós_szint_kezdő",
    "közepes_szintű":   "valós_szint_közepes",
    "haladó_szintű":    "valós_szint_haladó",
    "frusztrált":       "valós_frusztráció",
}


# ─── Szcenárió → valós cél-érték mapping ────────────────────────────────────
# Minden szcenárióhoz: mit "kellene" gondolnia a modellnek (a tutor-szakértő
# szerint). Ezekre tanítunk.

SZCENÁRIÓ_CÉLOK: dict[str, dict[str, float]] = {
    "kezdő_szintaktikai_hiba": {
        "valós_syntax":         0.95,
        "valós_logikai":        0.05,
        "valós_runtime":        0.05,
        "valós_szint_kezdő":    0.85,
        "valós_szint_közepes":  0.15,
        "valós_szint_haladó":   0.0,
        "valós_frusztráció":    0.3,
    },
    "runtime_hiba_kezdő": {
        "valós_syntax":         0.05,
        "valós_logikai":        0.15,
        "valós_runtime":        0.95,
        "valós_szint_kezdő":    0.75,
        "valós_szint_közepes":  0.2,
        "valós_szint_haladó":   0.0,
        "valós_frusztráció":    0.4,
    },
    "frusztrált_diák": {
        "valós_syntax":         0.2,
        "valós_logikai":        0.4,
        "valós_runtime":        0.3,
        "valós_szint_kezdő":    0.6,
        "valós_szint_közepes":  0.3,
        "valós_szint_haladó":   0.05,
        "valós_frusztráció":    0.95,   # ← magas
    },
    "pihenni_kellene": {
        "valós_syntax":         0.2,
        "valós_logikai":        0.4,
        "valós_runtime":        0.3,
        "valós_szint_kezdő":    0.5,
        "valós_szint_közepes":  0.35,
        "valós_szint_haladó":   0.1,
        "valós_frusztráció":    0.95,
    },
    "kezdő_új_fogalom": {
        "valós_syntax":         0.15,
        "valós_logikai":        0.15,
        "valós_runtime":        0.05,
        "valós_szint_kezdő":    0.95,   # ← magas
        "valós_szint_közepes":  0.1,
        "valós_szint_haladó":   0.0,
        "valós_frusztráció":    0.25,
    },
    "jól_halad_diák": {
        "valós_syntax":         0.05,
        "valós_logikai":        0.1,
        "valós_runtime":        0.05,
        "valós_szint_kezdő":    0.15,
        "valós_szint_közepes":  0.7,    # ← közepes
        "valós_szint_haladó":   0.3,
        "valós_frusztráció":    0.05,
    },
    "kódminőség_problémák": {
        "valós_syntax":         0.05,
        "valós_logikai":        0.2,
        "valós_runtime":        0.05,
        "valós_szint_kezdő":    0.2,
        "valós_szint_közepes":  0.6,
        "valós_szint_haladó":   0.2,
        "valós_frusztráció":    0.15,
    },
    "nyugodt_haladó": {
        "valós_syntax":         0.05,
        "valós_logikai":        0.05,
        "valós_runtime":        0.05,
        "valós_szint_kezdő":    0.05,
        "valós_szint_közepes":  0.25,
        "valós_szint_haladó":   0.85,   # ← haladó
        "valós_frusztráció":    0.05,
    },
}


def _zajozott(érték: float, std: float, rng: random.Random) -> float:
    """Hozzáad egy kis Gauss-zajt és klippeli [0, 1] közé."""
    ki = érték + rng.gauss(0, std)
    return max(0.0, min(1.0, ki))


def generál_tanító_adatot(
    *,
    n_per_szcenárió: int = 10,
    seed: int = 42,
    zaj_std: float = 0.05,
) -> list[dict[str, float]]:
    """Címkézett tanító-adat generálása.

    Visszatérés: lista olyan dict-ekből, amik tartalmazzák az
    `észlelés` paramétereit ÉS a `valós_*` cél-oszlopokat.
    Mind `rt.fit(adatok, célok=CÉLOK)` formátumban használható.

    Paraméterek:
      - n_per_szcenárió: hány variánst generálunk minden szcenárióból
      - seed: reprodukálhatóság
      - zaj_std: a paraméter-zaj szórása (kis perturbáció)
    """
    rng = random.Random(seed)
    adatok: list[dict[str, float]] = []

    for szcen_név, generátor in sc.ÖSSZES_SZCENÁRIÓ.items():
        if szcen_név not in SZCENÁRIÓ_CÉLOK:
            continue
        célok = SZCENÁRIÓ_CÉLOK[szcen_név]
        for _ in range(n_per_szcenárió):
            alap = generátor()
            zajos_paraméterek = {
                p: _zajozott(v, zaj_std, rng) for p, v in alap.items()
            }
            # Cél-értékekhez is kis zaj — valós tanítójel sosem tökéletes
            zajos_célok = {
                t: _zajozott(v, zaj_std / 2, rng) for t, v in célok.items()
            }
            sor = {**zajos_paraméterek, **zajos_célok}
            adatok.append(sor)

    rng.shuffle(adatok)
    return adatok


def generál_értékelő_adatot(
    *,
    n_per_szcenárió: int = 3,
    seed: int = 123,
) -> list[dict[str, float]]:
    """Külön értékelő-szett — más seed, kevesebb példa."""
    return generál_tanító_adatot(
        n_per_szcenárió=n_per_szcenárió, seed=seed
    )

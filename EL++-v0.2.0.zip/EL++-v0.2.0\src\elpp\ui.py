"""EL++ terminál-UI: színek, sárga keret és banner a REPL-hez.

Csak megjelenítés, semmi függés a nyelv magjától, így könnyen tesztelhető.
A színek ANSI-escape kódok; Windowson bekapcsoljuk a virtuális terminált.
Ha a kimenet nem terminál (pl. fájlba/csőbe irányítva), vagy be van állítva
a NO_COLOR, akkor a színezés kikapcsol; ha a konzol nem UTF-8, a keret sima
ASCII karakterekre vált. Erőltetett ASCII: ELPP_ASCII=1.
"""

from __future__ import annotations

import os
import re
import sys

# EL++ logó (a nyelv_ascii/ascii.txt beágyazva, hogy pip-telepítés után is meglegyen).
BANNER_ART = (
    "    ________\n"
    "   / ____/ /    __    __\n"
    "  / __/ / /  __/ /___/ /_\n"
    " / /___/ /__/_  __/_  __/\n"
    "/_____/_____//_/   /_/"
)

# ANSI színek
RESET = "\033[0m"
BOLD = "\033[1m"
DIM = "\033[2m"
YELLOW = "\033[93m"  # világos sárga: a keret színe
CYAN = "\033[96m"
RED = "\033[91m"
GREEN = "\033[92m"

_ANSI_RE = re.compile(r"\033\[[0-9;]*m")

# Modul-állapot: a init() tölti fel a környezet alapján.
_STATE = {"color": False, "unicode": True}


def strip_ansi(text: str) -> str:
    """ANSI színkódok eltávolítása (teszteléshez, log-hoz)."""
    return _ANSI_RE.sub("", text)


def _detect_unicode() -> bool:
    if os.environ.get("ELPP_ASCII"):
        return False
    enc = (getattr(sys.stdout, "encoding", None) or "").lower()
    return "utf" in enc


def _enable_ansi() -> bool:
    """ANSI-színek engedélyezése; Windowson a virtuális terminál bekapcsolása.

    Visszatér: színezhető-e a kimenet.
    """
    if os.environ.get("NO_COLOR"):
        return False
    if not getattr(sys.stdout, "isatty", lambda: False)():
        return False
    if os.name == "nt":
        try:
            import ctypes

            kernel32 = ctypes.windll.kernel32  # type: ignore[attr-defined]
            handle = kernel32.GetStdHandle(-11)  # STD_OUTPUT_HANDLE
            mode = ctypes.c_uint32()
            if kernel32.GetConsoleMode(handle, ctypes.byref(mode)):
                # ENABLE_VIRTUAL_TERMINAL_PROCESSING = 0x0004
                kernel32.SetConsoleMode(handle, mode.value | 0x0004)
        except Exception:
            return False
    return True


def init() -> None:
    """Egyszeri környezet-felmérés a REPL indulásakor."""
    _STATE["color"] = _enable_ansi()
    _STATE["unicode"] = _detect_unicode()


def paint(text: str, color: str) -> str:
    """Szöveg színezése, ha a kimenet színezhető; különben változatlan."""
    if not _STATE["color"] or not color:
        return text
    return f"{color}{text}{RESET}"


def _chars() -> dict[str, str]:
    if _STATE["unicode"]:
        return {"tl": "╭", "tr": "╮", "bl": "╰", "br": "╯", "h": "─", "v": "│"}
    return {"tl": "+", "tr": "+", "bl": "+", "br": "+", "h": "-", "v": "|"}


def banner(version: str, dialect: str) -> str:
    """A sárga keretes fejléc: EL++ logó + üdvözlő szöveg."""
    c = _chars()
    art_lines = BANNER_ART.split("\n")
    dot = " · " if _STATE["unicode"] else " - "
    text_lines = [
        "",
        f"EL++ (Easy Language) v{version}{dot}REPL [{dialect}]",
        f"súgó: :súgó{dot}példák: :példák{dot}kilépés: :kilép",
    ]
    lines = art_lines + text_lines
    inner = max(len(line) for line in lines)

    top = paint(c["tl"] + c["h"] * (inner + 2) + c["tr"], YELLOW)
    bottom = paint(c["bl"] + c["h"] * (inner + 2) + c["br"], YELLOW)
    edge = paint(c["v"], YELLOW)

    rows = [top]
    for i, line in enumerate(lines):
        padded = line.ljust(inner)
        # A logó-sorok sárgák (ez az EL++ arany embléma), a szöveg alapszínű.
        body = paint(padded, YELLOW) if i < len(art_lines) else padded
        rows.append(f"{edge} {body} {edge}")
    rows.append(bottom)
    return "\n".join(rows)


def rail_prompt(prompt_text: str) -> str:
    """Bal oldali sárga keret-léc a beviteli sorhoz (a kód a keretben fut)."""
    c = _chars()
    return f"{paint(c['v'], YELLOW)} {paint(prompt_text, YELLOW + BOLD)}"


def rail_line(text: str) -> str:
    """Egy kimeneti sor a sárga keret-lécen belül."""
    c = _chars()
    return f"{paint(c['v'], YELLOW)}   {text}"


def rail_close() -> str:
    """A sárga keret lezárása kilépéskor."""
    c = _chars()
    cow = " 🐮" if _STATE["unicode"] else ""
    return paint(c["bl"] + c["h"] * 2, YELLOW) + f" Viszlát!{cow}"


def clear_screen() -> None:
    """Képernyő törlése (ANSI); ha nem színezhető, több üres sor."""
    if _STATE["color"]:
        sys.stdout.write("\033[2J\033[H")
        sys.stdout.flush()
    else:
        print("\n" * 3)

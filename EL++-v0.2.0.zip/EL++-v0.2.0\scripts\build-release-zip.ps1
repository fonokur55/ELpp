# GitHub Release ZIP keszitese (install.bat, EL++.png, src, vscode-elpp, stb.)
# Hasznalat: .\scripts\build-release-zip.ps1

$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot

$version = (Select-String -Path (Join-Path $Root "pyproject.toml") -Pattern '^version = "(.+)"' |
    ForEach-Object { $_.Matches[0].Groups[1].Value })
if (-not $version) { throw "Verzio nem talalhato a pyproject.toml-ban." }

$zipName = "EL++-v$version.zip"
$stagingName = "EL++-v$version"
$distDir = Join-Path $Root "dist"
$staging = Join-Path $distDir $stagingName
$zipPath = Join-Path $distDir $zipName

if (Test-Path $staging) { Remove-Item $staging -Recurse -Force }
if (Test-Path $zipPath) { Remove-Item $zipPath -Force }
New-Item -ItemType Directory -Force -Path $staging | Out-Null

$rootFiles = @(
    "EL++.png",
    "install.bat",
    "install.ps1",
    "refresh-icons.ps1",
    "Register-ElppWindows.ps1",
    "release.json",
    "pyproject.toml",
    "README.md"
)
foreach ($f in $rootFiles) {
    $src = Join-Path $Root $f
    if (-not (Test-Path $src)) { throw "Hianyzik: $f" }
    Copy-Item $src (Join-Path $staging $f)
}

Copy-Item (Join-Path $Root "scripts") (Join-Path $staging "scripts") -Recurse
Copy-Item (Join-Path $Root "examples") (Join-Path $staging "examples") -Recurse
# A TELJES elpp csomagot masoljuk, az ALCSOMAGOKKAL egyutt (builtins, graph,
# reasoning, tudat, ...), mert az interpreter importalja oket. Korabban csak a
# legfelso szintu .py fajlok kerultek be, ezert a telepitett nyelv mar importra
# elszallt (ModuleNotFoundError: elpp.builtins) - ez volt a "nem indul el" oka.
$srcElpp = Join-Path $Root "src\elpp"
$dstElpp = Join-Path $staging "src\elpp"
Copy-Item $srcElpp $dstElpp -Recurse -Force
# Cache/build-maradek kihagyasa a csomagbol (tisztabb, kisebb ZIP).
Get-ChildItem $dstElpp -Recurse -Force -Directory |
    Where-Object { $_.Name -eq "__pycache__" } |
    Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
Get-ChildItem $dstElpp -Recurse -Force -File -Filter "*.pyc" |
    Remove-Item -Force -ErrorAction SilentlyContinue

$extSrc = Join-Path $Root "vscode-elpp"
$extDst = Join-Path $staging "vscode-elpp"
New-Item -ItemType Directory -Force -Path $extDst | Out-Null
# A nem-vsix fajlok mind mennek.
Get-ChildItem $extSrc -File | Where-Object { $_.Extension -ne ".vsix" } |
    Copy-Item -Destination $extDst
# A vsix-ek kozul a verzio-egyezot valasztjuk; ha az nincs, a legujabb meglevot,
# hogy a ZIP-ben MINDIG legyen egy telepitheto bovitmeny (Node nelkuli gepekre is).
$vsix = "elpp-language-$version.vsix"
$chosen = Get-ChildItem $extSrc -File -Filter "*.vsix" |
    Sort-Object -Property @{ Expression = { $_.Name -eq $vsix } }, LastWriteTime -Descending |
    Select-Object -First 1
if ($chosen) {
    Copy-Item $chosen.FullName (Join-Path $extDst $chosen.Name)
    if ($chosen.Name -ne $vsix) {
        Write-Host "  i $vsix nincs; a legujabb vsix megy: $($chosen.Name)" -ForegroundColor DarkGray
    }
} else {
    Write-Host "  ! Nincs .vsix a vscode-elpp mappaban - a telepito ujraepiti (Node kell)." -ForegroundColor Yellow
}
Get-ChildItem $extSrc -Directory | ForEach-Object {
    Copy-Item $_.FullName (Join-Path $extDst $_.Name) -Recurse
}

Compress-Archive -Path $staging -DestinationPath $zipPath -Force
Remove-Item $staging -Recurse -Force

$sizeKb = [math]::Round((Get-Item $zipPath).Length / 1KB)
Write-Host ('Kesz: {0} ({1} KB)' -f $zipPath, $sizeKb) -ForegroundColor Green
Write-Host "GitHub Release: https://github.com/fonokur55/EL-/releases/new" -ForegroundColor Cyan
Write-Host "  Tag: v$version" -ForegroundColor Cyan
Write-Host "  Asset: $zipName" -ForegroundColor Cyan

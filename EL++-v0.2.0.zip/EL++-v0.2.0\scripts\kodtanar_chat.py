#!/usr/bin/env python3
"""KódTanár (chat) — Interaktív, beszélgetős bemutató (Phase 7 / M7.4).

A tudat NYERS KÓDOT és ÜZENETET olvas (Phase 6), és grounded, magyarázható,
hallucináció-mentes VÁLASZT RAK ÖSSZE a hiedelmeiből (Phase 7). Bárki
használhatja: bemásolod a kódod, írsz egy üzenetet, és elbeszélgetsz vele.

Indítás:
    python scripts/kodtanar_chat.py

A beszélgetésben:
    • Írj be kódot (több sor, üres sor zárja) és egy üzenetet.
    • Kérdezd meg: „miért?" — és megindokolja az előző válaszát.
    • Javítsd: `/javit <hiedelem> <0..1>` — és a szemed láttára tanul belőle.
    • Kilépés: üres kód.
"""

from __future__ import annotations

import sys
from pathlib import Path

if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    except (AttributeError, OSError):
        pass

ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "examples" / "ai"))

from elpp.parser import parse  # noqa: E402
from elpp.tudat import TudatRuntime  # noqa: E402
from elpp.tudat.szoveg import Beszélgetés  # noqa: E402

import kodtanar_szöveg_adat as kd  # noqa: E402

MODELL_PATH = ROOT / "examples" / "ai" / "kodtanar_chat.elpp"
FÓKUSZ = ["frusztrált", "kezdő", "gyenge_kódminőség"]
EPOCHOK = 100
TANULÁSI_RÁTA = 0.5


# ─── Modell + beszélgetés (tesztelhető, újrahasználható) ─────────────────────


def betölt_és_tanít(*, seed: int = 1, epochok: int = EPOCHOK) -> TudatRuntime:
    """A beszélgetős KódTanár betanítása a hibrid szöveg-adatból."""
    src = MODELL_PATH.read_text(encoding="utf-8")
    rt = TudatRuntime(parse(src).statements[0], seed=seed)
    rt.fit(
        kd.tanító_adat(seed=42),
        célok=kd.CÉLOK,
        epochok=epochok,
        tanulási_ráta=TANULÁSI_RÁTA,
    )
    return rt


def beszélgetés_indít(rt: TudatRuntime, *, seed: int | None = None) -> Beszélgetés:
    """Beszélgetés a betanított tudat köré, a diák üzenetére hangolva."""
    return Beszélgetés(
        rt, fókusz_hiedelmek=FÓKUSZ, üzenet_mező="diák_üzenete", seed=seed
    )


# ─── Kiírás-segédek ─────────────────────────────────────────────────────────


def fej(címe: str) -> None:
    sáv = "═" * (len(címe) + 4)
    print(f"\n╔{sáv}╗\n║  {címe}  ║\n╚{sáv}╝")


def _olvass_több_sort(prompt: str) -> str:
    print(prompt + " (üres sor = vége):")
    sorok: list[str] = []
    while True:
        try:
            sor = input("    ")
        except EOFError:
            break
        if sor == "":
            break
        sorok.append(sor)
    return "\n".join(sorok)


# ─── Interaktív loop ─────────────────────────────────────────────────────────


def _javít_parancs(b: Beszélgetés, üzenet: str) -> str | None:
    """`/javit <hiedelem> <érték>` → online korrekció. None, ha nem ez."""
    if not üzenet.startswith("/javit"):
        return None
    részek = üzenet.split()
    if len(részek) != 3 or részek[1] not in FÓKUSZ:
        return (
            "Használat: /javit <frusztrált|kezdő|gyenge_kódminőség> <0..1>"
        )
    try:
        érték = float(részek[2])
    except ValueError:
        return "A javított értéknek számnak kell lennie (0 és 1 között)."
    return b.helyesbít(**{részek[1]: érték})


def interaktív(b: Beszélgetés) -> None:
    fej("KódTanár — beszélgess velem a kódodról")
    print("(Kérdezd: „miért?” · javíts: /javit <hiedelem> <0..1> · kilépés: üres kód)")
    while True:
        kód = _olvass_több_sort("\nA kódod")
        üzenet = input("Az üzeneted: ").strip()
        if not kód.strip() and not üzenet:
            print("\nViszlát! 👋  Jó kódolást!")
            return
        javítás = _javít_parancs(b, üzenet)
        if javítás is not None:
            print(f"\nKódTanár: {javítás}")
            continue
        válasz = b.fordul(diák_kódja=kód, diák_üzenete=üzenet)
        print(f"\nKódTanár: {válasz or '(erről még nincs határozott véleményem)'}")


def main() -> None:
    fej("KódTanár (chat) — Phase 7")
    print("• Tanulás a hibrid adatból...")
    rt = betölt_és_tanít()
    print("  ✓ kész. Másold be a kódod, és beszélgessünk!")
    interaktív(beszélgetés_indít(rt, seed=0))


if __name__ == "__main__":
    main()

"""Forward-chaining következtetés bizonyossággal."""

from __future__ import annotations

from dataclasses import dataclass

from elpp.runtime_values import Belief, Fact


@dataclass
class RuleEntry:
    condition_key: str
    condition_value: object
    conclusion: str
    confidence: float


class ReasoningEngine:
    """Egyszerű szabály-alapú motor."""

    def __init__(self) -> None:
        self.beliefs: dict[str, Belief] = {}
        self.facts: list[Fact] = []
        self.rules: list[RuleEntry] = []

    def assume(self, claim: str, confidence: float) -> None:
        c = max(0.0, min(1.0, confidence))
        existing = self.beliefs.get(claim)
        if existing is None or c > existing.confidence:
            self.beliefs[claim] = Belief(claim, c)

    def add_rule(
        self,
        condition_key: str,
        condition_value: object,
        conclusion: str,
        confidence: float,
    ) -> None:
        self.rules.append(
            RuleEntry(condition_key, condition_value, conclusion, confidence)
        )

    def propagate(self) -> None:
        """Forward chaining: szabályok alkalmazása."""
        changed = True
        while changed:
            changed = False
            for rule in self.rules:
                if self._condition_holds(rule):
                    new_conf = rule.confidence * 0.95
                    old = self.beliefs.get(rule.conclusion)
                    if old is None or new_conf > old.confidence:
                        self.beliefs[rule.conclusion] = Belief(
                            rule.conclusion, new_conf
                        )
                        changed = True

    def _condition_holds(self, rule: RuleEntry) -> bool:
        if rule.condition_key in self.beliefs:
            b = self.beliefs[rule.condition_key]
            return self._truthy(b.confidence)
        return False

    @staticmethod
    def _truthy(conf: float) -> bool:
        return conf >= 0.5

    def query(self, claim: str) -> Belief | None:
        self.propagate()
        return self.beliefs.get(claim)

    def combine(self, a: float, b: float) -> float:
        """Bayes-szerű kombináció (független források)."""
        return 1.0 - (1.0 - a) * (1.0 - b)

    def contradicts(self, claim_a: str, claim_b: str) -> bool:
        """Egyszerű ellentmondás: magas bizonyosság mindkettőn, ellentétes állítás."""
        ba = self.beliefs.get(claim_a)
        bb = self.beliefs.get(claim_b)
        if ba is None or bb is None:
            return False
        neg_pairs = {("igaz", "hamis"), ("true", "false"), ("esik", "nem esik")}
        pair = (claim_a.casefold(), claim_b.casefold())
        rev = (pair[1], pair[0])
        if pair in neg_pairs or rev in neg_pairs:
            return ba.confidence > 0.7 and bb.confidence > 0.7
        return False

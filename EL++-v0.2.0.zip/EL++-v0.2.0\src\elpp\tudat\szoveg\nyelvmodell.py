"""Tanult, belief-horgonyzott nyelvi modell — Phase 8 / M8.3.a + vektorizáció.

A tudat SAJÁT, TANULT generátora — nem sablon (Phase 7), nem LLM-wrapper. A modell
adatból tanul nyelvet generálni, és a tudat hiedelem-állapotára KONDICIONÁLVA termel.

**Architektúra (a BPTT elkerülésére):** kondicionált FEED-FORWARD nyelvi modell
(neurális n-gram). A kontextus FIX ABLAK az előző tokenekből → a gradiens egyszerű,
analitikus backprop, NEM időben-visszafelé terjesztett (BPTT).

    x       = [ E[w_{t-k}] ⊕ … ⊕ E[w_{t-1}] ⊕ kondíció ]
    h       = tanh(W1·x + b1)
    logits  = W2·h + b2 ;  p = softmax(logits)
    veszteség = −log p[cél]

**Vektorizáció (M8.3 sebesség-döntés):** a matek numpy-ban fut (mátrixszorzás),
így a TELJES korpusz tanítható. A numpy CSAK számítás-gyorsító — az architektúra,
a szabályok, a tanulás végig a miénk. Az analitikus gradiens változatlan, és
továbbra is numerikusan igazolt.
"""

from __future__ import annotations

import math
import random

import numpy as np

INIT_SZÓRÁS = 0.1


def _softmax(z: np.ndarray) -> np.ndarray:
    """Numerikusan stabil softmax (1D)."""
    z = z - z.max()
    e = np.exp(z)
    return e / e.sum()


class NyelvModell:
    """Kondicionált feed-forward nyelvi modell (neurális n-gram), numpy-háttérrel.

    Paraméterek:
        vocab_méret: a szótár mérete.
        ablak: hány előző tokenre feltételez (kontextus-ablak, default 3).
        dim: a beágyazás dimenziója (default 32).
        rejtett: a rejtett réteg mérete (default 64).
        kondíció_méret: a hiedelem-kondíció vektor mérete (0 = tiszta nyelvi modell).
        seed: reprodukálható inicializáláshoz.
    """

    __slots__ = (
        "vocab_méret", "ablak", "dim", "rejtett", "kondíció_méret",
        "E", "W1", "b1", "W2", "b2",
    )

    def __init__(
        self,
        vocab_méret: int,
        *,
        ablak: int = 3,
        dim: int = 32,
        rejtett: int = 64,
        kondíció_méret: int = 0,
        seed: int | None = None,
    ) -> None:
        if vocab_méret < 1 or ablak < 1 or dim < 1 or rejtett < 1:
            raise ValueError("vocab_méret/ablak/dim/rejtett legalább 1 legyen.")
        if kondíció_méret < 0:
            raise ValueError("kondíció_méret nem lehet negatív.")
        self.vocab_méret = vocab_méret
        self.ablak = ablak
        self.dim = dim
        self.rejtett = rejtett
        self.kondíció_méret = kondíció_méret
        bemenet = ablak * dim + kondíció_méret

        rng = np.random.default_rng(seed)
        self.E = rng.normal(0.0, INIT_SZÓRÁS, (vocab_méret, dim))
        self.W1 = rng.normal(0.0, INIT_SZÓRÁS, (rejtett, bemenet))
        self.b1 = np.zeros(rejtett)
        self.W2 = rng.normal(0.0, INIT_SZÓRÁS, (vocab_méret, rejtett))
        self.b2 = np.zeros(vocab_méret)

    @property
    def _bemenet(self) -> int:
        return self.ablak * self.dim + self.kondíció_méret

    # ── Forward ────────────────────────────────────────────────────────────

    def _bemenet_vektor(
        self, kontextus: list[int], kondíció: list[float]
    ) -> np.ndarray:
        if len(kontextus) != self.ablak:
            raise ValueError(
                f"A kontextusnak {self.ablak} tokenből kell állnia "
                f"(kapott {len(kontextus)})."
            )
        if len(kondíció) != self.kondíció_méret:
            raise ValueError(
                f"A kondíció mérete {self.kondíció_méret} legyen "
                f"(kapott {len(kondíció)})."
            )
        emb = self.E[kontextus].reshape(-1)   # (ablak*dim,)
        if self.kondíció_méret:
            return np.concatenate([emb, np.asarray(kondíció, dtype=float)])
        return emb

    def _előre(
        self, kontextus: list[int], kondíció: list[float]
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        """Forward → (eloszlás p, rejtett h, bemenet x)."""
        x = self._bemenet_vektor(kontextus, kondíció)
        h = np.tanh(self.W1 @ x + self.b1)
        logits = self.W2 @ h + self.b2
        return _softmax(logits), h, x

    def eloszlás(
        self, kontextus: list[int], kondíció: list[float] | None = None
    ) -> np.ndarray:
        """A következő token valószínűség-eloszlása a szótár felett."""
        p, _, _ = self._előre(kontextus, kondíció or [0.0] * self.kondíció_méret)
        return p

    # ── Veszteség + analitikus gradiens ──────────────────────────────────────

    def veszteség(
        self, kontextus: list[int], kondíció: list[float], cél: int
    ) -> float:
        p, _, _ = self._előre(kontextus, kondíció)
        return float(-math.log(max(float(p[cél]), 1e-12)))

    def gradiens(
        self, kontextus: list[int], kondíció: list[float], cél: int
    ) -> tuple[dict[int, np.ndarray], np.ndarray, np.ndarray,
               np.ndarray, np.ndarray, float]:
        """Analitikus gradiens egy példára.

        Visszatérés: (grad_E, grad_W1, grad_b1, grad_W2, grad_b2, veszteség).
        grad_E sparse: {token_index: [dim] gradiens} csak a kontextus-tokenekre.
        """
        p, h, x = self._előre(kontextus, kondíció)
        veszteség = float(-math.log(max(float(p[cél]), 1e-12)))

        dz2 = p.copy()
        dz2[cél] -= 1.0                       # p − onehot(cél)
        grad_b2 = dz2
        grad_W2 = np.outer(dz2, h)            # (V, rejtett)

        dh = self.W2.T @ dz2                  # (rejtett,)
        dz1 = dh * (1.0 - h * h)              # tanh'
        grad_b1 = dz1
        grad_W1 = np.outer(dz1, x)           # (rejtett, bemenet)

        dx = self.W1.T @ dz1                  # (bemenet,)
        emb_grad = dx[: self.ablak * self.dim].reshape(self.ablak, self.dim)
        grad_E: dict[int, np.ndarray] = {}
        for poz, idx in enumerate(kontextus):
            if idx in grad_E:
                grad_E[idx] = grad_E[idx] + emb_grad[poz]   # ismétlődő → összead
            else:
                grad_E[idx] = emb_grad[poz].copy()
        return grad_E, grad_W1, grad_b1, grad_W2, grad_b2, veszteség

    def tanulj_lépés(
        self, kontextus: list[int], kondíció: list[float], cél: int,
        tanulási_ráta: float,
    ) -> float:
        """Egy SGD-lépés (vektorizált); visszaadja a lépés előtti veszteséget."""
        grad_E, gW1, gb1, gW2, gb2, veszteség = self.gradiens(
            kontextus, kondíció, cél
        )
        lr = tanulási_ráta
        self.b2 -= lr * gb2
        self.W2 -= lr * gW2
        self.b1 -= lr * gb1
        self.W1 -= lr * gW1
        for idx, g in grad_E.items():
            self.E[idx] -= lr * g
        return veszteség

    # ── Generálás ────────────────────────────────────────────────────────────

    def generál(
        self,
        kezdő_kontextus: list[int],
        *,
        kondíció: list[float] | None = None,
        hossz: int = 20,
        hőmérséklet: float = 1.0,
        rng: random.Random | None = None,
        leállító: int | None = None,
    ) -> list[int]:
        """Token-szekvencia generálása autoregresszíven, hőmérsékletes mintavétellel."""
        rng = rng or random.Random()
        kondíció = kondíció or [0.0] * self.kondíció_méret
        kontextus = list(kezdő_kontextus[-self.ablak:])
        if len(kontextus) < self.ablak:
            kontextus = [0] * (self.ablak - len(kontextus)) + kontextus

        ki: list[int] = []
        for _ in range(hossz):
            p, _, _ = self._előre(kontextus, kondíció)
            if hőmérséklet != 1.0:
                p = _softmax(np.log(np.maximum(p, 1e-12)) / hőmérséklet)
            token = _mintavétel(p, rng)
            if leállító is not None and token == leállító:
                break
            ki.append(token)
            kontextus = kontextus[1:] + [token]
        return ki

    def __repr__(self) -> str:  # pragma: no cover
        return (
            f"NyelvModell(vocab={self.vocab_méret}, ablak={self.ablak}, "
            f"dim={self.dim}, rejtett={self.rejtett}, kondíció={self.kondíció_méret})"
        )


def _mintavétel(p: np.ndarray, rng: random.Random) -> int:
    """Kategorikus mintavétel egy valószínűség-eloszlásból."""
    r = rng.random()
    halmoz = 0.0
    for i in range(len(p)):
        halmoz += float(p[i])
        if r <= halmoz:
            return i
    return len(p) - 1

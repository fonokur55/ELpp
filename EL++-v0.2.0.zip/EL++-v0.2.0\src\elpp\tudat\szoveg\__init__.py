"""Szöveg-támogatás a tudat-paradigmához (Phase 6).

A `tudat` ettől a rétegtől kezdve NYERS SZÖVEGET olvas (kód, üzenet,
dokumentum), nem előre kiszámolt számokat.

Rétegek:
  • M6.1 — tokenizer: `Tokenizer`, `Szótár` (token → index).
  • M6.2 — beágyazás: token-index → vektor → pooling (analitikus gradienssel).
  • M6.3 — `tényező szöveg`: a paradigma 5. tényező-típusa.
"""

from __future__ import annotations

from elpp.tudat.szoveg.beagyazas import (
    ALAPÉRTELMEZETT_DIM,
    SzövegKódoló,
)
from elpp.tudat.szoveg.beszelgetes import Beszélgetés
from elpp.tudat.szoveg.diagnozis import Megállapítás, diagnózis, szövegezd
from elpp.tudat.szoveg.kodelemzo import KódTények, elemez
from elpp.tudat.szoveg.grounded import (
    bootstrap_állapotokból,
    generál_állapotból,
    kondíció_vektor,
    készíts_kondicionált_adatot,
    tanítsd_kondicionáltan,
    építs_tanult_generátort,
)
from elpp.tudat.szoveg.korpusz import (
    építs_korpuszt,
    folytat_szöveg,
    tanító_párok,
    tanítsd,
)
from elpp.tudat.szoveg.generator_api import (
    Generátor,
    elérhető_háttérek,
    generátort_készít,
)
from elpp.tudat.szoveg.nyelvmodell import NyelvModell
from elpp.tudat.szoveg.generalas import (
    DictForrás,
    FragmentForrás,
    Generáló,
    HiedelemPillanat,
    Megnyilvánulás,
    Sáv,
    Szerep,
    megfogalmazás,
    sáv_meghatározás,
    tartalom_választás,
    tervezés,
)
from elpp.tudat.szoveg.tokenizer import (
    ISMERETLEN,
    ISMERETLEN_INDEX,
    PADDING,
    PADDING_INDEX,
    Szótár,
    Tokenizer,
)

__all__ = [
    "Tokenizer",
    "Szótár",
    "PADDING",
    "ISMERETLEN",
    "PADDING_INDEX",
    "ISMERETLEN_INDEX",
    "SzövegKódoló",
    "ALAPÉRTELMEZETT_DIM",
    # M7.1 — kompozíciós generálás
    "Generáló",
    "HiedelemPillanat",
    "Megnyilvánulás",
    "FragmentForrás",
    "DictForrás",
    "Szerep",
    "Sáv",
    "sáv_meghatározás",
    "tartalom_választás",
    "tervezés",
    "megfogalmazás",
    # M7.3 — beszélgetés
    "Beszélgetés",
    # M8.1 — kód-elemzés
    "KódTények",
    "elemez",
    # M8.4 — diagnózis
    "Megállapítás",
    "diagnózis",
    "szövegezd",
    # M8.3 — tanult nyelvi generátor
    "NyelvModell",
    # M8.5 — skálázható váz (generátor-szerződés + gyár)
    "Generátor",
    "generátort_készít",
    "elérhető_háttérek",
    "építs_korpuszt",
    "tanító_párok",
    "tanítsd",
    "folytat_szöveg",
    # M8.3.c — belief-kondicionált (grounded) generálás
    "kondíció_vektor",
    "készíts_kondicionált_adatot",
    "tanítsd_kondicionáltan",
    "generál_állapotból",
    "bootstrap_állapotokból",
    "építs_tanult_generátort",
]

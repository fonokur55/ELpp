"""Runtime értéktípusok az EL++-hoz."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable

from elpp import ast


@dataclass
class FunctionValue:
    name: str
    params: list[str]
    body: list[ast.Stmt]
    closure: dict[str, Any]


@dataclass
class Belief:
    """Állítás bizonyossággal (0..1)."""

    claim: str
    confidence: float

    def __post_init__(self) -> None:
        self.confidence = max(0.0, min(1.0, float(self.confidence)))


@dataclass
class Fact:
    predicate: str
    args: tuple[Any, ...] = ()
    confidence: float = 1.0

    def __post_init__(self) -> None:
        self.confidence = max(0.0, min(1.0, float(self.confidence)))


@dataclass
class GraphNode:
    id: str
    op: str
    inputs: list[str] = field(default_factory=list)
    cost: float = 1.0
    value: Any = None
    computed: bool = False


@dataclass
class ComputationGraph:
    nodes: dict[str, GraphNode] = field(default_factory=dict)
    total_cost: float = 0.0

    def add_node(self, node_id: str, op: str, inputs: list[str], cost: float = 1.0) -> None:
        self.nodes[node_id] = GraphNode(node_id, op, inputs, cost)


class ElTensor:
    """Egyszerű tensor (lista-alapú buffer)."""

    __slots__ = ("data", "shape")

    def __init__(self, data: list[float], shape: list[int] | None = None):
        self.data = list(data)
        if shape is None:
            self.shape = [len(data)] if data else [0]
        else:
            self.shape = list(shape)

    def __repr__(self) -> str:
        return f"Tensor(shape={self.shape}, n={len(self.data)})"


# Beépített natív függvények
NativeFn = Callable[[list[Any]], Any]

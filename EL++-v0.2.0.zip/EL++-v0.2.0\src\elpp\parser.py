"""Parser: token lista → AST."""

from __future__ import annotations

from elpp import ast
from elpp.errors import ParseError, unexpected_token
from elpp.lexer import Token, filter_newlines, tokenize
from elpp.synonyms import Dialect

_PRECEDENCE: dict[str, int] = {
    "OR": 1,
    "AND": 2,
    "EQ": 3, "NE": 3,
    "LT": 4, "GT": 4, "LE": 4, "GE": 4,
    "PLUS": 5, "MINUS": 5,
    "STAR": 6, "SLASH": 6,
}

_COMPARISON = {"EQ", "NE", "LT", "GT", "LE", "GE"}


class Parser:
    def __init__(self, tokens: list[Token], dialect: Dialect = "easy"):
        self.tokens = filter_newlines(tokens)
        self.dialect = dialect
        self.pos = 0

    def _cur(self) -> Token:
        return self.tokens[self.pos]

    def _peek(self, offset: int = 0) -> Token:
        i = self.pos + offset
        if i >= len(self.tokens):
            return self.tokens[-1]
        return self.tokens[i]

    def _at_end(self) -> bool:
        return self._cur().kind == "EOF"

    def _advance(self) -> Token:
        t = self._cur()
        if not self._at_end():
            self.pos += 1
        return t

    def _match(self, *kinds: str) -> Token | None:
        if self._cur().kind in kinds:
            return self._advance()
        return None

    def _expect(self, kind: str, hint: str = "") -> Token:
        if self._cur().kind != kind:
            got = self._cur().kind
            msg = unexpected_token(got, kind).args[0]
            if hint:
                msg += f" {hint}"
            raise ParseError(msg, line=self._cur().line)
        return self._advance()

    def parse(self) -> ast.Program:
        stmts: list[ast.Stmt] = []
        while not self._at_end():
            if self._cur().kind == "EOF":
                break
            stmts.append(self._statement())
        return ast.Program(stmts, dialect=self.dialect)

    def _statement(self) -> ast.Stmt:
        t = self._cur()
        line = t.line

        if t.kind == "TUDAT":
            # Késleltetett import: körkörös import elkerülése
            # (a tudat parser TYPE_CHECKING alatt importálja ezt a Parser-t).
            from elpp.tudat.parser import parse_tudat
            return parse_tudat(self)

        if t.kind in ("DEF", "FN"):
            return self._parse_def(line)

        if t.kind == "RETURN":
            self._advance()
            val: ast.Expr | None = None
            if self._is_expr_start():
                val = self._expression()
            return ast.Return(val, line)

        if t.kind == "LET":
            self._advance()
            name_t = self._expect("IDENT", "Változónév kell.")
            name = str(name_t.value)
            if not self._match("EQ"):
                raise ParseError('Hiányzik az értékadás: „egyen”, „to”, „=”.', line=self._cur().line)
            value = self._expression()
            return ast.Let(name, value, line)

        if t.kind == "PRINT":
            self._advance()
            values: list[ast.Expr] = []
            while self._is_expr_start():
                values.append(self._expression())
                if not self._match("COMMA"):
                    break
            return ast.Print(values, line)

        if t.kind == "IF":
            return self._parse_if(line)

        if t.kind == "WHILE":
            self._advance()
            cond = self._expression()
            body = self._block()
            if self._cur().kind == "END":
                self._advance()
            return ast.While(cond, body, line)

        if t.kind == "FOR":
            self._advance()
            var_t = self._expect("IDENT", "Ciklusváltozó kell.")
            self._expect("IN", 'Hiányzik az „in” / „között”.')
            iterable = self._expression()
            body = self._block()
            if self._cur().kind == "END":
                self._advance()
            return ast.For(str(var_t.value), iterable, body, line)

        if t.kind == "IMPORT":
            self._advance()
            mod = self._parse_string_literal()
            return ast.Import(mod, line)

        if t.kind == "ASSUME":
            return self._parse_assume(line)

        if t.kind == "RULE":
            return self._parse_rule(line)

        if t.kind == "QUERY":
            self._advance()
            claim = self._parse_claim_text()
            return ast.Query(claim, line)

        if t.kind == "NODE":
            return self._parse_graph_node(line)

        if t.kind == "RUN":
            self._advance()
            if self._match("IDENT") and str(self._peek(-1).value).casefold() in ("graph", "graf"):
                pass
            target_t = self._expect("IDENT", "Graf célcsomópont kell.")
            return ast.RunGraph(str(target_t.value), line)

        if t.kind == "TRAIN":
            return self._parse_train(line)

        if t.kind == "END":
            self._advance()
            raise ParseError("Felesleges „kész” / „end”.", line=line)

        raise ParseError(
            "Nem értem ezt a sort. Talán „legyen”, „függvény”, „ha” vagy „amíg”?",
            line=line,
        )

    def _parse_def(self, line: int) -> ast.Def:
        self._advance()
        name_t = self._expect("IDENT", "Függvénynév kell.")
        params = self._parse_param_list()
        body = self._block()
        if self._cur().kind == "END":
            self._advance()
        return ast.Def(str(name_t.value), params, body, line)

    def _parse_param_list(self) -> list[str]:
        if not self._match("LPAREN"):
            return []
        params: list[str] = []
        if self._cur().kind != "RPAREN":
            params.append(str(self._expect("IDENT").value))
            while self._match("COMMA"):
                params.append(str(self._expect("IDENT").value))
        self._expect("RPAREN", "Hiányzik a záró „)”.")
        return params

    def _parse_if(self, line: int) -> ast.If:
        self._advance()
        cond = self._expression()
        self._expect("THEN", 'Hiányzik az „akkor” / „then”.')
        then_body = self._block()
        else_body: list[ast.Stmt] | None = None
        if self._match("ELSE"):
            else_body = self._block()
        if self._cur().kind == "END":
            self._advance()
        return ast.If(cond, then_body, else_body, line)

    def _parse_assume(self, line: int) -> ast.Assume:
        self._advance()
        if self._cur().kind == "STRING":
            claim = self._parse_string_literal()
            if self._match("CONF"):
                conf = self._expression()
                return ast.Assume(claim, conf, line)
        if self._cur().kind == "IDENT" and self._peek(1).kind == "LPAREN":
            # core: assume rain(conf=0.6) -> claim=rain, conf from inside
            claim = str(self._advance().value)
            self._expect("LPAREN")
            self._match("CONF")
            if self._match("EQ"):
                pass
            conf = self._expression()
            self._expect("RPAREN")
            return ast.Assume(claim, conf, line)
        claim = self._parse_claim_text()
        if self._match("CONF"):
            conf = self._expression()
        else:
            conf = ast.Number(1.0, line)
        return ast.Assume(claim, conf, line)

    def _parse_rule(self, line: int) -> ast.Rule:
        self._advance()
        if self._match("IF"):
            cond = self._expression()
            self._expect("THEN", 'Hiányzik az „akkor”.')
        elif self._cur().kind == "IDENT" and self._peek(1).kind == "ARROW":
            cond = ast.Var(str(self._advance().value), line)
            self._advance()
            conclusion = str(self._expect("IDENT").value)
            conf = ast.Number(1.0, line)
            if self._match("LPAREN"):
                self._match("CONF")
                if self._match("EQ"):
                    pass
                conf = self._expression()
                self._expect("RPAREN")
            return ast.Rule(cond, conclusion, conf, line)
        else:
            cond = self._expression()
            if self._match("THEN"):
                pass
            elif self._match("ARROW"):
                pass
        conclusion = self._parse_claim_text()
        if self._match("CONF"):
            conf = self._expression()
        else:
            conf = ast.Number(0.8, line)
        return ast.Rule(cond, conclusion, conf, line)

    def _parse_graph_node(self, line: int) -> ast.GraphNodeDef:
        self._advance()
        node_id = str(self._expect("IDENT").value)
        cost = 1.0
        if not self._match("EQ"):
            raise ParseError("Csomópont definícióhoz „=” / „egyen” kell.", line=line)
        op = str(self._expect("IDENT").value)
        inputs: list[str] = []
        if self._match("LPAREN"):
            while self._cur().kind == "IDENT":
                inputs.append(str(self._advance().value))
                if not self._match("COMMA"):
                    break
            self._expect("RPAREN")
        elif self._cur().kind == "IDENT":
            while self._cur().kind == "IDENT":
                inputs.append(str(self._advance().value))
                if not self._match("COMMA"):
                    break
        if self._match("COST"):
            c = self._expression()
            if isinstance(c, ast.Number):
                cost = c.value
        return ast.GraphNodeDef(node_id, op, inputs, cost, line)

    def _parse_train(self, line: int) -> ast.Train:
        self._advance()
        target = str(self._expect("IDENT").value)
        epochs = ast.Number(10.0, line)
        loss = "mse"
        if self._cur().kind == "IDENT" and str(self._cur().value).casefold() in ("epochs", "epoka", "korszak"):
            self._advance()
            epochs = self._expression()
        if self._cur().kind == "IDENT" and str(self._cur().value).casefold() == "loss":
            self._advance()
            loss = str(self._expect("IDENT").value)
        return ast.Train(target, epochs, loss, line)

    def _parse_claim_text(self) -> str:
        parts: list[str] = []
        while self._cur().kind not in (
            "EOF", "END", "ELSE", "CONF", "THEN", "NEWLINE",
            "RULE", "QUERY", "ASSUME", "PRINT", "LET", "IF", "WHILE", "FOR",
            "DEF", "FN", "RETURN", "NODE", "RUN", "TRAIN",
        ):
            if self._cur().kind == "STRING":
                parts.append(self._parse_string_literal())
                break
            if self._cur().kind == "IDENT":
                parts.append(str(self._advance().value))
                continue
            break
        return " ".join(parts) if parts else ""

    def _parse_string_literal(self) -> str:
        t = self._expect("STRING")
        return str(t.value)

    def _is_expr_start(self) -> bool:
        return self._cur().kind in (
            "IDENT", "NUMBER", "STRING", "TRUE", "FALSE",
            "LPAREN", "NOT", "MINUS", "LBRACKET", "LBRACE",
        )

    def _block(self) -> list[ast.Stmt]:
        body: list[ast.Stmt] = []
        while not self._at_end():
            k = self._cur().kind
            if k in ("END", "ELSE", "EOF"):
                break
            body.append(self._statement())
        return body

    def _expression(self) -> ast.Expr:
        return self._parse_or()

    def _parse_or(self) -> ast.Expr:
        left = self._parse_and()
        while self._match("OR"):
            right = self._parse_and()
            left = ast.Binary("OR", left, right, line=getattr(left, "line", 0))
        return left

    def _parse_and(self) -> ast.Expr:
        left = self._parse_comparison()
        while self._match("AND"):
            right = self._parse_comparison()
            left = ast.Binary("AND", left, right, line=getattr(left, "line", 0))
        return left

    def _parse_comparison(self) -> ast.Expr:
        left = self._parse_additive()
        while self._cur().kind in _COMPARISON:
            op = self._advance().kind
            right = self._parse_additive()
            left = ast.Binary(op, left, right, line=getattr(left, "line", 0))
        return left

    def _parse_additive(self) -> ast.Expr:
        left = self._parse_multiplicative()
        while self._cur().kind in ("PLUS", "MINUS"):
            op = self._advance().kind
            right = self._parse_multiplicative()
            left = ast.Binary(op, left, right, line=getattr(left, "line", 0))
        return left

    def _parse_multiplicative(self) -> ast.Expr:
        left = self._parse_unary()
        while self._cur().kind in ("STAR", "SLASH"):
            op = self._advance().kind
            right = self._parse_unary()
            left = ast.Binary(op, left, right, line=getattr(left, "line", 0))
        return left

    def _parse_unary(self) -> ast.Expr:
        if self._match("NOT"):
            return ast.Unary("NOT", self._parse_unary(), line=self._peek(-1).line)
        if self._match("MINUS"):
            return ast.Unary("MINUS", self._parse_unary(), line=self._peek(-1).line)
        return self._parse_postfix()

    def _parse_postfix(self) -> ast.Expr:
        expr = self._parse_primary()
        while True:
            if self._match("LBRACKET"):
                idx = self._expression()
                self._expect("RBRACKET")
                expr = ast.Index(expr, idx, line=getattr(expr, "line", 0))
                continue
            break
        return expr

    def _parse_primary(self) -> ast.Expr:
        t = self._cur()
        line = t.line

        if self._cur().kind == "NUMBER":
            tok = self._advance()
            v = tok.value
            assert isinstance(v, (int, float))
            return ast.Number(float(v), line)

        if self._cur().kind == "STRING":
            return ast.String(self._parse_string_literal(), line)

        if self._match("TRUE"):
            return ast.Bool(True, line)

        if self._match("FALSE"):
            return ast.Bool(False, line)

        if self._match("LBRACKET"):
            elements: list[ast.Expr] = []
            if self._cur().kind != "RBRACKET":
                elements.append(self._expression())
                while self._match("COMMA"):
                    elements.append(self._expression())
            self._expect("RBRACKET")
            return ast.ListLit(elements, line)

        if self._match("LBRACE"):
            pairs: list[tuple[ast.Expr, ast.Expr]] = []
            if self._cur().kind != "RBRACE":
                k = self._expression()
                self._expect("COLON")
                v = self._expression()
                pairs.append((k, v))
                while self._match("COMMA"):
                    k = self._expression()
                    self._expect("COLON")
                    v = self._expression()
                    pairs.append((k, v))
            self._expect("RBRACE")
            return ast.DictLit(pairs, line)

        if self._cur().kind == "IDENT":
            name = str(self._advance().value)
            if self._match("LPAREN"):
                args: list[ast.Expr] = []
                if self._cur().kind != "RPAREN":
                    args.append(self._expression())
                    while self._match("COMMA"):
                        args.append(self._expression())
                self._expect("RPAREN")
                return ast.Call(name, args, line)
            return ast.Var(name, line)

        if self._match("LPAREN"):
            expr = self._expression()
            self._expect("RPAREN")
            return expr

        raise ParseError(
            f"Kifejezés helyett „{t.kind}” áll.",
            line=line,
        )


def parse(source: str, dialect: Dialect = "easy") -> ast.Program:
    return Parser(tokenize(source, dialect=dialect), dialect=dialect).parse()

"""Ideiglenes segéd: a korpusz + script feltöltése privát HF dataset-re (M9).
Használat:
    python scripts/_hf_feltoltes.py val tok script   # a kis fájlok
    python scripts/_hf_feltoltes.py train            # a 9 GB train.bin
    python scripts/_hf_feltoltes.py                   # mind
A mentett `hf auth login` bejelentkezést használja (write token).
"""
import sys
from pathlib import Path

from huggingface_hub import HfApi

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

REPO = "FSCAaron58/elpp-korpusz"
GYOKER = Path(__file__).resolve().parent.parent  # EL++ projekt gyökér

FAJLOK = {
    "train":  ("moodel_corpus/tokenized/train.bin", "train.bin"),
    "val":    ("moodel_corpus/tokenized/val.bin", "val.bin"),
    "tok":    ("moodel_corpus/tokenizalo.json", "tokenizalo.json"),
    "script": ("scripts/tanit_modell.py", "tanit_modell.py"),
}

api = HfApi()
api.create_repo(REPO, repo_type="dataset", private=True, exist_ok=True)
print("REPO OK (privat):", REPO, flush=True)

kulcsok = sys.argv[1:] or list(FAJLOK)
for k in kulcsok:
    helyi, nev = FAJLOK[k]
    ut = GYOKER / helyi
    meret = ut.stat().st_size / 1e9
    print(f"FELTOLTES indul: {nev} ({meret:.2f} GB)...", flush=True)
    api.upload_file(
        path_or_fileobj=str(ut), path_in_repo=nev,
        repo_id=REPO, repo_type="dataset",
    )
    print(f"KESZ: {nev}", flush=True)
print("MIND KESZ.", flush=True)

"""Szcenárió-generátor a KódTanár modellhez (KT.2).

Itt definiáljuk a tipikus "diák-állapotokat" — valósághű bemeneti
paraméter-kombinációkat, amelyekkel a tudat-modellt **kipróbáljuk**,
**tanítjuk** és **demonstráljuk**.

Minden szcenárió egy dict-et ad vissza, ami **mind a 19 paramétert**
kitölti. Egyetlen szcenárió = egy "pillanatfelvétel" a diákról a
programozási környezetben.

Használat:
    from elpp.parser import parse
    from elpp.tudat import TudatRuntime
    import kodtanar_scenarios as sc

    rt = TudatRuntime(parse(open("kodtanar.elpp").read()).statements[0])
    rt.észlel(**sc.frusztrált_diák())
    print(rt.magyarázd("frusztrált"))
"""

from __future__ import annotations


# Az `észlelés` blokk paraméterei a `kodtanar.elpp`-ben — referencia.
PARAMS = [
    "helyes_használat", "ismétlés", "kérdez",
    "próbálkozás_szám", "hiba_szám",
    "hiányzó_zárójel", "hibakód_szöveg", "sor_szám_megvan", "kód_hossz",
    "futás_megáll", "kivétel_van",
    "függvény_hossz", "indentálás", "ismétlődő_kód",
    "rövid_név", "értelmetlen_név", "mély_egymásba_ágyazás",
    "új_fogalom",
    "idő_eltelt",
]


def _alap() -> dict[str, float]:
    """Egy "semleges" diák-állapot — minden közepes 0.5 körül."""
    return {p: 0.5 for p in PARAMS}


# ─── 1. Kezdő, szintaktikai hibával ─────────────────────────────────────────


def kezdő_szintaktikai_hiba() -> dict[str, float]:
    s = _alap()
    s.update({
        "helyes_használat": 0.3,
        "kérdez": 0.4,
        "próbálkozás_szám": 0.3,
        "hiba_szám": 0.5,
        "hiányzó_zárójel": 0.9,
        "hibakód_szöveg": 0.8,
        "sor_szám_megvan": 1.0,
        "futás_megáll": 1.0,
        "kivétel_van": 0.0,
        "új_fogalom": 0.7,
        "idő_eltelt": 0.2,
    })
    return s


# ─── 2. Kezdő, runtime hibával ──────────────────────────────────────────────


def runtime_hiba_kezdő() -> dict[str, float]:
    s = _alap()
    s.update({
        "helyes_használat": 0.4,
        "próbálkozás_szám": 0.4,
        "hiba_szám": 0.6,
        "hiányzó_zárójel": 0.1,
        "hibakód_szöveg": 0.7,
        "sor_szám_megvan": 1.0,
        "futás_megáll": 1.0,
        "kivétel_van": 1.0,
        "új_fogalom": 0.6,
        "idő_eltelt": 0.3,
    })
    return s


# ─── 3. Frusztrált diák ─────────────────────────────────────────────────────


def frusztrált_diák() -> dict[str, float]:
    s = _alap()
    s.update({
        "helyes_használat": 0.2,
        "kérdez": 0.7,
        "próbálkozás_szám": 0.9,
        "hiba_szám": 0.8,
        "új_fogalom": 0.4,
        "idő_eltelt": 0.85,
    })
    return s


# ─── 4. Pihenni kellene ─────────────────────────────────────────────────────


def pihenni_kellene() -> dict[str, float]:
    s = frusztrált_diák()
    s.update({
        "idő_eltelt": 0.95,
        "hiba_szám": 0.85,
        "próbálkozás_szám": 0.95,
    })
    return s


# ─── 5. Kezdő, új fogalom ───────────────────────────────────────────────────


def kezdő_új_fogalom() -> dict[str, float]:
    s = _alap()
    s.update({
        "helyes_használat": 0.3,
        "ismétlés": 0.1,
        "kérdez": 0.6,
        "próbálkozás_szám": 0.2,
        "hiba_szám": 0.3,
        "új_fogalom": 0.95,
        "kód_hossz": 0.2,
        "idő_eltelt": 0.3,
    })
    return s


# ─── 6. Jól haladó diák ─────────────────────────────────────────────────────


def jól_halad_diák() -> dict[str, float]:
    s = _alap()
    s.update({
        "helyes_használat": 0.85,
        "ismétlés": 0.7,
        "kérdez": 0.2,
        "próbálkozás_szám": 0.4,
        "hiba_szám": 0.15,
        "hiányzó_zárójel": 0.0,
        "kivétel_van": 0.0,
        "futás_megáll": 0.0,
        "új_fogalom": 0.3,
        "idő_eltelt": 0.4,
    })
    return s


# ─── 7. Kódminőség problémák ────────────────────────────────────────────────


def kódminőség_problémák() -> dict[str, float]:
    s = _alap()
    s.update({
        "helyes_használat": 0.7,
        "hiba_szám": 0.1,
        "hiányzó_zárójel": 0.0,
        "kivétel_van": 0.0,
        "futás_megáll": 0.0,
        "függvény_hossz": 0.9,
        "indentálás": 0.4,
        "ismétlődő_kód": 0.8,
        "rövid_név": 0.8,
        "értelmetlen_név": 0.7,
        "mély_egymásba_ágyazás": 0.7,
        "kód_hossz": 0.85,
        "idő_eltelt": 0.5,
    })
    return s


# ─── 8. Nyugodt, haladó diák ────────────────────────────────────────────────


def nyugodt_haladó() -> dict[str, float]:
    s = _alap()
    s.update({
        "helyes_használat": 0.92,
        "ismétlés": 0.85,
        "kérdez": 0.15,
        "próbálkozás_szám": 0.3,
        "hiba_szám": 0.1,
        "függvény_hossz": 0.4,
        "indentálás": 0.95,
        "rövid_név": 0.2,
        "értelmetlen_név": 0.05,
        "mély_egymásba_ágyazás": 0.2,
        "új_fogalom": 0.2,
        "idő_eltelt": 0.45,
    })
    return s


# ─── Az összes szcenárió ────────────────────────────────────────────────────


ÖSSZES_SZCENÁRIÓ = {
    "kezdő_szintaktikai_hiba": kezdő_szintaktikai_hiba,
    "runtime_hiba_kezdő": runtime_hiba_kezdő,
    "frusztrált_diák": frusztrált_diák,
    "pihenni_kellene": pihenni_kellene,
    "kezdő_új_fogalom": kezdő_új_fogalom,
    "jól_halad_diák": jól_halad_diák,
    "kódminőség_problémák": kódminőség_problémák,
    "nyugodt_haladó": nyugodt_haladó,
}

"""Tanító-adat a szöveg-alapú KódTanárhoz (Phase 6 / M6.4).

Hibrid forrás (a Phase 6 tervben megbeszélve):
  • 20 KÉZZEL ÍRT mag — 4 archetípus × 5 (kezdő / frusztrált / haladó / trehány)
  • 30 SZINTETIKUS variáció — átlátható sablon-mutáció a magokból
  → összesen 50 tanító-példa.

A held-out értékelő-szett KÜLÖN fájlban van (kodtanar_szöveg_eval.py), hogy a
tudat tanítás közben SOHA ne lássa — becsületes mérés.

Minden példa egy dict:
    diák_kódja, diák_üzenete  — a NYERS szöveg-bemenetek
    valós_frusztrált, valós_kezdő, valós_gyenge  — a tutor-szakértő címkéi

Használat:
    import kodtanar_szöveg_adat as kd
    train = kd.tanító_adat()
    rt.fit(train, célok=kd.CÉLOK, epochok=40, tanulási_ráta=0.4)
"""

from __future__ import annotations

import random

# A tanulás-blokk cél-mappingje (kodtanar_szöveg.elpp `tanulás (...)` blokkból).
CÉLOK: dict[str, str] = {
    "frusztrált": "valós_frusztrált",
    "kezdő": "valós_kezdő",
    "gyenge_kódminőség": "valós_gyenge",
}


# ─────────────────────────────────────────────────────────────────────────────
# 20 KÉZZEL ÍRT MAG — 4 archetípus × 5
# ─────────────────────────────────────────────────────────────────────────────

# A) KEZDŐ, NYUGODTAN KÉRDEZ — rövid, egyszerű kód; alap-kérdés.
#    → kezdő magas, frusztrált alacsony, gyenge közepes
_KEZDŐ: list[dict] = [
    {
        "diák_kódja": "x = 5\nprint(x)",
        "diák_üzenete": "hogyan tudok kiíratni egy számot?",
        "valós_frusztrált": 0.15, "valós_kezdő": 0.92, "valós_gyenge": 0.45,
    },
    {
        "diák_kódja": "a = 3\nb = 4",
        "diák_üzenete": "most akkor mi a változó pontosan?",
        "valós_frusztrált": 0.1, "valós_kezdő": 0.95, "valós_gyenge": 0.5,
    },
    {
        "diák_kódja": "print('szia')",
        "diák_üzenete": "ezt most kezdtem tanulni, jó így?",
        "valós_frusztrált": 0.15, "valós_kezdő": 0.9, "valós_gyenge": 0.3,
    },
    {
        "diák_kódja": "szam = 10\nprint(szam)",
        "diák_üzenete": "mi a különbség a szöveg és a szám között?",
        "valós_frusztrált": 0.1, "valós_kezdő": 0.88, "valós_gyenge": 0.35,
    },
    {
        "diák_kódja": "n = 1\nn = n + 1",
        "diák_üzenete": "tudnál segíteni egy egyszerű példával?",
        "valós_frusztrált": 0.2, "valós_kezdő": 0.9, "valós_gyenge": 0.4,
    },
]

# B) FRUSZTRÁLT, HIBÁZIK — hibás/zavaros kód; ingerült üzenet felkiáltójellel.
#    → frusztrált magas
_FRUSZTRÁLT: list[dict] = [
    {
        "diák_kódja": "for i in range(10)\n    print(i)",
        "diák_üzenete": "nem megy semmi!!! már egy órája ezzel szenvedek!",
        "valós_frusztrált": 0.95, "valós_kezdő": 0.6, "valós_gyenge": 0.5,
    },
    {
        "diák_kódja": "if x = 5:\n  print(x)",
        "diák_üzenete": "miért nem fut le?! teljesen elakadtam!!",
        "valós_frusztrált": 0.92, "valós_kezdő": 0.6, "valós_gyenge": 0.55,
    },
    {
        "diák_kódja": "print(y)",
        "diák_üzenete": "megint hibát dob, nem értem mit akar tőlem!",
        "valós_frusztrált": 0.9, "valós_kezdő": 0.65, "valós_gyenge": 0.5,
    },
    {
        "diák_kódja": "while True\n  print(1)",
        "diák_üzenete": "feladom, ez sosem fog működni!!!",
        "valós_frusztrált": 0.96, "valós_kezdő": 0.55, "valós_gyenge": 0.55,
    },
    {
        "diák_kódja": "def f(:\n  return 0",
        "diák_üzenete": "már mindent kipróbáltam és semmi nem jó!",
        "valós_frusztrált": 0.9, "valós_kezdő": 0.5, "valós_gyenge": 0.5,
    },
]

# C) HALADÓ, NYUGODT — hosszabb, tiszta, strukturált kód; magabiztos üzenet.
#    → minden alacsony
_HALADÓ: list[dict] = [
    {
        "diák_kódja": (
            "def osszeg(szamok):\n"
            "    eredmeny = 0\n"
            "    for szam in szamok:\n"
            "        eredmeny += szam\n"
            "    return eredmeny"
        ),
        "diák_üzenete": "szerintem ez tiszta, de szívesen fogadok visszajelzést",
        "valós_frusztrált": 0.08, "valós_kezdő": 0.1, "valós_gyenge": 0.12,
    },
    {
        "diák_kódja": (
            "def maximum(lista):\n"
            "    legnagyobb = lista[0]\n"
            "    for elem in lista:\n"
            "        if elem > legnagyobb:\n"
            "            legnagyobb = elem\n"
            "    return legnagyobb"
        ),
        "diák_üzenete": "optimalizáltam a ciklust, mit gondolsz róla?",
        "valós_frusztrált": 0.05, "valós_kezdő": 0.08, "valós_gyenge": 0.1,
    },
    {
        "diák_kódja": (
            "def szuro(elemek, kuszob):\n"
            "    return [e for e in elemek if e > kuszob]"
        ),
        "diák_üzenete": "list comprehension-nel tömörebb lett, jó döntés?",
        "valós_frusztrált": 0.05, "valós_kezdő": 0.1, "valós_gyenge": 0.1,
    },
    {
        "diák_kódja": (
            "def faktorialis(n):\n"
            "    if n <= 1:\n"
            "        return 1\n"
            "    return n * faktorialis(n - 1)"
        ),
        "diák_üzenete": "rekurzióval oldottam meg, szerintem elegáns",
        "valós_frusztrált": 0.06, "valós_kezdő": 0.1, "valós_gyenge": 0.13,
    },
    {
        "diák_kódja": (
            "def parosak(szamok):\n"
            "    return [s for s in szamok if s % 2 == 0]"
        ),
        "diák_üzenete": "minden teszt zöld, csak véleményt kérek a stílusra",
        "valós_frusztrált": 0.05, "valós_kezdő": 0.07, "valós_gyenge": 0.1,
    },
]

# D) TREHÁNY KÓD, NYUGODT — rossz nevek, struktúra nélkül; semleges üzenet.
#    → gyenge_kódminőség magas, frusztrált alacsony
_TREHÁNY: list[dict] = [
    {
        "diák_kódja": "x = 5\ny = 3\nz = x+y\nprint(z)",
        "diák_üzenete": "működik, de tudom hogy nem szép",
        "valós_frusztrált": 0.2, "valós_kezdő": 0.5, "valós_gyenge": 0.9,
    },
    {
        "diák_kódja": "a=1\nb=2\nc=3\nd=a+b+c\nprint(d)",
        "diák_üzenete": "lefut rendesen, csak gyors megoldás kellett",
        "valós_frusztrált": 0.15, "valós_kezdő": 0.55, "valós_gyenge": 0.92,
    },
    {
        "diák_kódja": "x = input()\nx = int(x)\nx = x * 2\nprint(x)",
        "diák_üzenete": "ez kész van szerintem, megy",
        "valós_frusztrált": 0.15, "valós_kezdő": 0.5, "valós_gyenge": 0.85,
    },
    {
        "diák_kódja": "t = [1,2,3]\nq = 0\nfor i in t: q = q + i\nprint(q)",
        "diák_üzenete": "összeadja a listát, nekem így is jó",
        "valós_frusztrált": 0.2, "valós_kezdő": 0.45, "valós_gyenge": 0.88,
    },
    {
        "diák_kódja": "x = 0\nx = x + 1\nx = x + 1\nx = x + 1\nprint(x)",
        "diák_üzenete": "tudom hogy ciklussal jobb lenne, de most ennyi",
        "valós_frusztrált": 0.18, "valós_kezdő": 0.55, "valós_gyenge": 0.9,
    },
]

MAG: list[dict] = _KEZDŐ + _FRUSZTRÁLT + _HALADÓ + _TREHÁNY


# ─────────────────────────────────────────────────────────────────────────────
# SZINTETIKUS VARIÁCIÓ — átlátható sablon-mutáció a magokból
# ─────────────────────────────────────────────────────────────────────────────

# Üzenet-toldalékok archetípus-megőrzően (a címkét nem forgatják föl).
_FRUSZTRÁLT_TOLDALÉK = [" komolyan!", " már megint!", " segítsen valaki!!"]
_NYUGODT_TOLDALÉK = ["", " köszi", " előre is kösz", " üdv"]
# Kód-változó átnevezések (struktúra-megőrzők).
_ÁTNEVEZÉS = [
    ("x", "ertek"), ("a", "alfa"), ("szam", "n"), ("eredmeny", "osszeg"),
    ("q", "akk"), ("t", "lista"),
]


def _mutál(példa: dict, rng: random.Random) -> dict:
    """Egy magpéldából címke-megőrző variáció.

    A mutáció ÁTLÁTHATÓ: változó-átnevezés a kódban + archetípus-konzisztens
    üzenet-toldalék + apró címke-zaj. A frusztráltságot az üzenet jellege
    vezeti, ezért a toldalékot a `valós_frusztrált` szerint választjuk.
    """
    kód = példa["diák_kódja"]
    régi, új = rng.choice(_ÁTNEVEZÉS)
    kód = kód.replace(régi, új)

    üzenet = példa["diák_üzenete"]
    if példa["valós_frusztrált"] >= 0.6:
        üzenet = üzenet + rng.choice(_FRUSZTRÁLT_TOLDALÉK)
    else:
        üzenet = üzenet + rng.choice(_NYUGODT_TOLDALÉK)

    def zaj(v: float) -> float:
        return max(0.0, min(1.0, v + rng.gauss(0, 0.03)))

    return {
        "diák_kódja": kód,
        "diák_üzenete": üzenet,
        "valós_frusztrált": zaj(példa["valós_frusztrált"]),
        "valós_kezdő": zaj(példa["valós_kezdő"]),
        "valós_gyenge": zaj(példa["valós_gyenge"]),
    }


def tanító_adat(*, n_szintetikus: int = 30, seed: int = 42) -> list[dict]:
    """A teljes tanító-szett: 20 mag + n_szintetikus variáció, megkeverve.

    Reprodukálható a seeddel.
    """
    rng = random.Random(seed)
    adatok = [dict(p) for p in MAG]
    for _ in range(n_szintetikus):
        alap = rng.choice(MAG)
        adatok.append(_mutál(alap, rng))
    rng.shuffle(adatok)
    return adatok

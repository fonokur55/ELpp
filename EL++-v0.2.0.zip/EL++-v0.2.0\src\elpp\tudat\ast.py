"""AST node-ok a tudat alrendszerhez.

Külön fájlban, hogy az AI-rész vizuálisan elkülönüljön az alap-nyelvtől
(lásd Phase 1 implementációs döntés). A Program.statements futás közben
ezeket a típusokat is tartalmazhatja — az alap `ast.Stmt` Union nem
sorolja fel őket, de a dinamikus dispatch működik.

Phase 1 — M1 (csontváz):
    TudatDecl (legfelső), AreaDecl (csoport),
    BeliefDecl / WeightDecl / GoalDecl (atomi elemek).

Phase 1 — M2 (tényezők):
    4 új factor-típus: NeuralFactor, RuleFactor, BeliefFactor, GoalFactor.
    BeliefDecl kibővítve opcionális `factors` mezővel
    (`hiedelem esni_fog jön: tényező ...`).

Phase 1 — M3 (élet):
    PerceptionBlock — `észlelés (params): ... kész`. Csak tudat-szinten
    (területbe NEM kerülhet), és csak a paraméter-szignatúrát definiálja —
    a body parse-ol, de futása M5+ téma.

Phase 1 — M4 (önreflexió):
    ReflectionBlock — `reflexió "<címke>": ... kész`. Body: `magyarázd <név>`
    statementek listája. CSAK tudat-szinten. Futtatás: rt.reflektál(címke).
    ExplainStmt — `magyarázd <belief_name>`.

Phase 1 — M5 (tanulás):
    TrainingBlock — `tanulás[ (params)]: ... kész`. Body M5-ben parse-ol
    de nem fut — a Python API (`rt.tanulj(**targets)`) csinálja a
    tanulást közvetlenül. Placeholder a későbbi nyelvi tanulás-szintaxishoz.
    LearnStmt — `tanulj <belief_name> -> <expr>`.

Phase 2 — M2.1 (hipotetikus):
    WhatIfBlock — `mi_lenne_ha "címke" (felülírások): ... kész`. Body:
    csak `magyarázd` statementek (mint reflexió). A felülírások név=érték
    párok (súly/context/cél/hiedelem-override). Runtime: PURE — snapshot,
    apply, recompute, restore.
    WhatIfOverride — egy név=érték pár.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Union

if TYPE_CHECKING:
    from elpp import ast as base_ast
    from elpp.ast import Stmt as BaseStmt


# ─────────────────────────────────────────────────────────────────────────────
# Tényezők (M2) — egy hiedelem bizonyítéki csatornái
# ─────────────────────────────────────────────────────────────────────────────


@dataclass
class NeuralFactor:
    """`tényező neurális <expression>` — tenzor-/számítás-alapú bizonyíték.

    Az `expr` egy tetszőleges kifejezés a base AST-ből (pl. `W * x + b`).
    A futtató ezt evaluálja és [0, 1] közé klippeli (M2-ben; M3+ sigmoid).
    """

    expr: "base_ast.Expr"
    ellen: bool = False
    line: int = 0


@dataclass
class RuleFactor:
    """`tényező szabály ha <feltétel> akkor <bizonyosság>` — logikai szabály.

    Ha a feltétel igaz (kifejezés > 0.5), a `confidence` értéke számolódik
    és kerül be a hiedelem aggregálásába. Ha hamis, 0 a contribution.
    """

    condition: "base_ast.Expr"
    confidence: "base_ast.Expr"
    ellen: bool = False
    line: int = 0


@dataclass
class BeliefFactor:
    """`tényező hiedelem <név>` — másik hiedelem értékének átfolyatása.

    Csendes függőség: ha a hivatkozott hiedelem értéke változik, jelen
    hiedelem újraszámolásakor reflektálódik. M3-ban a reaktív gráf ezt
    explicit függőségként követi.
    """

    belief_name: str
    ellen: bool = False
    line: int = 0


@dataclass
class GoalFactor:
    """`tényező cél <név>` — egy cél hatása a hiedelemre (meta-motiváció).

    A 4. tényező-típus, a Phase 1 / 2. döntés *egyedi* eleme:
    "azért gondolom, hogy X igaz, mert hinni benne segít elérni Y célt".

    M2-ben placeholder-kontribúció (0.1 × cél.aktiváció). A *tanult*
    goal-súly M5-ben jön — addig az architektúra már a helyén van,
    a kalibráció lesz pontosabb.
    """

    goal_name: str
    ellen: bool = False
    line: int = 0


@dataclass
class SzövegFactor:
    """`tényező szöveg(<bemenet>[, dim=N][, érzékeny=igen/nem])` — Phase 6 / M6.3.

    A paradigma 5. tényező-típusa: NYERS SZÖVEGET olvas (kód, üzenet,
    dokumentum), nem előre kiszámolt számot. A `bemenet` egy észlelési
    paraméter neve (pl. `diák_kódja`), aminek értéke egy string a context-ben.

    A futtató a szöveget tokenizálja → beágyazza → átlag-poolozza → lineáris
    réteg + sigmoid → [0,1] bizonyíték. A tanult állapot (szótár + kódoló) a
    runtime-ban él, nem az AST-ben (mint a rule_weight/goal_weight).

    Mezők:
        input_name: a szöveg-bemenet neve (észlelési paraméter).
        dim: a beágyazás dimenziója (D2 default 64).
        case_sensitive: kis/nagybetű-érzékenység (finomítás #1; kódhoz igen).
    """

    input_name: str
    dim: int = 64
    case_sensitive: bool = True
    ellen: bool = False
    line: int = 0


Factor = Union[NeuralFactor, RuleFactor, BeliefFactor, GoalFactor, SzövegFactor]


# ─────────────────────────────────────────────────────────────────────────────
# Tudat-elemek (M1 + M2 bővítés)
# ─────────────────────────────────────────────────────────────────────────────


@dataclass
class BeliefDecl:
    """`hiedelem esni_fog` — deklarál egy hiedelem-slotot a tudatban.

    M1: csak `name` (üres `factors` lista).
    M2: opcionális `factors` lista — `hiedelem X jön: tényező ... kész`.
    Ha üres a lista, a hiedelem confidence-e default 0.5 (nincs tudás).
    """

    name: str
    factors: list[Factor] = field(default_factory=list)
    line: int = 0


@dataclass
class WeightDecl:
    """`súly W` vagy `súly W : tenzor[n, m]` — deklarál egy tanítható paramétert.

    M1: csak a név (skalár).
    M4.1: opcionális `tensor_shape` annotáció → a runtime kis random init-tel
    inicializál egy ElTensor-t a megadott alakkal. Annotáció nélkül a súly
    skalár marad (visszafelé kompatibilis).

    Példa:
      `súly W`                  → skalár, gauss 0.1 szórással
      `súly W : tenzor[3]`      → 3-elemű vektor, gauss 0.01 szórással
      `súly W : tenzor[2, 4]`   → 2×4 mátrix, gauss 0.01 szórással
    """

    name: str
    tensor_shape: list[int] | None = None
    line: int = 0


@dataclass
class GoalDecl:
    """`cél pontos_jóslat` — deklarál egy preferált állapotot / motivációt.

    A célok a 4. tényező-típus (GoalFactor) alapja. M2-ben a cél
    aktivációja default 1.0; M5-ben tanulható, M3-ban kapcsolódik
    a területaktivációhoz.
    """

    name: str
    line: int = 0


# ─────────────────────────────────────────────────────────────────────────────
# Észlelés (M3) — a tudat külvilág-interfésze
# ─────────────────────────────────────────────────────────────────────────────


@dataclass
class PerceptionBlock:
    """`észlelés (param1, param2, ...): ... kész` — a tudat bemeneti kapuja.

    A paraméterek mondják meg, milyen név alatt érkeznek a külső bemenetek
    (`rt.észlel(param1=..., param2=...)`). A `body` M3-ban PARSE-OL, de
    nem fut le — a runtime automatikusan beállítja a context-et és reaktívan
    újraszámolja az érintett hiedelmeket.

    PerceptionBlock CSAK tudat-szinten lehet (területbe NEM kerülhet),
    mert az észlelés a tudat egésze és a világ közti határ.

    M5: a body futtatása + tanulási hookok érkeznek ide.
    """

    params: list[str]
    body: list["BaseStmt"] = field(default_factory=list)
    line: int = 0


# ─────────────────────────────────────────────────────────────────────────────
# Önreflexió (M4) — a tudat magyarázza önmagát
# ─────────────────────────────────────────────────────────────────────────────


@dataclass
class ExplainStmt:
    """`magyarázd <belief_name>` — egy hiedelem magyarázat-kérése.

    Csak `reflexió` blokkon belül használható (Phase 1 / M4 hatókör).
    Futtatáskor: az adott hiedelem aktuális confidence-ét és tényezőit
    Explanation objektumba csomagolja.
    """

    belief_name: str
    line: int = 0


@dataclass
class ReflectionBlock:
    """`reflexió "<címke>": ... kész` — önreflexió-blokk.

    A `label` egy sztring-azonosító, amellyel a felhasználó később futtatja
    (`rt.reflektál("miért gondolod?")`). Ugyanazon a tudaton belül több
    reflexió létezhet különböző címkékkel.

    A body M4-ben CSAK `magyarázd` statementeket fogad el.

    ReflectionBlock CSAK tudat-szinten lehet (területbe nem) — a tudat
    egészéről szól, nem egy területről.
    """

    label: str
    body: list[ExplainStmt] = field(default_factory=list)
    line: int = 0


# ─────────────────────────────────────────────────────────────────────────────
# Tanulás (M5) — a tudat frissíti paramétereit hiba alapján
# ─────────────────────────────────────────────────────────────────────────────


@dataclass
class LearnStmt:
    """`tanulj <belief_name> -> <expr>` — egy tanítási cél deklarációja.

    M5-ben a body NEM fut le — a Python API (`rt.tanulj`) végzi a tanulást
    közvetlenül. Ez a node a *jövőre* van: későbbi fázisok majd nyelvi
    szinten is futtathatóvá teszik.
    """

    belief_name: str
    target_expr: "base_ast.Expr"
    line: int = 0


@dataclass
class TrainingBlock:
    """`tanulás[ (params)]: ... kész` — tanítási konfiguráció / hook.

    M5-ben a syntax PARSE-OL, de a body NEM fut — a tényleges tanítás
    a Python API-n keresztül történik (`rt.tanulj(**targets)`).
    A blokk jelenléte a *szándékot* deklarálja ("ezt a tudatot tanítani
    fogjuk"); a future fázisok ezt fognak nyelvi szinten futtatni.

    TrainingBlock CSAK tudat-szinten lehet (területbe nem).
    """

    params: list[str] = field(default_factory=list)
    body: list[LearnStmt] = field(default_factory=list)
    line: int = 0


# ─────────────────────────────────────────────────────────────────────────────
# Hipotetikus kérdezés (Phase 2 / M2.1) — a tudat alternatívákat képzel
# ─────────────────────────────────────────────────────────────────────────────


@dataclass
class WhatIfOverride:
    """Egy név=érték pár egy `mi_lenne_ha` blokk felülírás-listájában.

    A `name` lehet: súly, context-kulcs, cél, vagy hiedelem-név. A runtime
    keresési sorrendben oldja fel (lásd `_apply_overrides`).
    A hiedelem-override BYPASS a tényezőkön — a hiedelem fix marad a
    hipotetikus számolás alatt.
    """

    name: str
    value_expr: "base_ast.Expr"
    line: int = 0


@dataclass
class WhatIfBlock:
    """`mi_lenne_ha "<címke>" (név1 = érték1, név2 = érték2, ...): ... kész`

    Nevesített kontrafaktuális forgatókönyv. A felhasználó később futtatja
    a Python API-n: `rt.mi_lenne_ha("címke") → list[Explanation]`.

    A body M2.1-ben CSAK `magyarázd` statementeket fogad el (mint reflexió).
    A futtatás PURE: snapshot → apply overrides → recompute → action →
    restore.

    WhatIfBlock CSAK tudat-szinten lehet (területbe nem) — a tudat egészéről
    szól.
    """

    label: str
    overrides: list[WhatIfOverride] = field(default_factory=list)
    body: list[ExplainStmt] = field(default_factory=list)
    line: int = 0


# AreaDecl, TudatDecl, PerceptionBlock, ReflectionBlock, TrainingBlock,
# WhatIfBlock előre-hivatkozása.
TudatItem = Union[
    BeliefDecl, WeightDecl, GoalDecl, "AreaDecl",
    PerceptionBlock, ReflectionBlock, TrainingBlock, WhatIfBlock,
    "KifejezésBlokk",
]


@dataclass
class KifejezésBejegyzés:
    """Egy sor egy `kifejezés` blokkban: `<szerep> <sáv>: "darab", ...`.

    A `szerep` (állítás/indok/ellenpont/javaslat/kérdés/nyugtázás) és a `sáv`
    (magas/közepes/alacsony/bizonytalan) határozza meg, mikor használhatók a
    `darabok` — a generáló ezekből KOMPONÁLJA a választ (Phase 7).
    """

    szerep: str
    sáv: str
    darabok: list[str]
    line: int = 0


@dataclass
class KifejezésBlokk:
    """`kifejezés <hiedelem>: <szerep> <sáv>: "darab", ... kész` — Phase 7 / M7.2.

    A tudat „beszéd-palettája" egy hiedelemhez: komponálható, RAGOZOTT felszíni
    darabok szerep+sáv szerint. NEM kész mondatok — a generáló rakja össze őket
    a hiedelem-állapotból. CSAK tudat-szinten (mint a reflexió/tanulás).
    """

    belief_name: str
    bejegyzések: list[KifejezésBejegyzés] = field(default_factory=list)
    line: int = 0


@dataclass
class AreaDecl:
    """`terület felhőkép: ... kész` — összetartozó tudat-elemek csoportja.

    A területek a Phase 1 / 4. döntés (futtatási modell) alapelemei:
    szelektív aktiváció történik területenként — M3-ban implementálva.
    """

    name: str
    body: list[TudatItem] = field(default_factory=list)
    line: int = 0


@dataclass
class TudatDecl:
    """`tudat IdőjárásBecslő: ... kész` — egy tudat blokk legfelső szintje.

    A `body` közvetlenül tartalmazhat atomi deklarációkat
    (BeliefDecl / WeightDecl / GoalDecl), AreaDecl csoportokat,
    és PerceptionBlock(okat) (M3+).
    """

    name: str
    body: list[TudatItem] = field(default_factory=list)
    line: int = 0

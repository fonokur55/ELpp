"""AST node-ok az EL++ nyelvhez."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Union

# --- Kifejezések ---


@dataclass
class Number:
    value: float
    line: int = 0


@dataclass
class String:
    value: str
    line: int = 0


@dataclass
class Bool:
    value: bool
    line: int = 0


@dataclass
class Var:
    name: str
    line: int = 0


@dataclass
class Unary:
    op: str  # NOT, MINUS
    operand: Expr
    line: int = 0


@dataclass
class Binary:
    op: str
    left: Expr
    right: Expr
    line: int = 0


@dataclass
class Call:
    name: str
    args: list[Expr]
    line: int = 0


@dataclass
class ListLit:
    elements: list[Expr]
    line: int = 0


@dataclass
class DictLit:
    pairs: list[tuple[Expr, Expr]]
    line: int = 0


@dataclass
class Index:
    target: Expr
    index: Expr
    line: int = 0


Expr = Union[
    Number, String, Bool, Var, Unary, Binary,
    Call, ListLit, DictLit, Index,
]

# --- Utasítások ---


@dataclass
class Let:
    name: str
    value: Expr
    line: int = 0


@dataclass
class Print:
    values: list[Expr]
    line: int = 0


@dataclass
class If:
    condition: Expr
    then_body: list[Stmt]
    else_body: list[Stmt] | None = None
    line: int = 0


@dataclass
class While:
    condition: Expr
    body: list[Stmt]
    line: int = 0


@dataclass
class Def:
    name: str
    params: list[str]
    body: list[Stmt]
    line: int = 0


@dataclass
class Return:
    value: Expr | None = None
    line: int = 0


@dataclass
class For:
    var: str
    iterable: Expr
    body: list[Stmt]
    line: int = 0


@dataclass
class Import:
    module: str
    line: int = 0


@dataclass
class Assume:
    claim: str
    confidence: Expr
    line: int = 0


@dataclass
class Rule:
    condition: Expr
    conclusion: str
    confidence: Expr
    line: int = 0


@dataclass
class Query:
    claim: str
    line: int = 0


@dataclass
class GraphNodeDef:
    node_id: str
    op: str
    inputs: list[str]
    cost: float = 1.0
    line: int = 0


@dataclass
class RunGraph:
    target: str
    line: int = 0


@dataclass
class Train:
    target: str
    epochs: Expr
    loss: str
    line: int = 0


Stmt = Union[
    Let, Print, If, While, Def, Return, For, Import,
    Assume, Rule, Query, GraphNodeDef, RunGraph, Train,
]


@dataclass
class Program:
    statements: list[Stmt] = field(default_factory=list)
    dialect: str = "easy"

#!/usr/bin/env python3
"""Korpusz-tokenizáló + shard-készítő — Phase 8 / M9 (adat-pipeline).

A `moodel_corpus/` gzippelt JSONL-jeiből:
  1. BPE-tokenizálót TANÍT (HF `tokenizers`, ~32k vocab) — ez a produkciós tokenizáló.
  2. A korpuszt TOKENIZÁLJA bináris shardokká (`train.bin`/`val.bin`, uint16,
     nanoGPT-formátum) — ez a transzformer-tanítás bemenete.

CPU-n fut (a `tokenizers` Rust-backed → gyors). A drága GPU-időt NEM tokenizálásra
költjük: itt készülnek a shardok, amiket a bérelt GPU-ra töltünk fel.

Használat:
    python scripts/korpusz_tokenizalo.py tanit            # tokenizáló tanítása
    python scripts/korpusz_tokenizalo.py tokenizal        # shardok készítése
    python scripts/korpusz_tokenizalo.py minta            # gyors próba kis mintán
"""

from __future__ import annotations

import gzip
import json
import sys
from pathlib import Path
from typing import Iterator

import numpy as np

ROOT = Path(__file__).parent.parent
KORPUSZ_DIR = ROOT / "moodel_corpus"
KIMENET_DIR = ROOT / "moodel_corpus" / "tokenized"
TOKENIZÁLÓ_ÚT = ROOT / "moodel_corpus" / "tokenizalo.json"

VOCAB_MÉRET = 32_000
SPECIÁLIS = ["<pad>", "<unk>", "<bos>", "<eos>"]
VAL_ARÁNY = 0.005   # 0.5% validációra


def _szöveg_iterátor(
    korpusz_dir: Path, *, max_dok: int | None = None
) -> Iterator[str]:
    """A korpusz összes (gzippelt JSONL) dokumentumának szövege, lustán."""
    db = 0
    for fn in sorted(korpusz_dir.glob("*.jsonl.gz")):
        with gzip.open(fn, "rt", encoding="utf-8") as f:
            for sor in f:
                try:
                    t = json.loads(sor).get("text", "")
                except json.JSONDecodeError:
                    continue
                if t:
                    yield t
                    db += 1
                    if max_dok is not None and db >= max_dok:
                        return


def tanits_tokenizalo(
    *, vocab_méret: int = VOCAB_MÉRET, max_dok: int | None = None,
    kimenet: Path = TOKENIZÁLÓ_ÚT,
):
    """BPE-tokenizáló betanítása a korpuszon (byte-level, vocab ~32k)."""
    from tokenizers import Tokenizer, decoders, models, pre_tokenizers, trainers

    tok = Tokenizer(models.BPE(unk_token="<unk>"))
    tok.pre_tokenizer = pre_tokenizers.ByteLevel(add_prefix_space=False)
    tok.decoder = decoders.ByteLevel()
    trainer = trainers.BpeTrainer(
        vocab_size=vocab_méret,
        special_tokens=SPECIÁLIS,
        initial_alphabet=pre_tokenizers.ByteLevel.alphabet(),
    )
    print(f"Tokenizáló tanítása (vocab={vocab_méret}, max_dok={max_dok})...", flush=True)
    tok.train_from_iterator(_szöveg_iterátor(KORPUSZ_DIR, max_dok=max_dok), trainer=trainer)
    kimenet.parent.mkdir(parents=True, exist_ok=True)
    tok.save(str(kimenet))
    print(f"Mentve: {kimenet} | vocab: {tok.get_vocab_size()}", flush=True)
    return tok


def tokenizald(*, max_dok: int | None = None):
    """A korpusz tokenizálása uint16 shardokká (train.bin / val.bin)."""
    from tokenizers import Tokenizer

    tok = Tokenizer.from_file(str(TOKENIZÁLÓ_ÚT))
    eos_id = tok.token_to_id("<eos>")
    KIMENET_DIR.mkdir(parents=True, exist_ok=True)

    rng = np.random.default_rng(0)
    train_f = open(KIMENET_DIR / "train.bin", "wb")
    val_f = open(KIMENET_DIR / "val.bin", "wb")
    train_tok = val_tok = 0
    try:
        for t in _szöveg_iterátor(KORPUSZ_DIR, max_dok=max_dok):
            ids = tok.encode(t).ids + [eos_id]          # dokumentum-határ jelölés
            arr = np.array(ids, dtype=np.uint16)
            if rng.random() < VAL_ARÁNY:
                arr.tofile(val_f); val_tok += len(arr)
            else:
                arr.tofile(train_f); train_tok += len(arr)
    finally:
        train_f.close(); val_f.close()
    print(f"Kész: train={train_tok:,} token, val={val_tok:,} token → {KIMENET_DIR}",
          flush=True)


def minta():
    """Gyors próba: tokenizáló tanítása kis mintán + körút-ellenőrzés."""
    tok = tanits_tokenizalo(vocab_méret=2000, max_dok=2000,
                            kimenet=KORPUSZ_DIR / "tokenizalo_minta.json")
    teszt = "A függvény a harmadik sorban hibás, mert hiányzik a kettőspont."
    ids = tok.encode(teszt).ids
    vissza = tok.decode(ids)
    print(f"Teszt-mondat: {teszt}")
    print(f"Tokenek ({len(ids)} db): {ids[:20]}...")
    print(f"Visszafejtve: {vissza}")


if __name__ == "__main__":
    parancs = sys.argv[1] if len(sys.argv) > 1 else "minta"
    if parancs == "tanit":
        tanits_tokenizalo()
    elif parancs == "tokenizal":
        tokenizald()
    else:
        minta()

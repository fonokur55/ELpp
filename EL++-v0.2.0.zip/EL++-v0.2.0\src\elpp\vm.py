"""Bytecode VM – alapértelmezett futtató."""

from __future__ import annotations

import sys
from typing import Any

from elpp import ast
from elpp.builtins.tensor import TENSOR_BUILTINS
from elpp.bytecode import Chunk, Op
from elpp.compiler import compile_program
from elpp.parser import parse
from elpp.synonyms import Dialect


class VM:
    def __init__(self, stdout: Any = None):
        self.stdout = stdout if stdout is not None else sys.stdout
        self.stack: list[Any] = []
        self.env: dict[str, Any] = {}
        self._running = True
        for name, fn in TENSOR_BUILTINS.items():
            self.env[name] = fn

    def run_chunk(self, chunk: Chunk) -> None:
        ip = 0
        while ip < len(chunk.code) and self._running:
            instr = chunk.code[ip]
            ip += 1
            op = instr.op
            arg = instr.arg

            if op == Op.CONST:
                self.stack.append(chunk.constants[arg])
            elif op == Op.LOAD:
                if arg not in self.env:
                    raise RuntimeError(f"Nincs változó: {arg}")
                self.stack.append(self.env[arg])
            elif op == Op.STORE:
                self.env[arg] = self.stack.pop()
            elif op == Op.ADD:
                b, a = self._pop2()
                self.stack.append(self._num(a) + self._num(b) if not isinstance(a, str) else str(a) + str(b))
            elif op == Op.SUB:
                b, a = self._pop2()
                self.stack.append(self._num(a) - self._num(b))
            elif op == Op.MUL:
                b, a = self._pop2()
                self.stack.append(self._num(a) * self._num(b))
            elif op == Op.DIV:
                b, a = self._pop2()
                self.stack.append(self._num(a) / self._num(b))
            elif op == Op.EQ:
                b, a = self._pop2()
                self.stack.append(a == b)
            elif op == Op.NE:
                b, a = self._pop2()
                self.stack.append(a != b)
            elif op == Op.LT:
                b, a = self._pop2()
                self.stack.append(a < b)
            elif op == Op.GT:
                b, a = self._pop2()
                self.stack.append(a > b)
            elif op == Op.LE:
                b, a = self._pop2()
                self.stack.append(a <= b)
            elif op == Op.GE:
                b, a = self._pop2()
                self.stack.append(a >= b)
            elif op == Op.AND:
                b, a = self._pop2()
                self.stack.append(bool(a) and bool(b))
            elif op == Op.OR:
                b, a = self._pop2()
                self.stack.append(bool(a) or bool(b))
            elif op == Op.NOT:
                self.stack.append(not bool(self.stack.pop()))
            elif op == Op.NEG:
                self.stack.append(-self._num(self.stack.pop()))
            elif op == Op.PRINT:
                n = arg or 1
                vals = [self.stack.pop() for _ in range(n)][::-1]
                print(" ".join(self._fmt(v) for v in vals), file=self.stdout)
            elif op == Op.JMP:
                ip = arg
            elif op == Op.JMP_IF_FALSE:
                if not self._truthy(self.stack.pop()):
                    ip = arg
            elif op == Op.CALL:
                name, argc = arg
                args = [self.stack.pop() for _ in range(argc)][::-1]
                fn = self.env.get(name)
                if callable(fn) and name in TENSOR_BUILTINS:
                    self.stack.append(fn(args))
                else:
                    raise RuntimeError(f"Hívható nem található: {name}")
            elif op == Op.RETURN:
                self._running = False
            elif op == Op.HALT:
                break

    def run_source(self, source: str, dialect: Dialect = "easy") -> None:
        program = parse(source, dialect=dialect)
        chunk = compile_program(program)
        self.run_chunk(chunk)

    @staticmethod
    def _num(v: Any) -> float:
        return float(v)

    @staticmethod
    def _truthy(v: Any) -> bool:
        if isinstance(v, (int, float)):
            return v != 0
        if isinstance(v, str):
            return len(v) > 0
        return bool(v)

    @staticmethod
    def _fmt(v: Any) -> str:
        if isinstance(v, float) and v == int(v):
            return str(int(v))
        return str(v)

    def _pop2(self) -> tuple[Any, Any]:
        b = self.stack.pop()
        a = self.stack.pop()
        return b, a


def run_vm_source(source: str, dialect: Dialect = "easy", stdout: Any = None) -> VM:
    vm = VM(stdout=stdout)
    vm.run_source(source, dialect=dialect)
    return vm

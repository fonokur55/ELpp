"""Kind-metaadat: runtime megkülönböztetés a tudat-elemek között.

Phase 1 / 3. döntés (lásd memory/project_phase1_typesystem.md):
    A tudat-on belüli értékek explicit kind-ot kapnak. A futtató tudja,
    melyik mit jelent — ez az önreflexió alapja. Egy `hiedelem` és egy
    `súly` lehet ugyanúgy számszerű, de **másképpen viselkedik** (más
    tanulási mechanizmus, más szerepe a reflexióban, stb.).

A `Kind` enum egyetlen regisztráló helye az AI-típusoknak — új típust
egyetlen sorral lehet hozzáadni (lásd Phase 1 / 2. döntés:
"belső bővíthetőség"). A felhasználói szintű új-kind-definiálás
Phase 3+ téma.
"""

from __future__ import annotations

from enum import Enum


class Kind(str, Enum):
    """A tudat-elemek lehetséges kindjei.

    Phase 1 / M1: csak az alapdeklarációkhoz tartozó kindek vannak itt.
    Phase 1 / M2-M5 bővíti: FACTOR, EXPECTATION, RULE, REFLECTION, stb.
    """

    BELIEF = "hiedelem"
    WEIGHT = "súly"
    GOAL = "cél"


def kind_name(k: Kind) -> str:
    """Olvasható magyar név egy kindhez — hibaüzenetekhez."""
    return k.value

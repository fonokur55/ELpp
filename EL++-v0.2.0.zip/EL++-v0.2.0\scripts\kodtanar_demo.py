#!/usr/bin/env python3
"""KódTanár — Interaktív bemutató CLI (KT.4).

Egy diáknak segítő programozási tutor tudat-modell demója.
Indítás:
    python scripts/kodtanar_demo.py

Funkciók:
    • 8 előre definiált diák-szcenárió kipróbálása
    • Magyarázat a predikciók mögött (`magyarázd`)
    • Reflexió-blokk futtatása
    • Modell tanítása újra
    • Tanulási görbe vizualizációja
    • Memória (események) lekérdezése
    • Állapot mentése
"""

from __future__ import annotations

import sys
from pathlib import Path

# Windows console UTF-8-ra állítása (Unicode box-drawing miatt)
if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    except (AttributeError, OSError):
        pass  # régi Python-on vagy nem-tty-n

# A scripts/ alól is működjön
ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "examples" / "ai"))

from elpp.parser import parse  # noqa: E402
from elpp.tudat import TudatDecl, TudatRuntime  # noqa: E402

import kodtanar_data as kd  # noqa: E402
import kodtanar_scenarios as sc  # noqa: E402


KODTANAR_PATH = ROOT / "examples" / "ai" / "kodtanar.elpp"
MENTÉS_ÚTVONAL = ROOT / "scripts" / "kodtanar_state.pkl"


# ─── Kiírás-segédek ─────────────────────────────────────────────────────────


def fej(címe: str) -> None:
    sáv = "═" * (len(címe) + 4)
    print(f"\n╔{sáv}╗")
    print(f"║  {címe}  ║")
    print(f"╚{sáv}╝")


def alfej(címe: str) -> None:
    print(f"\n── {címe} " + "─" * max(0, 60 - len(címe) - 4))


# ─── Modell betöltése / létrehozása ─────────────────────────────────────────


def betölt_vagy_készít_modellt() -> TudatRuntime:
    """Ha van mentett állapot → betölti. Egyébként újra-tanítja."""
    if MENTÉS_ÚTVONAL.exists():
        print(f"✓ Mentett modell betöltve: {MENTÉS_ÚTVONAL.name}")
        return TudatRuntime.betölt(MENTÉS_ÚTVONAL)

    print("• Új modell tanítása (mentett állapot nincs)...")
    src = KODTANAR_PATH.read_text(encoding="utf-8")
    decl = next(s for s in parse(src).statements if isinstance(s, TudatDecl))
    rt = TudatRuntime(decl, seed=42)
    train = kd.generál_tanító_adatot(n_per_szcenárió=10, seed=42)
    eredmény = rt.fit(train, célok=kd.CÉLOK, epochok=5, tanulási_ráta=0.3)
    print(f"✓ Tanítás kész: {eredmény['iterációk']} iteráció")
    return rt


# ─── Menü-műveletek ─────────────────────────────────────────────────────────


def válassz_szcenáriót() -> dict[str, float] | None:
    """Felhasználói menüből szcenárió-választás."""
    alfej("Válassz egy diák-szcenáriót")
    nevek = list(sc.ÖSSZES_SZCENÁRIÓ.keys())
    for i, név in enumerate(nevek, 1):
        print(f"  {i}. {név}")
    print("  0. Vissza")
    válasz = input("\nVálasz: ").strip()
    if not válasz.isdigit():
        return None
    idx = int(válasz)
    if idx == 0 or idx > len(nevek):
        return None
    return sc.ÖSSZES_SZCENÁRIÓ[nevek[idx - 1]]()


def kiír_predikciókat(rt: TudatRuntime) -> None:
    """Az összes hiedelem aktuális confidence-e."""
    alfej("Az összes hiedelem confidence-e")
    sorok = []
    for név in rt.beliefs:
        conf = rt.compute_belief(név)
        terület = rt._area_of.get(név) or "top-level"
        sorok.append((név, conf, terület))
    sorok.sort(key=lambda s: -s[1])
    print(f"\n  {'Hiedelem':<35} {'Confidence':>12}   Terület")
    print("  " + "─" * 70)
    for név, conf, terület in sorok:
        bar = "█" * int(conf * 20)
        print(f"  {név:<35} {conf:>10.3f}   {terület}  {bar}")


def magyarázat_részletesen(rt: TudatRuntime) -> None:
    """Egy konkrét hiedelem részletes magyarázata."""
    alfej("Magyarázat egy hiedelemre")
    nevek = sorted(rt.beliefs.keys())
    for i, név in enumerate(nevek, 1):
        print(f"  {i:2}. {név}")
    válasz = input("\nMelyik hiedelmet magyarázzam? Szám: ").strip()
    if not válasz.isdigit():
        return
    idx = int(válasz)
    if not 1 <= idx <= len(nevek):
        return
    expl = rt.magyarázd(nevek[idx - 1])
    print("\n" + str(expl))


def reflektálás(rt: TudatRuntime) -> None:
    alfej('Reflexió: "miért gondolod?"')
    for expl in rt.reflektál("miért gondolod?"):
        print()
        print(expl)
        print("─" * 60)


def tanítsd_újra(rt: TudatRuntime) -> None:
    alfej("Tanítás újra (5 epoch, 80 példa)")
    train = kd.generál_tanító_adatot(n_per_szcenárió=10)
    eredmény = rt.fit(train, célok=kd.CÉLOK, epochok=5, tanulási_ráta=0.3)
    print(f"\n✓ {eredmény['iterációk']} iteráció kész")
    print(f"  Végső átlagos abszolút hiba: {eredmény['végső_átlag_abs_hiba']:.4f}")


def tanulási_görbe(rt: TudatRuntime) -> None:
    alfej("Tanulási görbe")
    if rt.emlékek_száma() == 0:
        print("(Még nincs tanulás-emlék — indíts újra tanítást.)")
        return
    # Mind a tanult hiedelmekre külön
    for belief_név in kd.CÉLOK.keys():
        szöveg = rt.tanulási_görbe_szöveg(hiedelem=belief_név, max_szélesség=40)
        print(f"  {szöveg}")


def memória(rt: TudatRuntime) -> None:
    alfej("Memória — utolsó 10 esemény")
    emlékek = rt.emlékek(n=10)
    if not emlékek:
        print("(Üres.)")
        return
    for e in emlékek:
        belief_rész = f" [{e.belief_name}]" if e.belief_name else ""
        print(f"  step {e.step:>4}  {e.típus:<12}{belief_rész}")


def mentsd_el(rt: TudatRuntime) -> None:
    rt.ments(MENTÉS_ÚTVONAL)
    print(f"\n✓ Modell mentve: {MENTÉS_ÚTVONAL}")


# ─── Fő menü ─────────────────────────────────────────────────────────────────


def fő_menü(rt: TudatRuntime) -> None:
    aktuális_szcenárió_név: str = "(nincs)"
    while True:
        fej("KódTanár — Programozási Tutor")
        print(f"  Aktuális diák-szcenárió: {aktuális_szcenárió_név}")
        print()
        print("  1. Válassz előre definiált szcenáriót")
        print("  2. Mutasd az összes hiedelem-előrejelzést")
        print("  3. Magyarázat egy hiedelemre")
        print('  4. Reflexió ("miért gondolod?")')
        print("  5. Tanítsd újra a modellt")
        print("  6. Tanulási görbe")
        print("  7. Memória (események)")
        print("  8. Mentsd el a modell állapotát")
        print("  0. Kilépés")
        válasz = input("\nVálasz: ").strip()

        if válasz == "0":
            print("\nViszlát! 👋")
            return
        elif válasz == "1":
            new_sc = válassz_szcenáriót()
            if new_sc is not None:
                rt.észlel(**new_sc)
                # Aktuális név meghatározása
                for név, gen in sc.ÖSSZES_SZCENÁRIÓ.items():
                    if gen() == new_sc:
                        aktuális_szcenárió_név = név
                        break
                print(f"\n✓ Beállítva: {aktuális_szcenárió_név}")
        elif válasz == "2":
            kiír_predikciókat(rt)
        elif válasz == "3":
            magyarázat_részletesen(rt)
        elif válasz == "4":
            reflektálás(rt)
        elif válasz == "5":
            tanítsd_újra(rt)
        elif válasz == "6":
            tanulási_görbe(rt)
        elif válasz == "7":
            memória(rt)
        elif válasz == "8":
            mentsd_el(rt)
        else:
            print("Ismeretlen választás.")

        input("\n(Enter a folytatáshoz...)")


def main() -> None:
    fej("KódTanár — Programozási Tutor Tudat-modell")
    rt = betölt_vagy_készít_modellt()
    try:
        fő_menü(rt)
    except (EOFError, KeyboardInterrupt):
        print("\n\nMegszakítva.")


if __name__ == "__main__":
    main()

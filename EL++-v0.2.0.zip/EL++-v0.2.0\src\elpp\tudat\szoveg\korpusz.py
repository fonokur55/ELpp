"""Korpusz-betöltő + tréner a tanult nyelvi modellhez — Phase 8 / M8.3.b.

A `data/korpusz/` (vagy bármely mappa) `.txt` fájljait tokenizálja, szótárat épít,
és csúszó-ablakos tanító-párokká `(kontextus, következő_token)` alakítja, majd a
`NyelvModell`-t valódi szövegen tanítja (tiszta nyelvi modellként, kondíció nélkül).

**Skála-őszinteség:** ez tiszta Python, CPU — egy nagy szótár + sok token lassú.
Ezért a betöltő `min_gyakoriság`-gal kapja el a szótárat (ritka szó → `<ismeretlen>`),
és `max_token`-nel vágható a korpusz. Az első tanítás BIZONYÍTÉK (a modell valódi
magyaron tanul), nem produkciós modell — a skálázás (vektorizáció) későbbi téma.
"""

from __future__ import annotations

import random
from pathlib import Path
from typing import Iterator

from elpp.tudat.szoveg.nyelvmodell import NyelvModell
from elpp.tudat.szoveg.tokenizer import PADDING_INDEX, Szótár, Tokenizer


def szövegfájlok(mappa: "str | Path") -> list[Path]:
    """A mappa (rekurzív) `.txt` fájljai, determinisztikus sorrendben."""
    return sorted(Path(mappa).rglob("*.txt"))


def építs_korpuszt(
    mappa: "str | Path",
    *,
    min_gyakoriság: int = 5,
    max_token: int | None = None,
    case_sensitive: bool = False,
) -> tuple[Szótár, list[int]]:
    """A mappa szövegéből szótár + token-index folyam.

    A `min_gyakoriság` alatti szavak `<ismeretlen>`-re képződnek (szótár-méret
    kordában tartása). A `max_token` levágja a folyamot (gyors első tanításhoz).
    """
    # A korpusz-dokumentumok hosszúak — a >500 token figyelmeztetés itt nem releváns.
    tok = Tokenizer(case_sensitive=case_sensitive, figyelmeztetési_küszöb=10**9)
    tokenek: list[str] = []
    for f in szövegfájlok(mappa):
        szöveg = f.read_text(encoding="utf-8", errors="ignore")
        tokenek.extend(tok.tokenizál(szöveg))
        if max_token is not None and len(tokenek) >= max_token:
            tokenek = tokenek[:max_token]
            break
    szótár = Szótár(min_gyakoriság=min_gyakoriság).illeszt([tokenek])
    indexek = szótár.kódol(tokenek)
    return szótár, indexek


def tanító_párok(
    indexek: list[int], ablak: int, *, pad: int = PADDING_INDEX
) -> Iterator[tuple[list[int], int]]:
    """Csúszó-ablakos `(kontextus, következő_token)` párok.

    A folyam elejét `pad`-del töltjük, így az első tokenek is jósolhatók.
    """
    puffer = [pad] * ablak
    for idx in indexek:
        yield list(puffer), idx
        puffer = puffer[1:] + [idx]


def tanítsd(
    modell: NyelvModell,
    indexek: list[int],
    *,
    epochok: int = 1,
    tanulási_ráta: float = 0.1,
    max_lépés: int | None = None,
    napló_lépésenként: int = 1000,
) -> list[tuple[int, float]]:
    """A modellt a token-folyamon tanítja (tiszta nyelvi modell, kondíció nélkül).

    Visszatérés: napló `(lépés, átlag_veszteség)` párok listája — a `napló_lépésenként`
    ablakok átlagolt vesztesége (tanulási görbe).
    """
    napló: list[tuple[int, float]] = []
    lépés = 0
    futó_összeg = 0.0
    futó_db = 0
    for _ in range(epochok):
        for kontextus, cél in tanító_párok(indexek, modell.ablak):
            v = modell.tanulj_lépés(kontextus, [], cél, tanulási_ráta)
            futó_összeg += v
            futó_db += 1
            lépés += 1
            if lépés % napló_lépésenként == 0:
                napló.append((lépés, futó_összeg / futó_db))
                futó_összeg = 0.0
                futó_db = 0
            if max_lépés is not None and lépés >= max_lépés:
                if futó_db:
                    napló.append((lépés, futó_összeg / futó_db))
                return napló
    if futó_db:
        napló.append((lépés, futó_összeg / futó_db))
    return napló


def folytat_szöveg(
    modell: NyelvModell,
    szótár: Szótár,
    kezdet: str,
    *,
    hossz: int = 20,
    hőmérséklet: float = 0.7,
    case_sensitive: bool = False,
    seed: int | None = None,
) -> str:
    """Kényelmi: szöveg-kezdetből generál szöveg-folytatást (a szótáron át)."""
    tok = Tokenizer(case_sensitive=case_sensitive)
    kezdő_indexek = szótár.kódol(tok.tokenizál(kezdet)) or [PADDING_INDEX]
    ki = modell.generál(
        kezdő_indexek,
        hossz=hossz,
        hőmérséklet=hőmérséklet,
        rng=random.Random(seed),
    )
    return " ".join(szótár.dekódol(ki))

"""Generátor-szerződés + gyár — Phase 8 / M8.5 (skálázható váz).

A cél: a GPU-átállás (numpy → PyTorch) legyen LOKÁLIS CSERE, ne újraírás. Ezt NEM
egy nehéz, spekulatív backend-absztrakcióval érjük el (az korai optimalizálás
lenne), hanem egy TISZTA SZERZŐDÉSSEL:

  • `Generátor` Protocol — pontosan rögzíti, mit kell egy tanult, belief-
    kondicionált generátornak nyújtania. A fogyasztók (Beszélgetés, grounded)
    EHHEZ kötődnek, nem a konkrét osztályhoz.
  • `generátort_készít(backend=...)` — egy hely, ahol a háttér választható.
    Most: "numpy" → NyelvModell. Később: "torch" → GPU-implementáció (ugyanezt a
    Protocolt megvalósítva, torch autograd-dal).

Így a skálázás = EGY ÚJ OSZTÁLY a known szerződés ellen — a rendszer többi része
változatlan marad.
"""

from __future__ import annotations

import random
from typing import Protocol, runtime_checkable

from elpp.tudat.szoveg.nyelvmodell import NyelvModell


@runtime_checkable
class Generátor(Protocol):
    """Egy tanult, belief-kondicionált szöveg-generátor szerződése.

    Bármely implementáció (numpy/CPU most, torch/GPU később) ezt nyújtja — a
    rendszer többi része csak EZT használja. A backward/optimalizáló MÓDJA az
    implementáció belügye (numpy: analitikus gradiens; torch: autograd).
    """

    vocab_méret: int
    ablak: int
    kondíció_méret: int

    def eloszlás(
        self, kontextus: list[int], kondíció: list[float] | None = None
    ) -> object:
        """A következő token valószínűség-eloszlása a szótár felett."""
        ...

    def tanulj_lépés(
        self, kontextus: list[int], kondíció: list[float], cél: int,
        tanulási_ráta: float,
    ) -> float:
        """Egy tanulási lépés; visszaadja a lépés előtti veszteséget."""
        ...

    def generál(
        self,
        kezdő_kontextus: list[int],
        *,
        kondíció: list[float] | None = None,
        hossz: int = 20,
        hőmérséklet: float = 1.0,
        rng: "random.Random | None" = None,
        leállító: int | None = None,
    ) -> list[int]:
        """Token-szekvencia generálása autoregresszíven."""
        ...


# Backend-regiszter: backend-név → konstruktor. ÚJ HÁTTÉR = egy sor ide.
# A "torch" (GPU) a finanszírozott skálázási fázisban kerül be.
_HÁTTEREK: dict[str, type] = {
    "numpy": NyelvModell,
}


def elérhető_háttérek() -> list[str]:
    """A regisztrált generátor-háttérek (most: csak 'numpy')."""
    return sorted(_HÁTTEREK)


def generátort_készít(
    backend: str = "numpy",
    *,
    vocab_méret: int,
    ablak: int = 3,
    dim: int = 32,
    rejtett: int = 64,
    kondíció_méret: int = 0,
    seed: int | None = None,
) -> Generátor:
    """Generátort hoz létre a választott háttérrel (egyetlen belépési pont).

    Most "numpy" (CPU, analitikus gradiens). A "torch" (GPU, autograd) a jövőbeli
    skálázáshoz — ugyanezt a `Generátor` szerződést kell megvalósítania, így a
    hívók (Beszélgetés, grounded) változatlanok maradnak.
    """
    if backend == "torch":
        raise NotImplementedError(
            "A 'torch' (GPU) háttér a finanszírozott skálázási fázis feladata "
            "(lásd docs/skalazas.md). Egy TorchGenerátor a `Generátor` Protocolt "
            "valósítja meg torch autograd-dal — a rendszer többi része nem változik."
        )
    konstruktor = _HÁTTEREK.get(backend)
    if konstruktor is None:
        raise ValueError(
            f"Ismeretlen generátor-háttér: `{backend}`. "
            f"Elérhető: {elérhető_háttérek()}."
        )
    return konstruktor(
        vocab_méret, ablak=ablak, dim=dim, rejtett=rejtett,
        kondíció_méret=kondíció_méret, seed=seed,
    )
